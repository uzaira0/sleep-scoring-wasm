var a = "argument,value,context\ndatadir,,not applicable\ndo.report,\"c(2,4,5,6)\",not applicable\nf0,1,not applicable\nf1,542,not applicable\nmode,\"c(1,2,3,4,5,6)\",not applicable\noutputdir,,not applicable\nrawaccfiles_formats,csv,not applicable\nstudyname,,not applicable\nGGIRread_version,could not extract version,not applicable\nGGIRversion,3.0.0,not applicable\nR_version,R version 4.4.3 (2025-02-28),not applicable\nqwindow,\"c(0,24)\",params_247\nqlevels,\"c(0.958333333333333,0.979166666666667,0.993055555555556)\",params_247\nqwindow_dateformat,%d-%m-%Y,params_247\nilevels,c(),params_247\nIVIS_windowsize_minutes,60,params_247\nIVIS_epochsize_seconds,c(),params_247\nIVIS.activity.metric,2,params_247\nIVIS_acc_threshold,20,params_247\nqM5L5,c(),params_247\nMX.ig.min.dur,10,params_247\nM5L5res,10,params_247\nwinhr,\"c(5,10)\",params_247\niglevels,\"c(0,25,50,75,100,125,150,175,200,225,250,275,300,325,350,375,400,425,450,475,500,525,550,575,600,625,650,675,700,725,750,775,800,825,850,875,900,925,950,975,1000,1025,1050,1075,1100,1125,1150,1175,1200,1225,1250,1275,1300,1325,1350,1375,1400,1425,1450,1475,1500,1525,1550,1575,1600,1625,1650,1675,1700,1725,1750,1775,1800,1825,1850,1875,1900,1925,1950,1975,2000,2025,2050,2075,2100,2125,2150,2175,2200,2225,2250,2275,2300,2325,2350,2375,2400,2425,2450,2475,2500,2525,2550,2575,2600,2625,2650,2675,2700,2725,2750,2775,2800,2825,2850,2875,2900,2925,2950,2975,3000,3025,3050,3075,3100,3125,3150,3175,3200,3225,3250,3275,3300,3325,3350,3375,3400,3425,3450,3475,3500,3525,3550,3575,3600,3625,3650,3675,3700,3725,3750,3775,3800,3825,3850,3875,3900,3925,3950,3975,4000,8000)\",params_247\nLUXthresholds,\"c(0,100,500,1000,3000,5000,10000)\",params_247\nLUX_cal_constant,c(),params_247\nLUX_cal_exponent,c(),params_247\nLUX_day_segments,c(),params_247\nwindow.summary.size,10,params_247\nL5M5window,\"c(0,24)\",params_247\ncosinor,TRUE,params_247\nincludedaycrit,1,params_cleaning\nndayswindow,7,params_cleaning\nstrategy,1,params_cleaning\nmaxdur,0,params_cleaning\nhrs.del.start,0,params_cleaning\nhrs.del.end,0,params_cleaning\nincludedaycrit.part5,0.083333333,params_cleaning\nexcludefirstlast.part5,FALSE,params_cleaning\nTimeSegments2ZeroFile,c(),params_cleaning\ndo.imp,TRUE,params_cleaning\ndata_cleaning_file,c(),params_cleaning\nminimum_MM_length.part5,23,params_cleaning\nexcludefirstlast,FALSE,params_cleaning\nincludenightcrit,1,params_cleaning\nexcludefirst.part4,FALSE,params_cleaning\nexcludelast.part4,FALSE,params_cleaning\nmax_calendar_days,0,params_cleaning\nnonWearEdgeCorrection,TRUE,params_cleaning\nnonwear_approach,2023,params_cleaning\nsegmentWEARcrit.part5,0.5,params_cleaning\nsegmentDAYSPTcrit.part5,\"c(0.9,0)\",params_cleaning\noverwrite,FALSE,params_general\nacc.metric,ENMO,params_general\nmaxNcores,c(),params_general\nprint.filename,FALSE,params_general\ndo.parallel,TRUE,params_general\nwindowsizes,\"c(5,900,3600)\",params_general\ndesiredtz,EST,params_general\nconfigtz,c(),params_general\nidloc,1,params_general\ndayborder,0,params_general\npart5_agg2_60seconds,FALSE,params_general\nsensor.location,wrist,params_general\nexpand_tail_max_hours,c(),params_general\nrecordingEndSleepHour,c(),params_general\ndataFormat,raw,params_general\nmaxRecordingInterval,c(),params_general\nextEpochData_timeformat,%d-%m-%Y %H:%M:%S,params_general\ndo.anglex,FALSE,params_metrics\ndo.angley,FALSE,params_metrics\ndo.anglez,TRUE,params_metrics\ndo.zcx,FALSE,params_metrics\ndo.zcy,FALSE,params_metrics\ndo.zcz,FALSE,params_metrics\ndo.enmo,TRUE,params_metrics\ndo.lfenmo,FALSE,params_metrics\ndo.en,FALSE,params_metrics\ndo.mad,FALSE,params_metrics\ndo.enmoa,FALSE,params_metrics\ndo.roll_med_acc_x,FALSE,params_metrics\ndo.roll_med_acc_y,FALSE,params_metrics\ndo.roll_med_acc_z,FALSE,params_metrics\ndo.dev_roll_med_acc_x,FALSE,params_metrics\ndo.dev_roll_med_acc_y,FALSE,params_metrics\ndo.dev_roll_med_acc_z,FALSE,params_metrics\ndo.bfen,FALSE,params_metrics\ndo.hfen,FALSE,params_metrics\ndo.hfenplus,FALSE,params_metrics\ndo.lfen,FALSE,params_metrics\ndo.lfx,FALSE,params_metrics\ndo.lfy,FALSE,params_metrics\ndo.lfz,FALSE,params_metrics\ndo.hfx,FALSE,params_metrics\ndo.hfy,FALSE,params_metrics\ndo.hfz,FALSE,params_metrics\ndo.bfx,FALSE,params_metrics\ndo.bfy,FALSE,params_metrics\ndo.bfz,FALSE,params_metrics\ndo.brondcounts,FALSE,params_metrics\ndo.neishabouricounts,FALSE,params_metrics\nhb,15,params_metrics\nlb,0.2,params_metrics\nn,4,params_metrics\nzc.lb,0.25,params_metrics\nzc.hb,3,params_metrics\nzc.sb,0.01,params_metrics\nzc.order,2,params_metrics\nzc.scale,1,params_metrics\nactilife_LFE,FALSE,params_metrics\nepochvalues2csv,FALSE,params_output\nsave_ms5rawlevels,TRUE,params_output\nsave_ms5raw_format,csv,params_output\nsave_ms5raw_without_invalid,TRUE,params_output\nstorefolderstructure,FALSE,params_output\ntimewindow,WW,params_output\nviewingwindow,1,params_output\ndofirstpage,TRUE,params_output\nvisualreport,TRUE,params_output\nweek_weekend_aggregate.part5,FALSE,params_output\ndo.part3.pdf,TRUE,params_output\noutliers.only,TRUE,params_output\ncriterror,4,params_output\ndo.visual,TRUE,params_output\ndo.sibreport,FALSE,params_output\ndo.part2.pdf,TRUE,params_output\nsep_reports,\",\",params_output\nsep_config,\",\",params_output\nvisualreport_without_invalid,FALSE,params_output\nmvpathreshold,100,params_phyact\nboutcriter,0.8,params_phyact\nmvpadur,\"c(1,5,10)\",params_phyact\nboutcriter.in,0.9,params_phyact\nboutcriter.lig,0.8,params_phyact\nboutcriter.mvpa,0.8,params_phyact\nthreshold.lig,30,params_phyact\nthreshold.mod,100,params_phyact\nthreshold.vig,400,params_phyact\nboutdur.mvpa,\"c(1,5,10)\",params_phyact\nboutdur.in,\"c(1,10,30)\",params_phyact\nboutdur.lig,\"c(1,10,30)\",params_phyact\nfrag.metrics,all,params_phyact\nchunksize,1,params_rawdata\nspherecrit,0.3,params_rawdata\nminloadcrit,72,params_rawdata\nprintsummary,FALSE,params_rawdata\ndo.cal,TRUE,params_rawdata\nbackup.cal.coef,retrieve,params_rawdata\ndynrange,c(),params_rawdata\nminimumFileSizeMB,2,params_rawdata\nrmc.dec,.,params_rawdata\nrmc.firstrow.acc,c(),params_rawdata\nrmc.firstrow.header,c(),params_rawdata\nrmc.header.length,c(),params_rawdata\nrmc.col.acc,\"c(1,2,3)\",params_rawdata\nrmc.col.temp,c(),params_rawdata\nrmc.col.time,c(),params_rawdata\nrmc.unit.acc,g,params_rawdata\nrmc.unit.temp,C,params_rawdata\nrmc.unit.time,POSIX,params_rawdata\nrmc.format.time,%Y-%m-%d %H:%M:%OS,params_rawdata\nrmc.bitrate,c(),params_rawdata\nrmc.dynamic_range,c(),params_rawdata\nrmc.unsignedbit,TRUE,params_rawdata\nrmc.origin,1/1/1970,params_rawdata\nrmc.desiredtz,c(),params_rawdata\nrmc.configtz,c(),params_rawdata\nrmc.sf,c(),params_rawdata\nrmc.headername.sf,c(),params_rawdata\nrmc.headername.sn,c(),params_rawdata\nrmc.headername.recordingid,c(),params_rawdata\nrmc.header.structure,c(),params_rawdata\nrmc.check4timegaps,FALSE,params_rawdata\nrmc.noise,13,params_rawdata\nrmc.col.wear,c(),params_rawdata\nrmc.doresample,FALSE,params_rawdata\ninterpolationType,1,params_rawdata\nimputeTimegaps,TRUE,params_rawdata\nfrequency_tol,0.1,params_rawdata\nrmc.scalefactor.acc,1,params_rawdata\nanglethreshold,5,params_sleep\ntimethreshold,5,params_sleep\nignorenonwear,TRUE,params_sleep\nconstrain2range,TRUE,params_sleep\nHASPT.algo,HDCZA,params_sleep\nHASIB.algo,vanHees2015,params_sleep\nSadeh_axis,,params_sleep\nlongitudinal_axis,c(),params_sleep\nHASPT.ignore.invalid,FALSE,params_sleep\nloglocation,c(),params_sleep\ncolid,1,params_sleep\ncoln1,2,params_sleep\nnnights,c(),params_sleep\nrelyonguider,FALSE,params_sleep\ndef.noc.sleep,1,params_sleep\nsleeplogsep,c(),params_sleep\nsleepwindowType,SPT,params_sleep\npossible_nap_window,\"c(9,18)\",params_sleep\npossible_nap_dur,\"c(15,240)\",params_sleep\n";
const e = "no_sleep_toggled", r = "main_sleep_on_no_sleep_night";
Object.freeze({ [e]: "invalid_night_toggled" }), Object.freeze({ [r]: "main_sleep_on_invalid_night" }), Object.freeze({
	camel: "isNoSleep",
	snake: "is_no_sleep",
	placement: "no_sleep",
	auditAction: e,
	exportHeader: "Is No Sleep",
	guard: r
});
const n = new Int32Array([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]), t = /* @__PURE__ */ new Int32Array(64);
const s = a;
var o;
Object.freeze({
	name: "default ELEMENT",
	sha256: (o = a, function(a) {
		const e = a instanceof Uint8Array ? a : new Uint8Array(a);
		let r = "";
		for (const n of e) r += n.toString(16).padStart(2, "0");
		return r;
	}(function(a) {
		const e = new Uint32Array([
			1779033703,
			3144134277,
			1013904242,
			2773480762,
			1359893119,
			2600822924,
			528734635,
			1541459225
		]), r = 8n * BigInt(a.length), s = 64 * Math.ceil((a.length + 9) / 64), o = new Uint8Array(s);
		o.set(a), o[a.length] = 128, new DataView(o.buffer).setBigUint64(s - 8, r, !1), function(a, e, r, s) {
			let o = 0 | a[0], i = 0 | a[1], c = 0 | a[2], m = 0 | a[3], p = 0 | a[4], l = 0 | a[5], d = 0 | a[6], u = 0 | a[7];
			for (let _ = 0; _ + 64 <= s; _ += 64) {
				for (let n = 0, o = _; n < 16; n++, o += 4) t[n] = e[o] << 24 | e[o + 1] << 16 | e[o + 2] << 8 | e[o + 3];
				for (let e = 16; e < 64; e++) {
					const a = t[e - 15], r = t[e - 2], n = (a >>> 7 | a << 25) ^ (a >>> 18 | a << 14) ^ a >>> 3, s = (r >>> 17 | r << 15) ^ (r >>> 19 | r << 13) ^ r >>> 10;
					t[e] = t[e - 16] + n + t[e - 7] + s | 0;
				}
				let a = o, r = i, s = c, f = m, g = p, h = l, w = d, E = u;
				for (let e = 0; e < 64; e++) {
					const o = E + ((g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7)) + (g & h ^ ~g & w) + n[e] + t[e] | 0, i = ((a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10)) + (a & r ^ a & s ^ r & s) | 0;
					E = w, w = h, h = g, g = f + o | 0, f = s, s = r, r = a, a = o + i | 0;
				}
				o = o + a | 0, i = i + r | 0, c = c + s | 0, m = m + f | 0, p = p + g | 0, l = l + h | 0, d = d + w | 0, u = u + E | 0;
			}
			a[0] = o, a[1] = i, a[2] = c, a[3] = m, a[4] = p, a[5] = l, a[6] = d, a[7] = u;
		}(e, o, 0, s);
		const i = /* @__PURE__ */ new Uint8Array(32), c = new DataView(i.buffer);
		for (let n = 0; n < 8; n++) c.setUint32(4 * n, e[n], !1);
		return i;
	}(new TextEncoder().encode(o)))),
	csvText: a
});
const i = Symbol("Comlink.proxy"), c = Symbol("Comlink.endpoint"), m = Symbol("Comlink.releaseProxy"), p = Symbol("Comlink.finalizer"), l = Symbol("Comlink.thrown"), d = (a) => "object" == typeof a && null !== a || "function" == typeof a, u = /* @__PURE__ */ new Map([["proxy", {
	canHandle: (a) => d(a) && a[i],
	serialize(a) {
		const { port1: e, port2: r } = new MessageChannel();
		return _(a, e), [r, [r]];
	},
	deserialize: (a) => (a.start(), function(a) {
		const e = /* @__PURE__ */ new Map();
		return a.addEventListener("message", function(a) {
			const { data: r } = a;
			if (!r || !r.id) return;
			const n = e.get(r.id);
			if (n) try {
				n(r);
			} finally {
				e.delete(r.id);
			}
		}), y(a, e, [], void 0);
	}(a))
}], ["throw", {
	canHandle: (a) => d(a) && l in a,
	serialize({ value: a }) {
		let e;
		return e = a instanceof Error ? {
			isError: !0,
			value: {
				message: a.message,
				name: a.name,
				stack: a.stack
			}
		} : {
			isError: !1,
			value: a
		}, [e, []];
	},
	deserialize(a) {
		if (a.isError) throw Object.assign(new Error(a.value.message), a.value);
		throw a.value;
	}
}]]);
/**
* @license
* Copyright 2019 Google LLC
* SPDX-License-Identifier: Apache-2.0
*/ function _(a, e = globalThis, r = ["*"]) {
	e.addEventListener("message", function n(t) {
		if (!t || !t.data) return;
		if (!function(a, e) {
			for (const r of a) {
				if (e === r || "*" === r) return !0;
				if (r instanceof RegExp && r.test(e)) return !0;
			}
			return !1;
		}(r, t.origin)) return void console.warn(`Invalid origin '${t.origin}' for comlink proxy`);
		const { id: s, type: o, path: c } = Object.assign({ path: [] }, t.data), m = (t.data.argumentList || []).map(L);
		let d;
		try {
			const e = c.slice(0, -1).reduce((a, e) => a[e], a), r = c.reduce((a, e) => a[e], a);
			switch (o) {
				case "GET":
					d = r;
					break;
				case "SET":
					e[c.slice(-1)[0]] = L(t.data.value), d = !0;
					break;
				case "APPLY":
					d = r.apply(e, m);
					break;
				case "CONSTRUCT":
					d = function(a) {
						return Object.assign(a, { [i]: !0 });
					}(new r(...m));
					break;
				case "ENDPOINT":
					{
						const { port1: e, port2: r } = new MessageChannel();
						_(a, r), d = A(e, [e]);
					}
					break;
				case "RELEASE":
					d = void 0;
					break;
				default: return;
			}
		} catch (u) {
			d = {
				value: u,
				[l]: 0
			};
		}
		Promise.resolve(d).catch((a) => ({
			value: a,
			[l]: 0
		})).then((r) => {
			const [t, i] = v(r);
			e.postMessage(Object.assign(Object.assign({}, t), { id: s }), i), "RELEASE" === o && (e.removeEventListener("message", n), f(e), p in a && "function" == typeof a[p] && a[p]());
		}).catch((a) => {
			const [r, n] = v({
				value: /* @__PURE__ */ new TypeError("Unserializable return value"),
				[l]: 0
			});
			e.postMessage(Object.assign(Object.assign({}, r), { id: s }), n);
		});
	}), e.start && e.start();
}
function f(a) {
	(function(a) {
		return "MessagePort" === a.constructor.name;
	})(a) && a.close();
}
function g(a) {
	if (a) throw new Error("Proxy has been released and is not useable");
}
function h(a) {
	return F(a, /* @__PURE__ */ new Map(), { type: "RELEASE" }).then(() => {
		f(a);
	});
}
const w = /* @__PURE__ */ new WeakMap(), E = "FinalizationRegistry" in globalThis && new FinalizationRegistry((a) => {
	const e = (w.get(a) || 0) - 1;
	w.set(a, e), 0 === e && h(a);
});
function y(a, e, r = [], n = function() {}) {
	let t = !1;
	const s = new Proxy(n, {
		get(n, o) {
			if (g(t), o === m) return () => {
				(function(a) {
					E && E.unregister(a);
				})(s), h(a), e.clear(), t = !0;
			};
			if ("then" === o) {
				if (0 === r.length) return { then: () => s };
				const n = F(a, e, {
					type: "GET",
					path: r.map((a) => a.toString())
				}).then(L);
				return n.then.bind(n);
			}
			return y(a, e, [...r, o]);
		},
		set(n, s, o) {
			g(t);
			const [i, c] = v(o);
			return F(a, e, {
				type: "SET",
				path: [...r, s].map((a) => a.toString()),
				value: i
			}, c).then(L);
		},
		apply(n, s, o) {
			g(t);
			const i = r[r.length - 1];
			if (i === c) return F(a, e, { type: "ENDPOINT" }).then(L);
			if ("bind" === i) return y(a, e, r.slice(0, -1));
			const [m, p] = S(o);
			return F(a, e, {
				type: "APPLY",
				path: r.map((a) => a.toString()),
				argumentList: m
			}, p).then(L);
		},
		construct(n, s) {
			g(t);
			const [o, i] = S(s);
			return F(a, e, {
				type: "CONSTRUCT",
				path: r.map((a) => a.toString()),
				argumentList: o
			}, i).then(L);
		}
	});
	return function(a, e) {
		const r = (w.get(e) || 0) + 1;
		w.set(e, r), E && E.register(a, e, a);
	}(s, a), s;
}
function S(a) {
	const e = a.map(v);
	return [e.map((a) => a[0]), (r = e.map((a) => a[1]), Array.prototype.concat.apply([], r))];
	var r;
}
const b = /* @__PURE__ */ new WeakMap();
function A(a, e) {
	return b.set(a, e), a;
}
function v(a) {
	for (const [e, r] of u) if (r.canHandle(a)) {
		const [n, t] = r.serialize(a);
		return [{
			type: "HANDLER",
			name: e,
			value: n
		}, t];
	}
	return [{
		type: "RAW",
		value: a
	}, b.get(a) || []];
}
function L(a) {
	switch (a.type) {
		case "HANDLER": return u.get(a.name).deserialize(a.value);
		case "RAW": return a.value;
	}
}
function F(a, e, r, n) {
	return new Promise((t) => {
		const s = new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
		e.set(s, t), a.start && a.start(), a.postMessage(Object.assign({ id: s }, r), n);
	});
}
let T = null;
const z = /unreachable|RuntimeError|out of bounds|wasm/i, R = 1073741824, x = /* @__PURE__ */ new WeakSet();
async function U() {
	const a = await async function(a) {
		if (!0 !== (e = a.scope).pinnedSingleThread && e.sharedArrayBuffer && e.crossOriginIsolated && e.cores > 1) {
			let e;
			try {
				const r = await a.loadThreaded();
				if (e = r, x.has(r)) throw new Error("thread pool start was abandoned earlier in this worker");
				await r.default();
				const n = Math.min(4, a.scope.cores);
				return r.threadPoolReady() || await function(a, e) {
					let r;
					const n = new Promise((a, n) => {
						r = setTimeout(() => {
							n(/* @__PURE__ */ new Error(`thread pool did not start within ${String(e)} ms`));
						}, e);
					});
					return Promise.race([a, n]).finally(() => {
						clearTimeout(r);
					});
				}(r.startThreadPool(n), a.poolStartTimeoutMs ?? 15e3), {
					mod: r,
					runtime: {
						threaded: !0,
						threads: n
					}
				};
			} catch (n) {
				void 0 !== e && x.add(e), a.warn("[wasm] threaded runtime unavailable, using the single-thread package", n);
			}
		}
		var e;
		const r = await a.loadSingle();
		return await r.default(), {
			mod: r,
			runtime: {
				threaded: !1,
				threads: 1
			}
		};
	}({
		scope: {
			pinnedSingleThread: "actours-single-thread" === globalThis.name,
			sharedArrayBuffer: "undefined" != typeof SharedArrayBuffer,
			crossOriginIsolated: "undefined" != typeof crossOriginIsolated && crossOriginIsolated,
			cores: "undefined" != typeof navigator ? navigator.hardwareConcurrency : 1
		},
		loadThreaded: () => import("./actours-CxRalOOc.js"),
		loadSingle: () => import("./actours-DjH2M9a0.js"),
		warn: (a, e) => {
			console.warn(a, e);
		}
	});
	return function(a) {
		const e = /* @__PURE__ */ new Float64Array(16), r = new Uint8Array(a.scoreSadeh(e, -4));
		if (16 !== r.length) throw new Error(`WASM integrity check failed: scoreSadeh length ${String(r.length)}, expected ${String(16)}`);
		for (let n = 0; n < 16; n++) if (1 !== r[n]) throw new Error(`WASM integrity check failed: scoreSadeh(zeros)[${String(n)}] = ${String(r[n])}, expected 1. Bundle may be corrupt — clear the site cache and reload.`);
	}(a.mod), a;
}
let M = null;
(function() {
	const a = console.error.bind(console);
	console.error = (...e) => {
		try {
			const r = e.map((a) => "string" == typeof a ? a : a instanceof Error ? a.stack ?? a.message : String(a)).join(" ");
			if (/panicked at|RuntimeError|unreachable/i.test(r)) {
				const e = /([A-Za-z0-9_.-]+\.rs):(\d+)/.exec(r);
				T = e ? `Rust trap at ${e[1]}:${e[2]}` : "Rust runtime trap", a("[wasm-worker] WASM runtime trap captured");
				return;
			}
		} catch {}
		a(...e);
	};
})(), _(function(a) {
	const e = {};
	for (const r of Object.keys(a)) {
		const n = a[r];
		if ("function" != typeof n) {
			e[r] = n;
			continue;
		}
		const t = n;
		e[r] = async (...a) => {
			T = null;
			try {
				return await t(...a);
			} catch (e) {
				const a = e instanceof Error ? e.message : String(e);
				if (T && z.test(a)) throw new Error(`WASM panic in ${r}(): ${T}`, { cause: e });
				throw e;
			}
		};
	}
	return e;
}({ async processGt3xFull(a, e = 60, r = s) {
	const n = (await (M || (M = (async () => {
		const { mod: a, runtime: e } = await U();
		return a.configureComputeMemoryBudgetV1(function() {
			const a = "undefined" == typeof navigator ? void 0 : navigator.deviceMemory;
			if ("number" != typeof a || !Number.isFinite(a) || a <= 0) return R;
			const e = Math.floor(1024 * a * 1024 * 1024 / 4);
			return Math.min(2147483648, Math.max(R, e));
		}()), a;
	})().catch((a) => {
		throw M = null, a;
	})), M)).processGt3xPart1WithEpoch(new Uint8Array(a), e, r), { enmo5s: t, anglez5s: o, anglex5s: i, angley5s: c, mad5s: m, enmoa5s: p, ggirInvalid5s: l, ggirNonwear5s: d, countsX: u, countsY: _, countsZ: f, countsVm: g } = n, { zcx60s: h, zcy60s: w, zcz60s: E, mimsUnit: y, mimsUnitX: S, mimsUnitY: b, mimsUnitZ: v, preschoolWristRfClasses: L, lstmFeatures30s: F } = n, T = n.ggirZeroCrossings5s?.map((a) => Float64Array.from(a));
	return A({
		enmo5s: t,
		anglez5s: o,
		anglex5s: i,
		angley5s: c,
		mad5s: m,
		enmoa5s: p,
		ggirInvalid5s: l,
		...T ? { ggirZeroCrossings5s: T } : {},
		ggirNonwear5s: d,
		countsX: u,
		countsY: _,
		countsZ: f,
		countsVm: g,
		zcx60s: h,
		zcy60s: w,
		zcz60s: E,
		mimsUnit: y,
		mimsUnitX: S,
		mimsUnitY: b,
		mimsUnitZ: v,
		mimsAvailability: n.mimsAvailability,
		preschoolWristRfClasses: L,
		preschoolWristRfEpochSeconds: n.preschoolWristRfEpochSeconds,
		lstmFeatures30s: F,
		lstmFeatureEpochs: n.lstmFeatureEpochs,
		lstmFeatureBins: n.lstmFeatureBins,
		lstmFeatureChannels: n.lstmFeatureChannels,
		sampleRate: n.sampleRate,
		firstTsMs: n.firstTsMs,
		tzJump: n.tzJump,
		dstTransitions: n.dst.transitions,
		dstTimezone: n.dst.timezone,
		capsense: n.capsense,
		calibration: n.calibration
	}, [
		t.buffer,
		o.buffer,
		i.buffer,
		c.buffer,
		m.buffer,
		p.buffer,
		l.buffer,
		d.buffer,
		u.buffer,
		_.buffer,
		f.buffer,
		g.buffer,
		h.buffer,
		w.buffer,
		E.buffer,
		y.buffer,
		S.buffer,
		b.buffer,
		v.buffer,
		L.buffer,
		F.buffer
	]);
} }));

function e(e) {
	let t, r;
	try {
		const a = function(e, t, n) {
			if (void 0 === n) {
				const n = c.encode(e), r = t(n.length, 1) >>> 0;
				return o().subarray(r, r + n.length).set(n), u = n.length, r;
			}
			let r = e.length, s = t(r, 1) >>> 0;
			const i = o();
			let a = 0;
			for (; a < r; a++) {
				const t = e.charCodeAt(a);
				if (t > 127) break;
				i[s + a] = t;
			}
			if (a !== r) {
				0 !== a && (e = e.slice(a)), s = n(s, r, r = a + 3 * e.length, 1) >>> 0;
				const t = o().subarray(s + a, s + r);
				a += c.encodeInto(e, t).written, s = n(s, r, a, 1) >>> 0;
			}
			return u = a, s;
		}(e, l.__wbindgen_malloc, l.__wbindgen_realloc), f = u, d = l.entriesToNtriples(a, f);
		var s = d[0], i = d[1];
		if (d[3]) throw s = 0, i = 0, function(e) {
			const t = l.__wbindgen_externrefs.get(e);
			return l.__externref_table_dealloc(e), t;
		}(d[2]);
		return t = s, r = i, n(s, i);
	} finally {
		l.__wbindgen_free(t, r, 1);
	}
}
function t() {
	return {
		__proto__: null,
		"./diary_rdf_bg.js": {
			__proto__: null,
			__wbg_Error_ef53bc310eb298a0: function(e, t) {
				return Error(n(e, t));
			},
			__wbindgen_init_externref_table: function() {
				const e = l.__wbindgen_externrefs, t = e.grow(4);
				e.set(0, void 0), e.set(t + 0, void 0), e.set(t + 1, null), e.set(t + 2, !0), e.set(t + 3, !1);
			}
		}
	};
}
function n(e, t) {
	return function(e, t) {
		return a += t, a >= i && (s = new TextDecoder("utf-8", {
			ignoreBOM: !0,
			fatal: !0
		}), s.decode(), a = t), s.decode(o().subarray(e, e + t));
	}(e >>> 0, t);
}
let r = null;
function o() {
	return null !== r && 0 !== r.byteLength || (r = new Uint8Array(l.memory.buffer)), r;
}
let s = new TextDecoder("utf-8", {
	ignoreBOM: !0,
	fatal: !0
});
s.decode();
const i = 2146435072;
let a = 0;
const c = new TextEncoder();
"encodeInto" in c || (c.encodeInto = function(e, t) {
	const n = c.encode(e);
	return t.set(n), {
		read: e.length,
		written: n.length
	};
});
let l, u = 0;
function f(e, t) {
	return l = e.exports, r = null, l.__wbindgen_start(), l;
}
function d(e) {
	if (void 0 !== l) return l;
	void 0 !== e && (Object.getPrototypeOf(e) === Object.prototype ? {module: e} = e : console.warn("using deprecated parameters for `initSync()`; pass a single object instead"));
	const n = t();
	return e instanceof WebAssembly.Module || (e = new WebAssembly.Module(e)), f(new WebAssembly.Instance(e, n));
}
async function b(e) {
	if (void 0 !== l) return l;
	void 0 !== e && (Object.getPrototypeOf(e) === Object.prototype ? {module_or_path: e} = e : console.warn("using deprecated parameters for the initialization function; pass a single object instead")), void 0 === e && (e = new URL("/sleep-scoring-wasm/assets/diary_rdf_bg-Dl2VU04Z.wasm", "" + import.meta.url));
	const n = t();
	("string" == typeof e || "function" == typeof Request && e instanceof Request || "function" == typeof URL && e instanceof URL) && (e = fetch(e));
	const { instance: r, module: o } = await async function(e, t) {
		if ("function" == typeof Response && e instanceof Response) {
			if ("function" == typeof WebAssembly.instantiateStreaming) try {
				return await WebAssembly.instantiateStreaming(e, t);
			} catch (n) {
				if (!e.ok || !function(e) {
					switch (e) {
						case "basic":
						case "cors":
						case "default": return !0;
					}
					return !1;
				}(e.type) || "application/wasm" === e.headers.get("Content-Type")) throw n;
				console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", n);
			}
			const r = await e.arrayBuffer();
			return await WebAssembly.instantiate(r, t);
		}
		{
			const n = await WebAssembly.instantiate(e, t);
			return n instanceof WebAssembly.Instance ? {
				instance: n,
				module: e
			} : n;
		}
	}(await e, n);
	return f(r);
}
export { b as default, e as entriesToNtriples, d as initSync };

import { a as e, o } from "./csv-column-mapping-BSSY09yh.js";
import { t as r } from "./diary-source-adapter-DB4JvE2r.js";
import { diaryOccurrenceSourceBinding as i } from "./diary-occurrence-store-CsUXx3cT.js";
function s(s, t, a, n = {}) {
	const { availableHeaders: c } = n, l = n.instrumentAssignments ?? s?.instrumentMapping?.assignments ?? [];
	if (!s) return [];
	if (!s.diaryMapping) return [];
	const d = s.diaryMapping, u = d.identity_bindings?.some((e) => "occurrence_id" === e.identity_role) ?? !1, m = [];
	if (d.profile_planes?.includes("browser") || m.push({
		key: "local_runtime:execution_plane",
		message: "This source mapping profile does not authorize browser execution. Its structure remains saved for manual authoring and adapter development."
	}), "text/csv" !== d.source_media_type && m.push({
		key: "local_runtime:media_type",
		message: "Local browser diary import requires the explicit text/csv media type."
	}), u) try {
		i(d);
	} catch (g) {
		m.push({
			key: "local_runtime:diary_occurrence",
			message: g instanceof Error ? g.message : "The occurrence_id binding is not executable against one tabular CSV row."
		});
	}
	"tabular_row" !== d.source_record_model && m.push({
		key: "local_runtime:record_model",
		message: "Local browser import requires an explicit tabular-row source model. This source shape remains saved in the profile but cannot be imported locally."
	}), d.source_field_selectors?.some((e) => void 0 !== e.source_part_id || void 0 !== e.source_row_position || void 0 !== e.source_path) && m.push({
		key: "local_runtime:selector_shape",
		message: "Local browser import cannot execute multipart, row-coordinate, or source-path selectors. Their exact structure remains saved for a matching adapter."
	}), "direct_record" !== d.record_assembly?.assembly_kind && m.push({
		key: "local_runtime:record_assembly",
		message: "Local browser import requires explicit direct-record assembly. Keyed-object, event-pairing, or unstated assembly remains saved but cannot be imported locally."
	});
	const p = d.record_assembly;
	(void 0 !== d.source_record_root_path || p && (void 0 !== p.record_root_path || (p.key_selector_ids?.length ?? 0) > 0 || (p.grouping_selector_ids?.length ?? 0) > 0 || (p.ordering_selector_ids?.length ?? 0) > 0 || (p.repeated_row_discriminator_selector_ids?.length ?? 0) > 0 || void 0 !== p.method_reference || void 0 !== p.method_version || void 0 !== p.parameter_json || void 0 !== p.parameter_sha256)) && m.push({
		key: "local_runtime:record_assembly_instructions",
		message: "Direct-record browser execution cannot ignore additional assembly instructions."
	}), "occurrences_across_rows" !== d.diary_occurrence_layout && m.push({
		key: "local_runtime:occurrence_layout",
		message: "Local browser import requires explicit diary occurrences across rows. Other or unstated layouts remain saved but cannot be imported locally."
	}), "fields_in_columns" !== d.field_orientation && m.push({
		key: "local_runtime:field_orientation",
		message: "Local browser import requires explicit fields-in-columns orientation. Transposed or unstated orientation remains saved but cannot be imported locally."
	}), d.repeated_event_layouts?.some((e) => "none" !== e.layout) && m.push({
		key: "local_runtime:repeated_event_layout",
		message: "Repeated-event layouts remain preserved, but browser execution is blocked until an adapter binds each event concept and episode role instead of inferring header patterns."
	});
	const _ = d.source_row_role_bindings ?? [];
	if ((1 !== _.length || _.some((e) => "diary_entry" !== e.row_entity_kind || "new_source_record" !== e.revision_mode || void 0 !== e.discriminator_selector_id)) && m.push({
		key: "local_runtime:row_semantics",
		message: "Local browser import requires exactly one new diary-entry row role without a mixed row discriminator."
	}), "complete_submission" !== d.record_semantics && m.push({
		key: "local_runtime:record_semantics",
		message: "Local browser import executes complete submissions only; sparse-patch semantics remain preserved until an adapter binds absent, no-op, and explicit-clear operations."
	}), "mapped_slots_only" !== d.canonical_write_scope && m.push({
		key: "local_runtime:canonical_write_scope",
		message: "Browser import requires mapped-slots-only write authority so one paper instrument cannot clear unrelated canonical diary fields."
	}), 1 === _.length && void 0 !== _[0].record_semantics && _[0].record_semantics !== d.record_semantics && m.push({
		key: "local_runtime:row_semantics_mismatch",
		message: "The source row role and mapping record semantics disagree."
	}), d.column_mappings.some((e) => void 0 !== e.episode_index || void 0 !== e.episode_field_role) && m.push({
		key: "local_runtime:episode_mapping",
		message: "Explicit repeated-episode indexes and field roles are preserved, but the browser CSV adapter does not execute them yet."
	}), void 0 !== c) try {
		const e = r(d, c);
		for (const [o, r] of Object.entries(e)) t[o] !== r && m.push({
			key: `local_runtime:identity_role:${o}`,
			message: `The ${o} parser anchor must use the exact evidence-authored identity column.`
		});
	} catch (g) {
		m.push({
			key: "local_runtime:identity_role",
			message: g instanceof Error ? g.message : "A source identity binding is not executable against this CSV."
		});
	}
	if ("," !== d.delimiter && m.push({
		key: "local_runtime:delimiter",
		message: "Local browser diary import requires an explicit comma delimiter."
	}), d.character_encoding && ["utf-8", "utf8"].includes(d.character_encoding.toLowerCase()) || m.push({
		key: "local_runtime:encoding",
		message: "Local browser diary import requires an explicit UTF-8 character encoding."
	}), d.skip_rows === a && d.header_row_index === a || m.push({
		key: "local_runtime:header_row",
		message: "Explicit replication-profile header coordinates must match the active Skip rows setting."
	}), "tabular_row" === d.source_record_model && "fields_in_transposed_rows" !== d.field_orientation && "fields_in_transposed_blocks" !== d.field_orientation) for (const o of d.column_mappings) {
		if (void 0 === c) {
			m.push({
				key: `local_runtime:source_coordinate:${o.canonical_slot}`,
				message: "Exact source headers are required before a canonical source-profile mapping can execute locally."
			});
			continue;
		}
		const r = c.map((e, o) => ({
			header: e,
			position: o + 1
		})).filter(({ header: r }) => e(r) === e(o.source_field_name)).map(({ position: e }) => e);
		(1 !== r.length || void 0 !== o.source_field_position && r[0] !== o.source_field_position) && m.push({
			key: `local_runtime:source_coordinate:${o.canonical_slot}`,
			message: "The local canonical-field parser cannot prove this exact source position from a name-only mapping. Choose a uniquely named source column or use an adapter that executes positional canonical mappings."
		});
	}
	if (void 0 === c) m.push({
		key: "local_runtime:source_selector_partition",
		message: "Exact source headers are required to prove that every executable CSV column has one source selector and an explicit mapping decision."
	});
	else {
		const e = d.source_field_selectors ?? [], o = /* @__PURE__ */ new Map();
		for (const s of e) {
			const e = void 0 === s.source_field_position ? c.map((e, o) => ({
				header: e,
				position: o + 1
			})).filter(({ header: e }) => void 0 !== s.source_field_name && e === s.source_field_name).map(({ position: e }) => e) : void 0 === c[s.source_field_position - 1] || void 0 !== s.source_field_name && c[s.source_field_position - 1] !== s.source_field_name ? [] : [s.source_field_position];
			1 === e.length && o.set(s.selector_id, e[0]);
		}
		const r = /* @__PURE__ */ new Map();
		for (const [s, t] of o) {
			const e = r.get(t);
			e ? e.push(s) : r.set(t, [s]);
		}
		(o.size !== e.length || c.some((e, o) => 1 !== r.get(o + 1)?.length)) && m.push({
			key: "local_runtime:source_selector_partition",
			message: "Every uploaded CSV header position must resolve to exactly one evidence-authored source selector; duplicate names require distinct one-based positions."
		});
		const i = new Set(d.unmapped_source_selector_ids ?? []);
		d.identity_bindings?.forEach((e) => {
			e.selector_ids.forEach((e) => {
				i.add(e);
			});
		}), d.column_mappings.forEach((e) => {
			void 0 !== e.source_selector_id && i.add(e.source_selector_id);
		});
		for (const s of l) {
			if (void 0 !== s.sourceSelectorId) {
				i.add(s.sourceSelectorId);
				continue;
			}
			const e = void 0 === s.sourceFieldName ? [] : c.map((e, o) => ({
				header: e,
				position: o + 1
			})).filter(({ header: e }) => e === s.sourceFieldName).map(({ position: e }) => e), o = void 0 === s.sourceFieldPosition ? 1 === e.length ? e[0] : void 0 : void 0 === s.sourceFieldName || c[s.sourceFieldPosition - 1] === s.sourceFieldName ? s.sourceFieldPosition : void 0;
			if (void 0 === o) continue;
			const t = r.get(o) ?? [];
			1 === t.length && i.add(t[0]);
		}
		e.filter((e) => !i.has(e.selector_id)).length > 0 && m.push({
			key: "local_runtime:source_selector_accounting",
			message: "Every source selector must be used by an identity binding, reviewed-variable assignment, canonical mapping, or the exact intentionally-unmapped selector list."
		});
	}
	const h = d.column_mappings.map((e) => `${e.canonical_slot}\0${e.source_field_name}`).sort(), y = Object.entries(t).flatMap(([e, r]) => o(r).map((o) => `${e}\0${o}`)).sort();
	return h.length > 0 && JSON.stringify(h) !== JSON.stringify(y) && m.push({
		key: "local_runtime:source_mapping",
		message: "The authored source-profile column mappings must exactly match the active manual mapping before local import."
	}), m;
}
export { s as validateLocalDiaryReplicationRuntime };

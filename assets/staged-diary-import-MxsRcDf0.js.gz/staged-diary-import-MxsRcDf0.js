import { Bt as e, Pt as t, t as a, zt as r } from "./schema-BHdDgVmx.js";
import "./local-data-source-DA97v67F.js";
import { I as i, n, t as s, w as o } from "./workspace-db-MESLoRZb.js";
import "./background-jobs-DEvUJdJD.js";
import { Et as c, P as l, Tt as d, Vt as f, at as u, ct as p, it as m, lt as g, ot as w, r as y, st as h, ut as v, wt as _ } from "./store-Ws1lFj33.js";
import { E as b } from "./night-session-registry-ByzRGVV_.js";
import { t as j } from "./audit-log-Cn9vPjEI.js";
import { c as S, s as k } from "./diary-local-import-contract-fQgt3inx.js";
import "./diary-source-adapter-fhbTh-Jv.js";
i.evening_onset, i.evening_onset, i.morning_offset, i.morning_offset;
const { verdictMinutes: E } = S, M = (E.spt_verdict_max_minutes, E.tib_verdict_max_minutes, E.onset_gap_verdict_max_minutes, E.sol_verdict_max_minutes, f), D = {
	upload: "upload",
	structure: "structure",
	map: "mapping",
	mapping: "mapping",
	validate: "validate"
}, K = "<destination>";
(function(e) {
	const t = k[e];
	if (void 0 === D[t.resolveStep]) throw new Error(`Diary decision rule ${e} resolves on unknown step ${t.resolveStep}.`);
	const a = t.resolveControl;
	a.includes(K) && a.replace(`-${K}`, "");
})("time_only_date_filled"), new Map(Object.entries(k).flatMap(([e, t]) => t.findingCodes.map((t) => [t, e]))), new Map(Object.entries(M).map(([e, t]) => [t, e])), Object.values(o), Object.fromEntries([
	{
		result: null,
		label: "All nights",
		tone: "neutral"
	},
	{
		result: "as_written",
		label: "As written",
		tone: "ok"
	},
	{
		result: "date_filled",
		label: "Date filled in",
		tone: "derived"
	},
	{
		result: "sources_agree",
		label: "Two sources agree",
		tone: "ok"
	},
	{
		result: "needs_decision",
		label: "Needs a decision",
		tone: "warning"
	},
	{
		result: "sources_disagree",
		label: "Sources disagree",
		tone: "danger"
	},
	{
		result: "cannot_be_read",
		label: "Cannot be read",
		tone: "danger"
	}
].filter((e) => null !== e.result).map((e) => [e.result, e.label.toLowerCase()]));
const x = /* @__PURE__ */ new WeakMap(), B = /* @__PURE__ */ new WeakMap(), C = /* @__PURE__ */ new WeakSet();
async function W(i, o) {
	n() && i === s() && await async function(i, n, o = []) {
		let f;
		try {
			f = await function(i, n = s(), o, f = []) {
				const S = B.get(n);
				if (S) return i.flatMap(e).forEach((e) => S.scope.add(e)), f.forEach((e) => S.retryKeys.add(e)), 0 === i.length && (S.all = !0), S.rerun = !0, S.promise;
				const k = {
					promise: Promise.resolve({
						attached: 0,
						conflicted: 0,
						failed: 0,
						remaining: 0,
						receipts: []
					}),
					scope: new Set(i.flatMap(e)),
					retryKeys: new Set(f),
					rerun: !1,
					all: 0 === i.length
				}, E = o ?? function(e) {
					const { username: t, selectedStudyId: a } = y.getState();
					return j.captureWorkspaceBinding(e, {
						signal: void 0,
						username: t,
						studyId: a
					});
				}(n);
				return k.promise = b(n, async () => {
					const i = {
						attached: 0,
						conflicted: 0,
						failed: 0,
						remaining: 0,
						receipts: []
					}, s = [], o = /* @__PURE__ */ new Map();
					try {
						do {
							k.rerun = !1;
							const f = await w(n), y = [.../* @__PURE__ */ new Set([...f.filter((t) => k.all || e({ filename: t }).some((e) => k.scope.has(e))), ...k.retryKeys])];
							if (k.retryKeys.clear(), 0 === y.length) continue;
							const b = await l(n, {
								participantKeys: y,
								includeIncomplete: !0
							}), j = [.../* @__PURE__ */ new Set([...b.map(r), ...y.filter((t) => !b.some((a) => e(a).includes(t)))])];
							for (const w of j) {
								const f = b.filter((e) => r(e) === w), j = [.../* @__PURE__ */ new Set([w, ...f.flatMap(e)])];
								let S = {
									attached: 0,
									conflicted: 0,
									failed: 0,
									remaining: 0,
									receipts: []
								};
								try {
									await c(n, E), S = await n.transaction("rw", [
										n.files,
										n.diaryEntries,
										n.stagedDiaryEntries,
										n.diaryOccurrences,
										n.diaryBindingDirty,
										n.projectMeta,
										n.walLog,
										n.auditLog,
										...p(n)
									], async () => {
										const i = {
											attached: 0,
											conflicted: 0,
											failed: 0,
											remaining: 0,
											receipts: []
										}, s = [];
										let o;
										try {
											o = await m([w], n, E), s.push(o.receipt), i.conflicted += o.conflicted, o.deferred && i.failed++;
										} catch {
											i.failed++;
										}
										const c = await l(n, {
											participantKeys: j,
											includeIncomplete: !0
										}), f = await v(n, c), p = new Set(c.map(r)), b = [.../* @__PURE__ */ new Set([w, ...c.flatMap(e)])], S = await h(n, b), k = [];
										for (const e of S) {
											const a = g(e.sourceKey, e.analysisDate, f), r = a.status === t.MATCHED ? a.file : null;
											if (!r?.id || o?.deferred) {
												i.remaining++;
												continue;
											}
											let c;
											try {
												c = await u(e, r, n, { enclosingAudit: !0 });
											} catch {
												i.failed++, i.remaining++;
												continue;
											}
											"conflict" === c.status && (i.conflicted++, s.push(c.receipt)), "target_changed" === c.status && i.failed++, "attached" === c.status ? (s.push(c.receipt), k.push(c.receipt), i.attached++) : i.remaining++;
										}
										k.length > 0 && await _(d("attach", k), E), i.receipts = s;
										for (const e of [
											"restaged",
											"moved",
											"mirrored",
											"unrecoverable"
										]) o?.[e] && (i[e] = o[e]);
										return i.failed || i.conflicted || await n.diaryBindingDirty.bulkDelete([...[.../* @__PURE__ */ new Set([
											w,
											...y.filter((e) => b.includes(e)),
											...S.map((e) => e.normalizedSourceKey)
										])].filter((e) => e === w || !p.has(e)).map((e) => a + e), ...c.filter((e) => r(e) === w).map((e) => e.id)]), i;
									});
								} catch {
									S.failed++;
								}
								o.set(w, S), s.push(...S.receipts);
								for (const e of [
									"attached",
									"moved",
									"restaged",
									"mirrored"
								]) S[e] && (i[e] = (i[e] ?? 0) + S[e]);
							}
						} while (k.rerun);
					} catch (f) {
						console.warn("[diary] recovery pass failed after committed work", f instanceof Error ? f.name : typeof f), i.failed++;
					}
					for (const e of o.values()) for (const t of [
						"conflicted",
						"failed",
						"remaining",
						"unrecoverable"
					]) e[t] && (i[t] = (i[t] ?? 0) + e[t]);
					return B.delete(n), {
						...i,
						receipts: s
					};
				}).catch((e) => {
					throw B.get(n) === k && B.delete(n), e;
				}), B.set(n, k), k.promise;
			}([], i, n, o);
		} catch {
			f = {
				attached: 0,
				conflicted: 0,
				failed: 1,
				remaining: 0,
				receipts: []
			};
		}
		return function(e, t) {
			if (t.failed) {
				const { receipts: e, ...a } = t;
				console.warn("[diary] Workspace recovery failed; retry on the next activation.", a);
			}
			if (C.has(t)) return x.get(e) ?? t;
			C.add(t);
			const a = function(e, t) {
				if (!e) return t;
				const a = (a) => (e[a] ?? 0) + (t[a] ?? 0), r = t.failed > 0 ? e : t, i = {
					attached: a("attached"),
					conflicted: r.conflicted,
					failed: t.failed,
					remaining: r.remaining,
					receipts: [...e.receipts, ...t.receipts]
				};
				for (const n of [
					"moved",
					"restaged",
					"mirrored"
				]) a(n) && (i[n] = a(n));
				return r.unrecoverable && (i.unrecoverable = r.unrecoverable), i;
			}(x.get(e), t);
			var r = a;
			return Boolean(r.failed || r.conflicted || r.attached || r.moved || r.restaged || r.mirrored) && (x.set(e, a), "undefined" != typeof window && window.dispatchEvent(new CustomEvent("diary-recovery-receipt", { detail: e }))), a;
		}(i, f);
	}(i, j.captureWorkspaceBinding(i, o));
}
export { W as recoverWorkspaceDiaryBindings };

import { An as e, In as t, Mn as a, Pn as r, T as n, Zt as s, f as o, jn as i, o as c, w as l } from "./schema-D8rqa1Y6.js";
import { a as u } from "./content-hash-CZ-UAlQR.js";
function d(e) {
	const t = e?.reason;
	return t instanceof Error ? t : new DOMException("Job cancelled", "AbortError");
}
function p(e, t) {
	return t ? t.aborted ? Promise.reject(d(t)) : new Promise((a, r) => {
		const n = () => r(d(t));
		t.addEventListener("abort", n, { once: !0 }), e.then(a, r).finally(() => t.removeEventListener("abort", n));
	}) : e;
}
const f = "undefined" != typeof process && !1;
let m = !1;
const w = {
	get basePath() {
		const e = "/sleep-scoring-wasm/", t = e.replace(/\/$/, ""), a = "undefined" != typeof window ? window.__CONFIG__?.basePath : void 0;
		return null == a ? t : "" !== t && a !== t ? (m || (m = !0, console.error(`[config] config.js basePath "${a}" does not match the build base "${e}"; using "${t}". Fix config.js or rebuild with VITE_BASE_PATH="${a}/".`)), t) : a;
	},
	get apiBaseUrl() {
		return `${this.basePath}/api/v1`;
	},
	get isDev() {
		return f;
	},
	get isProd() {
		return !f;
	}
};
var h = class extends i {
	workspaces;
	uiSettings;
	constructor(t) {
		super(t), this.version(1).stores({
			workspaces: "id, lastAccessedAt",
			uiSettings: "key, updatedAt"
		}), e(this);
	}
};
const g = new h("SleepScoringGlobal-wasm"), _ = "workspace-deleted:";
function y(e) {
	return `${_}${e}`;
}
async function v(e = g) {
	const t = await e.uiSettings.where("key").startsWith(_).primaryKeys();
	return new Set(t.map((e) => e.slice(18)));
}
async function b(e, t = []) {
	return g.transaction("rw", g.workspaces, g.uiSettings, async () => {
		const a = await v(), r = e.filter((e) => !a.has(e.dbName));
		return t.length > 0 && await g.workspaces.bulkDelete([...t]), r.length > 0 && await g.workspaces.bulkPut(r), r.length;
	});
}
const k = (e) => {
	let t;
	const a = /* @__PURE__ */ new Set(), r = (e, r) => {
		const n = "function" == typeof e ? e(t) : e;
		if (!Object.is(n, t)) {
			const e = t;
			t = (null != r ? r : "object" != typeof n || null === n) ? n : Object.assign({}, t, n), a.forEach((a) => a(t, e));
		}
	}, n = () => t, s = {
		setState: r,
		getState: n,
		getInitialState: () => o,
		subscribe: (e) => (a.add(e), () => a.delete(e))
	}, o = t = e(r, n, s);
	return s;
}, S = (e) => e ? k(e) : k;
/**
* @license React
* react.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var E = a((e) => {
	var t = Symbol.for("react.transitional.element"), a = Symbol.for("react.consumer"), r = Symbol.for("react.context"), n = Symbol.for("react.forward_ref"), s = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	}, o = Object.assign, i = {};
	function c(e, t, a) {
		this.props = e, this.context = t, this.refs = i, this.updater = a || s;
	}
	function l() {}
	function u(e, t, a) {
		this.props = e, this.context = t, this.refs = i, this.updater = a || s;
	}
	c.prototype.isReactComponent = {}, c.prototype.setState = function(e, t) {
		if ("object" != typeof e && "function" != typeof e && null != e) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, e, t, "setState");
	}, c.prototype.forceUpdate = function(e) {
		this.updater.enqueueForceUpdate(this, e, "forceUpdate");
	}, l.prototype = c.prototype;
	var d = u.prototype = new l();
	d.constructor = u, o(d, c.prototype), d.isPureReactComponent = !0, Array.isArray;
	var p = {
		H: null,
		A: null,
		T: null,
		S: null
	}, f = Object.prototype.hasOwnProperty;
	e.createContext = function(e) {
		return (e = {
			$$typeof: r,
			_currentValue: e,
			_currentValue2: e,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		}).Provider = e, e.Consumer = {
			$$typeof: a,
			_context: e
		}, e;
	}, e.createElement = function(e, a, r) {
		var n, s = {}, o = null;
		if (null != a) for (n in void 0 !== a.key && (o = "" + a.key), a) f.call(a, n) && "key" !== n && "__self" !== n && "__source" !== n && (s[n] = a[n]);
		var i = arguments.length - 2;
		if (1 === i) s.children = r;
		else if (1 < i) {
			for (var c = Array(i), l = 0; l < i; l++) c[l] = arguments[l + 2];
			s.children = c;
		}
		if (e && e.defaultProps) for (n in i = e.defaultProps) void 0 === s[n] && (s[n] = i[n]);
		return function(e, a, r) {
			var n = r.ref;
			return {
				$$typeof: t,
				type: e,
				key: a,
				ref: void 0 !== n ? n : null,
				props: r
			};
		}(e, o, s);
	}, e.forwardRef = function(e) {
		return {
			$$typeof: n,
			render: e
		};
	}, e.useCallback = function(e, t) {
		return p.H.useCallback(e, t);
	}, e.useContext = function(e) {
		return p.H.useContext(e);
	}, e.useDebugValue = function() {}, e.useRef = function(e) {
		return p.H.useRef(e);
	}, e.useSyncExternalStore = function(e, t, a) {
		return p.H.useSyncExternalStore(e, t, a);
	};
}), R = a((e, t) => {
	t.exports = E();
}), A = t(R(), 1);
const I = (e) => e, O = (e) => {
	const t = S(e), a = (e) => function(e, t = I) {
		const a = A.useSyncExternalStore(e.subscribe, A.useCallback(() => t(e.getState()), [e, t]), A.useCallback(() => t(e.getInitialState()), [e, t]));
		return A.useDebugValue(a), a;
	}(t, e);
	return Object.assign(a, t), a;
}, P = (e) => e ? O(e) : O, C = {
	IMPORT: "import",
	REPROCESS: "reprocess",
	SCORED_VARIANT_WARM: "scored-variant-warm",
	VARIANT_RECOVERY: "variant-recovery",
	GGIR_RECOMPUTE: "ggir-recompute",
	GGIR_RECOVERY: "ggir-recovery",
	GGIR_CORRECTED_WARM: "ggir-corrected-warm",
	NIGHT_DIFFICULTY: "night-difficulty",
	PHYSICAL_ACTIVITY: "physical-activity",
	PLACEMENT: "placement",
	AUTO_SCORE: "auto-score",
	PLACEMENT_RECOVERY: "placement-recovery",
	BACKUP_EXPORT: "backup-export",
	BACKUP_RESTORE: "backup-restore",
	RESCORE: "rescore",
	EXPORT: "export",
	DIARY_VALIDATE: "diary-validate",
	DIARY_REPAIR: "diary-repair",
	DIARY_IMPORT: "diary-import",
	HDCZA_REFRESH: "hdcza-refresh",
	SYNC: "sync",
	WAL_TRIM: "wal-trim",
	MODEL_DOWNLOAD: "model-download",
	NONWEAR_IMPORT: "nonwear-import",
	AUDIT_EXPORT: "audit-export"
}, T = {
	QUEUED: "queued",
	RUNNING: "running",
	JOINED: "joined",
	RERUN: "rerun",
	CANCELLED: "cancelled",
	COMMITTED: "committed",
	DONE: "done",
	FAILED: "failed",
	ELSEWHERE: "elsewhere"
}, D = {
	[C.IMPORT]: "user",
	[C.REPROCESS]: "user",
	[C.SCORED_VARIANT_WARM]: "automatic",
	[C.VARIANT_RECOVERY]: "automatic",
	[C.GGIR_RECOMPUTE]: "automatic",
	[C.GGIR_RECOVERY]: "automatic",
	[C.GGIR_CORRECTED_WARM]: "user",
	[C.NIGHT_DIFFICULTY]: "automatic",
	[C.PHYSICAL_ACTIVITY]: "automatic",
	[C.PLACEMENT]: "automatic",
	[C.AUTO_SCORE]: "automatic",
	[C.PLACEMENT_RECOVERY]: "automatic",
	[C.BACKUP_EXPORT]: "user",
	[C.BACKUP_RESTORE]: "user",
	[C.RESCORE]: "user",
	[C.EXPORT]: "user",
	[C.DIARY_VALIDATE]: "user",
	[C.DIARY_REPAIR]: "user",
	[C.DIARY_IMPORT]: "user",
	[C.HDCZA_REFRESH]: "automatic",
	[C.SYNC]: "automatic",
	[C.WAL_TRIM]: "automatic",
	[C.MODEL_DOWNLOAD]: "user",
	[C.NONWEAR_IMPORT]: "user",
	[C.AUDIT_EXPORT]: "user"
};
function N(e) {
	return "automatic" === D[e];
}
function L(e) {
	return [
		C.WAL_TRIM,
		C.PLACEMENT,
		C.PLACEMENT_RECOVERY,
		C.NIGHT_DIFFICULTY,
		C.PHYSICAL_ACTIVITY,
		C.VARIANT_RECOVERY,
		C.GGIR_RECOVERY
	].includes(e);
}
const j = P((e, t) => ({
	jobs: {},
	localProcessingJobId: null,
	localProcessingProgress: null,
	isLocalProcessing: !1,
	setLocalProcessingProgress: (t) => e({ localProcessingProgress: t }),
	setIsLocalProcessing: (t) => e({ isLocalProcessing: t }),
	update: (t, a) => e((e) => {
		const r = {
			...e.jobs[t],
			...a
		};
		r.status === T.FAILED ? r.visible = !0 : N(r.kind) && (r.visible = !1);
		const n = { ...e.jobs };
		r.status === T.FAILED && Reflect.deleteProperty(n, `${t}:failure`);
		const s = e.jobs[t];
		if (s?.status === T.FAILED && r.status !== T.FAILED && M(s)) {
			const e = `${t}:failure`;
			n[e] = {
				...s,
				id: e,
				noticeOnly: !0
			};
		}
		W(r) || Reflect.deleteProperty(n, t), r.status === T.DONE && N(r.kind) || (n[t] = r);
		const o = Object.values(n).filter((e) => !W(e) && e.status !== T.FAILED);
		for (const t of o.slice(0, Math.max(0, o.length - 5))) Reflect.deleteProperty(n, t.id);
		return {
			jobs: n,
			...void 0 !== a.detail && e.localProcessingJobId === t ? { localProcessingProgress: a.detail } : {}
		};
	}),
	cancel: (e) => {
		const a = t().jobs[e];
		a?.controller.abort(), a && t().update(e, {});
	},
	dismiss: (t) => e((e) => {
		const a = { ...e.jobs };
		return Reflect.deleteProperty(a, t), { jobs: a };
	})
}));
function G(e) {
	return e.localProcessingJobId ? e.jobs[e.localProcessingJobId] : void 0;
}
function M(e) {
	return !e.noticeOnly;
}
function W(e) {
	return e?.status === T.QUEUED || e?.status === T.RUNNING;
}
const x = (e) => !!e.dispatchFromDevtools && "function" == typeof e.dispatch, U = /* @__PURE__ */ new Map(), F = (e) => {
	const t = U.get(e);
	return t ? Object.fromEntries(Object.entries(t.stores).map(([e, t]) => [e, t.getState()])) : {};
}, V = /^at (?:new |async )?(.+?) \(/, H = /^([^@]+)@/;
function $(e) {
	var t, a, r;
	if (!e) return;
	const n = e.split("\n"), s = n.findIndex((e) => e.includes("api.setState"));
	if (s < 0) return;
	const o = (null == (t = n[s + 1]) ? void 0 : t.trim()) || "";
	return (null == (a = V.exec(o)) ? void 0 : a[1]) || (null == (r = H.exec(o)) ? void 0 : r[1]);
}
const z = (e, t = {}) => (a, r, n) => {
	const { enabled: s, anonymousActionType: o, store: i, ...c } = t;
	let l;
	try {
		l = null != s && s && window.__REDUX_DEVTOOLS_EXTENSION__;
	} catch (w) {}
	if (!l) return e(a, r, n);
	const { connection: u, ...d } = ((e, t, a) => {
		if (void 0 === e) return {
			type: "untracked",
			connection: t.connect(a)
		};
		const r = U.get(a.name);
		if (r) return {
			type: "tracked",
			store: e,
			...r
		};
		const n = {
			connection: t.connect(a),
			stores: {}
		};
		return U.set(a.name, n), {
			type: "tracked",
			store: e,
			...n
		};
	})(i, l, c);
	let p = !0;
	n.setState = (e, t, s) => {
		const l = a(e, t);
		if (!p) return l;
		const d = void 0 === s ? { type: o || $((/* @__PURE__ */ new Error()).stack) || "anonymous" } : "string" == typeof s ? { type: s } : s;
		return void 0 === i ? (u?.send(d, r()), l) : (u?.send({
			...d,
			type: `${i}/${d.type}`
		}, {
			...F(c.name),
			[i]: n.getState()
		}), l);
	}, n.devtools = { cleanup: () => {
		u && "function" == typeof u.unsubscribe && u.unsubscribe(), ((e, t) => {
			if (void 0 === t) return;
			const a = U.get(e);
			a && (delete a.stores[t], 0 === Object.keys(a.stores).length && U.delete(e));
		})(c.name, i);
	} };
	const f = (...e) => {
		const t = p;
		p = !1, a(...e), p = t;
	}, m = e(n.setState, r, n);
	if ("untracked" === d.type ? u?.init(m) : (d.stores[d.store] = n, u?.init(Object.fromEntries(Object.entries(d.stores).map(([e, t]) => [e, e === d.store ? m : t.getState()])))), x(n)) {
		const e = n.dispatch;
		n.dispatch = (...t) => {
			e(...t);
		};
	}
	return u.subscribe((e) => {
		var t;
		switch (e.type) {
			case "ACTION": return "string" != typeof e.payload ? void console.error("[zustand devtools middleware] Unsupported action format") : B(e.payload, (e) => {
				if ("__setState" === e.type) {
					if (void 0 === i) return void f(e.state);
					1 !== Object.keys(e.state).length && console.error("\n                    [zustand devtools middleware] Unsupported __setState action format.\n                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),\n                    and value of this only key should be a state object. Example: { \"type\": \"__setState\", \"state\": { \"abc123Store\": { \"foo\": \"bar\" } } }\n                    ");
					const t = e.state[i];
					if (null == t) return;
					JSON.stringify(n.getState()) !== JSON.stringify(t) && f(t);
					return;
				}
				x(n) && n.dispatch(e);
			});
			case "DISPATCH":
				switch (e.payload.type) {
					case "RESET": return f(m), void 0 === i ? null == u ? void 0 : u.init(n.getState()) : null == u ? void 0 : u.init(F(c.name));
					case "COMMIT": return void 0 === i ? void u?.init(n.getState()) : null == u ? void 0 : u.init(F(c.name));
					case "ROLLBACK": return B(e.state, (e) => {
						if (void 0 === i) return f(e), void u?.init(n.getState());
						f(e[i]), u?.init(F(c.name));
					});
					case "JUMP_TO_STATE":
					case "JUMP_TO_ACTION": return B(e.state, (e) => {
						void 0 !== i ? JSON.stringify(n.getState()) !== JSON.stringify(e[i]) && f(e[i]) : f(e);
					});
					case "IMPORT_STATE": {
						const { nextLiftedState: a } = e.payload, r = null == (t = a.computedStates.slice(-1)[0]) ? void 0 : t.state;
						if (!r) return;
						f(void 0 === i ? r : r[i]), u?.send(null, a);
						return;
					}
					case "PAUSE_RECORDING": return p = !p;
				}
				return;
		}
	}), m;
}, B = (e, t) => {
	let a;
	try {
		a = JSON.parse(e);
	} catch (r) {
		console.error("[zustand devtools middleware] Could not parse the received json", r);
	}
	void 0 !== a && t(a);
};
function Y(e, t) {
	let a;
	try {
		a = e();
	} catch (r) {
		return;
	}
	return {
		getItem: (e) => {
			var r;
			const n = (e) => null === e ? null : JSON.parse(e, null == t ? void 0 : t.reviver), s = null != (r = a.getItem(e)) ? r : null;
			return s instanceof Promise ? s.then(n) : n(s);
		},
		setItem: (e, r) => a.setItem(e, JSON.stringify(r, null == t ? void 0 : t.replacer)),
		removeItem: (e) => a.removeItem(e)
	};
}
const q = (e) => (t) => {
	try {
		const a = e(t);
		return a instanceof Promise ? a : {
			then: (e) => q(e)(a),
			catch(e) {
				return this;
			}
		};
	} catch (a) {
		return {
			then(e) {
				return this;
			},
			catch: (e) => q(e)(a)
		};
	}
}, J = (e, t) => (a, r, n) => {
	let s = {
		storage: Y(() => window.localStorage),
		partialize: (e) => e,
		version: 0,
		merge: (e, t) => ({
			...t,
			...e
		}),
		...t
	}, o = !1, i = 0;
	const c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set();
	let u = s.storage;
	if (!u) return e((...e) => {
		console.warn(`[zustand persist middleware] Unable to update item '${s.name}', the given storage is currently unavailable.`), a(...e);
	}, r, n);
	const d = () => {
		const e = s.partialize({ ...r() });
		return u.setItem(s.name, {
			state: e,
			version: s.version
		});
	}, p = n.setState;
	n.setState = (e, t) => (p(e, t), d());
	const f = e((...e) => (a(...e), d()), r, n);
	let m;
	n.getInitialState = () => f;
	const w = () => {
		var e, t;
		if (!u) return;
		const n = ++i;
		o = !1, c.forEach((e) => {
			var t;
			return e(null != (t = r()) ? t : f);
		});
		const p = (null == (t = s.onRehydrateStorage) ? void 0 : t.call(s, null != (e = r()) ? e : f)) || void 0;
		return q(u.getItem.bind(u))(s.name).then((e) => {
			if (e) {
				if ("number" != typeof e.version || e.version === s.version) return [!1, e.state];
				if (s.migrate) {
					const t = s.migrate(e.state, e.version);
					return t instanceof Promise ? t.then((e) => [!0, e]) : [!0, t];
				}
				console.error("State loaded from storage couldn't be migrated since no migrate function was provided");
			}
			return [!1, void 0];
		}).then((e) => {
			var t;
			if (n !== i) return;
			const [o, c] = e;
			return m = s.merge(c, null != (t = r()) ? t : f), a(m, !0), o ? d() : void 0;
		}).then(() => {
			n === i && (p?.(r(), void 0), m = r(), o = !0, l.forEach((e) => e(m)));
		}).catch((e) => {
			n === i && p?.(void 0, e);
		});
	};
	return n.persist = {
		setOptions: (e) => {
			s = {
				...s,
				...e
			}, e.storage && (u = e.storage);
		},
		clearStorage: () => {
			++i, u?.removeItem(s.name);
		},
		getOptions: () => s,
		rehydrate: () => w(),
		hasHydrated: () => o,
		onHydrate: (e) => (c.add(e), () => {
			c.delete(e);
		}),
		onFinishHydration: (e) => (l.add(e), () => {
			l.delete(e);
		})
	}, s.skipHydration || w(), m || f;
};
function K(e) {
	const t = e.split(/[/\\]/);
	return t[t.length - 1] || e;
}
var X = class e {
	path;
	name;
	lastModified;
	fileSize;
	start;
	end;
	constructor(e) {
		this.path = e.path, this.name = e.name, this.fileSize = e.fileSize, this.lastModified = e.lastModified, this.start = e.start ?? 0, this.end = e.end ?? e.fileSize;
	}
	static async fromPath(t) {
		const { stat: a } = await import("./dist-js-CMqw3VI6.js"), r = await a(t), n = r.mtime ? r.mtime.getTime() : 0;
		return new e({
			path: t,
			name: K(t),
			fileSize: r.size,
			lastModified: n
		});
	}
	get size() {
		return this.end - this.start;
	}
	slice(t, a) {
		const { start: r, end: n } = function(e, t, a) {
			const r = (t, a) => void 0 === t ? a : t < 0 ? Math.max(e + t, 0) : Math.min(t, e), n = r(t, 0), s = r(a, e);
			return {
				start: n,
				end: Math.max(n, s)
			};
		}(this.size, t, a);
		return new e({
			path: this.path,
			name: this.name,
			fileSize: this.fileSize,
			lastModified: this.lastModified,
			start: this.start + r,
			end: this.start + n
		});
	}
	async arrayBuffer() {
		const e = this.size;
		if (e <= 0) return /* @__PURE__ */ new ArrayBuffer(0);
		const { open: t, SeekMode: a } = await import("./dist-js-CMqw3VI6.js"), r = await t(this.path, { read: !0 });
		try {
			await r.seek(this.start, a.Start);
			const t = new Uint8Array(e);
			let n = 0;
			for (; n < e;) {
				const e = await r.read(t.subarray(n));
				if (null === e || 0 === e) break;
				n += e;
			}
			return n === e ? t.buffer : t.buffer.slice(0, n);
		} finally {
			await r.close();
		}
	}
	async text() {
		const e = await this.arrayBuffer();
		return new TextDecoder().decode(e);
	}
};
async function Z(e) {
	return u(e);
}
const Q = [
	"csv",
	"gt3x",
	"bin",
	"bz2",
	"tbz2"
], ee = "ggirImportRefusals", te = "already-imported-different-content", ae = "local-storage", re = "GGIR output folder", ne = "ggir-folder", se = "import-in-progress", oe = {
	workspace: {
		label: "workspace changed",
		durableRefusal: !1
	},
	"csv-settings": {
		label: "CSV settings",
		durableRefusal: !1
	},
	"unsupported-format": {
		label: "unsupported file format",
		durableRefusal: !1
	},
	"empty-file": {
		label: "empty file",
		durableRefusal: !1
	},
	"invalid-data": {
		label: "invalid file data",
		durableRefusal: !1
	},
	[ae]: {
		label: "local storage",
		durableRefusal: !1
	},
	permission: {
		label: "permission",
		durableRefusal: !1
	},
	"browser-memory": {
		label: "browser memory",
		durableRefusal: !1
	},
	"time-limit": {
		label: "too large or slow for this browser",
		durableRefusal: !1
	},
	[se]: {
		label: "earlier import still holds this file; try again in about 2 minutes",
		durableRefusal: !1
	},
	"decoder-crash": {
		label: "the decoder crashed on this file",
		durableRefusal: !1
	},
	"ggir-no-part4": {
		label: "GGIR made no Part 4 for this recording and an earlier version of the app refused it; import the folder again",
		durableRefusal: !0
	},
	"ggir-not-read": {
		label: "a GGIR file this recording needs could not be read; the receipt names it",
		durableRefusal: !0
	},
	"ggir-corrected-not-available": {
		label: "refused by an earlier version of the app; import the folder again",
		durableRefusal: !0
	},
	[te]: {
		label: "already imported with different content and kept as it was; to replace it first use Export backup on the Workspace tab of the Files page then delete the earlier import on the Files page and import it again",
		durableRefusal: !0
	},
	[ne]: {
		label: "GGIR output folder cannot be imported; select the whole folder containing GGIR configuration and milestones",
		durableRefusal: !0
	},
	"aw5-unreadable": {
		label: "the Actiwatch database could not be read in this browser; the file is damaged or is not an Actiware database",
		durableRefusal: !1
	},
	"aw5-memory": {
		label: "the Actiwatch database could not be read in this browser; it ran out of memory; close other tabs or import fewer databases at once",
		durableRefusal: !1
	},
	"stale-app": {
		label: "this tab could not load part of the app because a newer version was installed in another tab; reload the page and try again",
		durableRefusal: !1
	},
	"unsupported-epoch": {
		label: `this recording epoch length cannot be stored; only ${n.join(" or ")} second epochs and shorter epochs that divide ${String(l)} seconds can be imported`,
		durableRefusal: !1
	},
	"processing-runtime": {
		label: "processing runtime",
		durableRefusal: !1
	}
}, ie = new Map(Object.entries(oe).map(([e, { label: t }]) => [t.toLowerCase(), e])), ce = /categor(?:y|ies): ([a-z0-9; ]+?)(?: \(\d+\))?[.,]/u;
const ue = Object.keys({
	workspace: null,
	"csv-settings": "/csv-import",
	"unsupported-format": "/csv-import",
	"empty-file": null,
	"invalid-data": "/csv-import",
	[ae]: null,
	permission: null,
	"browser-memory": null,
	"time-limit": null,
	[se]: null,
	"decoder-crash": null,
	"ggir-no-part4": null,
	"ggir-not-read": null,
	"ggir-corrected-not-available": null,
	[te]: null,
	[ne]: null,
	"aw5-unreadable": null,
	"aw5-memory": null,
	"stale-app": null,
	"unsupported-epoch": null,
	"processing-runtime": "/settings/processing"
});
function de(e) {
	return oe[e].label;
}
function pe(e) {
	return de(function(e) {
		if (e instanceof Error && "category" in e && "string" == typeof e.category && Object.hasOwn(oe, e.category)) return e.category;
		const t = function(e) {
			try {
				return e instanceof Error ? e.message : "string" == typeof e ? e : "";
			} catch {
				return "";
			}
		}(e).toLowerCase();
		if (Object.hasOwn(oe, t)) return t;
		const a = ie.get(t) ?? ie.get(ce.exec(t)?.[1] ?? "");
		return void 0 !== a ? a : t.includes("timed out during") ? "time-limit" : /failed to fetch dynamically imported module|error loading dynamically imported module|importing a module script failed/u.test(t) ? "stale-app" : t.includes("already being imported") ? "import-in-progress" : t.startsWith("wasm panic in ") ? "decoder-crash" : /workspace|scope changed|no longer active/u.test(t) ? "workspace" : /csv settings|column-mapped|column mapping|mapping .*required|settings .*incomplete|review data settings/u.test(t) ? "csv-settings" : /unsupported|not supported|unimplemented source-profile|unknown file (?:type|format)/u.test(t) ? "unsupported-format" : /out of memory|allocation failed|invalid array length|exceeds the v1 limit|too large (?:to process|for in-browser memory)/u.test(t) || /\bunreachable\b/u.test(t) && !t.startsWith("wasm panic in ") ? "browser-memory" : /empty|no data rows|did not contain any .*epochs/u.test(t) ? "empty-file" : /quota|indexeddb|dexie|database|storage|persist|saving|disk/u.test(t) ? "local-storage" : /permission|denied|unauthori[sz]ed|not allowed/u.test(t) ? "permission" : /parse|csv|row|column|timestamp|header|date|\btime\b|corrupt|invalid|malformed|decompress|archive|rdata/u.test(t) ? "invalid-data" : "processing-runtime";
	}(e));
}
const fe = [
	"parse",
	"score",
	"nonwear",
	"save",
	"variants"
], me = "A recording already in this workspace was offered again, changed. It was not imported, and nothing was overwritten: the file and its scoring are as they were. To use the changed recording, export your work first, then delete the file and import it again.", we = {
	reading: [0, 30],
	parsing: [0, 45],
	epoching: [30, 50],
	scoring: [55, 72],
	nonwear: [72, 82],
	ggir: [82, 85],
	storing: [85, 98],
	variants: [98, 100],
	complete: [100, 100]
};
function he(e, t) {
	if (null === t) return -1;
	const [a, r] = we[e];
	return a + Math.max(0, Math.min(1, t)) * (r - a);
}
function ge(e, t) {
	return "gt3x" === e || "geneactiv_bin" === e || "nhanes" === e || t ? [
		"read",
		"parse",
		"epochs",
		"counts",
		"score",
		"nonwear",
		"ggir",
		"save",
		"variants"
	] : [
		"read",
		"parse",
		"score",
		"nonwear",
		"save",
		"variants"
	];
}
Object.keys(we);
const _e = {
	high: "high",
	medium: "medium",
	low: "low"
}, ye = {
	off: "off",
	actiware: "actiware",
	screens: "screens"
}, ve = {
	SADEH_1994_ACTILIFE: "sadeh_1994_actilife",
	SADEH_1994_ORIGINAL: "sadeh_1994_original",
	SADEH_1994_GGIR: "sadeh_1994_ggir",
	COLE_KRIPKE_1992_ACTILIFE: "cole_kripke_1992_actilife",
	COLE_KRIPKE_1992_ORIGINAL: "cole_kripke_1992_original",
	COLE_KRIPKE_1992_GGIR: "cole_kripke_1992_ggir",
	TENSOR_MAJORITY_VOTE: "tensor_majority_vote",
	CONSENSUS_MAJORITY_VOTE: "consensus_majority_vote",
	LSTM_SLEEP_WAKE: "lstm_sleep_wake",
	GGIR_HASIB_VAN_HEES_2015: "ggir_hasib_van_hees_2015",
	GGIR_HASIB_SADEH_1994: "ggir_hasib_sadeh_1994",
	GGIR_HASIB_GALLAND_2012: "ggir_hasib_galland_2012",
	GGIR_HASIB_COLE_KRIPKE_1992: "ggir_hasib_cole_kripke_1992",
	GGIR_HASIB_OAKLEY_1997: "ggir_hasib_oakley_1997",
	GGIR_HASIB_NOT_WORN: "ggir_hasib_not_worn",
	CHOI_2011_NONWEAR: "choi_2011_nonwear",
	DETACH_NONWEAR: "detach_nonwear",
	UCSD_SCRIPPS_2010: "ucsd_scripps_2010",
	SAZONOV_2004: "sazonov_2004",
	PRESCHOOL_FREE_LIVING_RF_3_5: "preschool_free_living_rf_3_5"
}, be = {
	configured_scoring: "configured_scoring",
	actiware: "actiware"
}, ke = {
	pim: "pim",
	zcm: "zcm",
	tat: "tat",
	neishabouri: "neishabouri",
	zero_crossing: "zero_crossing",
	mad: "mad",
	hfen: "hfen"
}, Se = {
	month_first: "month_first",
	day_first: "day_first"
}, Ee = {
	night_date: "night_date",
	period_start_day: "period_start_day",
	explicit_only: "explicit_only",
	ask_per_night: "ask_per_night"
}, Re = {
	cannot_be_read: "cannot_be_read",
	sources_disagree: "sources_disagree",
	needs_decision: "needs_decision",
	date_filled: "date_filled",
	sources_agree: "sources_agree",
	as_written: "as_written"
}, Ae = {
	explicit_only: "explicit_only",
	sleep_date_same_day: "sleep_date_same_day",
	sleep_date_chronology: "sleep_date_chronology"
}, Ie = {
	main_sleep: "main_sleep",
	naps: "naps",
	nonwear: "nonwear"
}, Oe = {
	ask: "ask",
	first_occurrence: "first_occurrence",
	mark_unusable: "mark_unusable"
}, Pe = {
	mark_unusable: "mark_unusable",
	shift_forward_hour: "shift_forward_hour"
}, Ce = {
	sleep_periods: "sleep_periods",
	rest_intervals: "rest_intervals"
}, Te = {
	number_60s_epochs: "60s_epochs",
	ggir_5s: "ggir_5s"
}, De = {
	HDCZA: "HDCZA",
	HorAngle: "HorAngle",
	NotWorn: "NotWorn",
	MotionWare: "MotionWare",
	HLRB: "HLRB"
}, Ne = {
	choi_2011: "choi_2011",
	flat_activity: "flat_activity",
	gt3x_capsense: "gt3x_capsense",
	actiware_off_wrist: "actiware_off_wrist",
	detach_nonwear: "detach_nonwear",
	van_hees_2013: "van_hees_2013",
	van_hees_2023: "van_hees_2023",
	ggir_saved: "ggir_saved",
	ggir_part2_invalid: "ggir_part2_invalid",
	choi_2012: "choi_2012",
	troiano_2008: "troiano_2008",
	ahmadi_2020: "ahmadi_2020",
	skovgaard_2023: "skovgaard_2023"
}, Le = {
	PHYSICAL_ACTIVITY: "physical_activity",
	SLEEP_DIARY: "sleep_diary",
	CSV_IMPORT: "csv_import",
	PRESET_MANAGEMENT: "preset_management",
	NONWEAR_TIME: "nonwear_time",
	CONSENSUS_REVIEW: "consensus_review",
	ANALYSIS_ISSUES: "analysis_issues"
}, je = {
	use_source_a: "use_source_a",
	use_source_b: "use_source_b",
	intersection: "intersection",
	union: "union",
	source_b_bounded_by_source_a: "source_b_bounded_by_source_a",
	sanity_clamp_source_b_to_source_a: "sanity_clamp_source_b_to_source_a"
}, Ge = {
	diary: "diary",
	hdcza: "hdcza",
	l5: "l5",
	selected_scorer_first_last: "selected_scorer_first_last",
	selected_scorer_longest_bout: "selected_scorer_longest_bout",
	quiet_bout: "quiet_bout",
	event_marker: "event_marker",
	actiware_rest_interval: "actiware_rest_interval",
	none: "none"
}, Me = {
	evening_onset: "evening_onset",
	morning_offset: "morning_offset",
	daytime: "daytime"
}, We = {
	NOON_OFFSET_HOURS: 12,
	ANALYSIS_WINDOW_HOURS: 24,
	CONTEXT_WINDOW_HOURS: 48,
	MORNING_OFFSET_ROLLOVER_PAD_HOURS: 6
}, xe = {
	MAX_SLEEP_PERIODS_PER_DAY: 4,
	MAX_NONWEAR_PERIODS_PER_DAY: 10,
	EPOCH_DURATION_SECONDS: 60
}, Ue = {
	sadeh_1994_actilife: "1",
	sadeh_1994_original: "1",
	sadeh_1994_ggir: "1",
	cole_kripke_1992_actilife: "1",
	cole_kripke_1992_original: "2",
	cole_kripke_1992_ggir: "1",
	tensor_majority_vote: "1",
	consensus_majority_vote: "1",
	lstm_sleep_wake: "1",
	ggir_hasib_van_hees_2015: "1",
	ggir_hasib_sadeh_1994: "1",
	ggir_hasib_galland_2012: "1",
	ggir_hasib_cole_kripke_1992: "1",
	ggir_hasib_oakley_1997: "1",
	ggir_hasib_not_worn: "1",
	choi_2011_nonwear: "1",
	detach_nonwear: "1",
	ucsd_scripps_2010: "1",
	sazonov_2004: "1",
	preschool_free_living_rf_3_5: "1"
};
function Fe(e) {
	const t = Ue[e];
	if (void 0 === t) throw new Error(`no implementation_version for ${e}`);
	return t;
}
function Ve(e) {
	return Object.hasOwn(Ue, e) ? e : null;
}
var He = class extends Error {
	name = "GgirResultsBundleError";
	category = ne;
	folderName;
	fileName;
	constructor(e, t, a) {
		super(e), this.folderName = t, this.fileName = a;
	}
};
const $e = /* @__PURE__ */ new WeakMap(), ze = /* @__PURE__ */ new WeakMap(), Be = /* @__PURE__ */ new WeakMap();
function Ye(e, t) {
	const a = new File([], e);
	return Be.set(a, t instanceof He ? t : new He(t ? "The GGIR output folder could not be read. Check folder access and open it again." : "The GGIR output folder is empty or contains no supported activity files.", e)), a;
}
function qe(e) {
	return $e.get(e);
}
function Je(e, t) {
	ze.set(e, t);
}
function Ke(e) {
	const t = ze.get(e);
	if (t) return t;
	const a = e.webkitRelativePath;
	return "string" == typeof a && a ? a : e.name;
}
function Xe(e, t) {
	return /\.csv$/iu.test(e.name) && Ke(e) !== e.name ? new He("This CSV table could not be read as activity data. GGIR imports require the whole output folder containing meta/ and config.csv.", void 0, e.name) : t instanceof Error ? t : new Error(t);
}
function Ze(e, t = !1) {
	const a = e.replace(/\\/gu, "/");
	return !/(^|\/)(?:\._[^/]*|__MACOSX)(?:\/|$)/iu.test(a) && (t || !/(^|\/)(?:ms5\.outraw|sib\.reports|sleep\.qc)(?:\/|$)/iu.test(a));
}
function Qe(e) {
	const t = e.replace(/\\/g, "/").split("/").filter(Boolean), a = t.indexOf("meta");
	return a >= 0 && a < t.length - 1 ? t.slice(0, a).join("/") : null;
}
function et(e) {
	return t = rt(e), /\.(rdata|rda)$/iu.test(t) ? Qe(e) : null;
	var t;
}
function tt(e) {
	const t = e.map((e) => e.replace(/\\/gu, "/")).filter((e) => Ze(e, !0)), a = new Set(t.map(et).filter((e) => null !== e)), r = /* @__PURE__ */ new Map();
	for (const n of t) {
		const e = Qe(n);
		if (null === e || !a.has(e)) continue;
		const t = r.get(e) ?? [];
		t.push(n.slice(e ? e.length + 1 : 0)), r.set(e, t);
	}
	for (const [n, s] of r) {
		const e = n ? rt(n) : void 0, a = [...new Set(s.filter((e) => e.split("/").length > 2).map((e) => e.split("/")[1] ?? "").filter(Boolean))].sort().map((e) => `meta/${e}`).join(", ") || "no part folders", r = n ? `${n}/` : "";
		if (!t.some((e) => e.startsWith(r) && "config.csv" === e.slice(r.length).toLowerCase())) throw new He(`The GGIR output has no config.csv (found ${a}). GGIR writes config.csv next to meta/; add it to the folder and import again.`, e);
		for (const t of [
			"basic",
			"ms2.out",
			"ms3.out",
			"ms4.out",
			"ms5.out"
		]) {
			const a = `meta/${t}/`, r = s.filter((e) => e.startsWith(a)).map((e) => e.slice(a.length)).find((e) => e.includes("/"))?.split("/")[0];
			if (r) throw new He(`meta/${t} contains a folder ${r}/ instead of ${"basic" === t ? "meta_*.RData" : "*.RData"} files: move its files up one level, as GGIR writes them.`, e);
		}
		if (!s.some((e) => /^meta\/basic\/meta_[^/]+\.(?:rdata|rda)$/iu.test(e))) throw new He(`meta/basic ${s.some((e) => e.startsWith("meta/basic/")) ? "contains no meta_*.RData files" : "is missing"} (found ${a}). Part 1 files (meta_*.RData) are needed.`, e);
	}
}
function at(e) {
	return {
		...e.desiredTz ? { desiredtz: e.desiredTz } : {},
		...e.configTz ? { configtz: e.configTz } : {},
		..."boolean" == typeof e.imputeTimegaps ? { imputeTimegaps: e.imputeTimegaps } : {}
	};
}
function rt(e) {
	const t = e.replace(/\\/g, "/").split("/");
	return t[t.length - 1] ?? e;
}
function nt() {
	return s;
}
s.join(" · ");
const st = [
	{
		key: "native_raw",
		label: "Native raw / archive",
		modeLabel: "Local parser",
		items: [
			"ActiGraph CSV / GT3X",
			"GENEActiv raw CSV / BIN",
			"NHANES PAX80 archives"
		]
	},
	{
		key: "mapped_vendor_csv",
		label: "Mapped vendor CSV",
		modeLabel: "Column map",
		items: [
			"ActLumus CSV",
			"ActTrust CSV",
			"Axivity",
			"ActivPAL",
			"Actical",
			"Philips Actiwatch / Spectrum CSV",
			"MotionWatch",
			"Activinsights",
			"Movisens",
			"Shimmer",
			"GaitUp",
			"Consumer wearables",
			"Other vendor epoch CSV"
		]
	},
	{
		key: "derived_sidecars",
		label: "Derived CSV imports",
		modeLabel: "Mapped or injected",
		items: [
			"GGIR meta RData",
			"GGIR output folder or .zip (Parts 1–5 + config.csv)",
			"GGIR 60s epoch CSV",
			"GGIR Part 5 day summaries",
			"MIMS metric columns"
		]
	},
	{
		key: "server_native_light",
		label: "Server-native light",
		modeLabel: "Server parser",
		items: [
			"Condor ActLumus TXT",
			"Condor ActTrust TXT",
			"CamNtech Actiwatch AWD"
		]
	}
].filter((e) => "Server parser" !== e.modeLabel);
function ot(e) {
	return void 0 !== (t = e, Be.get(t)) || function(e, t = nt()) {
		const a = e.toLowerCase();
		return Ze(e) && t.some((e) => a.endsWith(e));
	}(e.name, nt());
	var t;
}
function it(e) {
	return new Promise((t) => {
		let a = !1;
		const r = (e) => {
			a || (a = !0, window.removeEventListener("focus", n), t(e));
		};
		e.addEventListener("change", () => {
			const t = Array.from(e.files ?? []);
			r({ files: t });
		}), e.addEventListener("cancel", () => r({ cancelled: !0 }));
		const n = () => {
			setTimeout(() => {
				a || 0 !== (e.files?.length ?? 0) || r({ cancelled: !0 });
			}, 200);
		};
		window.addEventListener("focus", n);
	});
}
(st[0]?.items ?? []).join(", "), st.slice(1).map((e) => e.label).join(" and ");
const ct = [
	".csv",
	".gt3x",
	".bin",
	".rdata",
	".rda",
	".zip",
	".tar.bz2",
	".tbz2"
];
function lt(e) {
	const t = document.createElement("input");
	t.type = "file", t.accept = nt().join(","), e && (t.multiple = !0);
	const a = it(t);
	return t.click(), a.then((e) => "cancelled" in e ? null : e.files);
}
function ut() {
	const e = document.createElement("input");
	e.type = "file", e.setAttribute("webkitdirectory", "");
	const t = it(e);
	return e.click(), t.then((e) => {
		if ("cancelled" in e) return null;
		const { files: t } = e;
		try {
			tt(t.map(Ke));
		} catch (a) {
			if (!(a instanceof He)) throw a;
			return [Ye(a.folderName ?? "GGIR output folder", a)];
		}
		return t.filter((e) => ot(e) && Ze(Ke(e)));
	});
}
const dt = 1e5, pt = `The folder was not read: it holds folders nested more than ${String(32)} deep or more than ${dt.toLocaleString("en-US")} entries (a folder link that points back into its own folder does this). Pick the GGIR output folder itself.`;
async function ft(e, t = e.name, a) {
	try {
		const r = [], n = await mt(e, t, r, a);
		return tt(r), n.length ? n : [Ye(e.name, !1)];
	} catch (r) {
		return [Ye(e.name, !(r instanceof He) || r)];
	}
}
async function mt(e, t, a, r) {
	if (!Ze(t)) return [];
	if (t.split("/").length > 32) throw new He(pt);
	const n = [], s = "function" == typeof e.values ? e.values() : e;
	for await (const o of s) {
		const e = o, s = t ? `${t}/${e.name}` : e.name;
		if (a.push("directory" === e.kind ? `${s}/` : s), a.length > dt) throw new He(pt);
		if (r?.(a.length), Ze(s)) {
			if ("file" === e.kind && "function" == typeof e.getFile && ot(e)) {
				const t = await e.getFile();
				Je(t, s), n.push(t);
				continue;
			}
			"directory" === e.kind && n.push(...await mt(e, s, a, r));
		}
	}
	return n;
}
function wt(e) {
	return e.isFile ? {
		kind: "file",
		name: e.name,
		getFile: () => new Promise((t, a) => e.file(t, a))
	} : {
		kind: "directory",
		name: e.name,
		values: () => ht(e.createReader())
	};
}
async function* ht(e) {
	const t = await new Promise((t, a) => e.readEntries(t, a));
	t.length && (yield* t.map(wt), yield* ht(e));
}
const gt = "auto-update is unavailable on the web platform";
let _t = null;
let yt = null;
function vt() {
	return yt || (yt = globalThis.isTauri ? {
		kind: "tauri",
		routerKind: "hash",
		capabilities: {
			tauri: !0,
			autoUpdate: "true" === {
				BASE_URL: "/sleep-scoring-wasm/",
				DEV: !1,
				MODE: "production",
				PROD: !0,
				SSR: !1,
				VITE_BASE_PATH: "/sleep-scoring-wasm/",
				VITE_FORCE_LOCAL_MODE: "true"
			}.VITE_ENABLE_TAURI_UPDATER
		},
		files: {
			pickFiles: (e) => async function(e) {
				const { open: t } = await import("./dist-js-DtyocxnK.js"), a = await t({
					multiple: e,
					directory: !1,
					filters: [{
						name: "Activity Files",
						extensions: Q
					}]
				});
				if (null == a) return null;
				const r = Array.isArray(a) ? a : [a], n = [];
				for (const s of r) n.push(await X.fromPath(s));
				return n.length > 0 ? n : null;
			}(e),
			pickFolder: () => async function() {
				const { open: e } = await import("./dist-js-DtyocxnK.js"), { invoke: t } = await import("./core-B0WeKh9d.js"), a = await e({
					directory: !0,
					multiple: !1
				});
				if ("string" != typeof a) return null;
				const r = await t("list_supported_files", { dir: a }), n = [];
				for (const s of r) n.push(await X.fromPath(s));
				return n.length > 0 ? n : null;
			}(),
			saveBlob: (e, t, a) => async function(e, t, a) {
				const { save: r } = await import("./dist-js-DtyocxnK.js"), { invoke: n } = await import("./core-B0WeKh9d.js");
				a?.throwIfAborted();
				const s = await p(r({ defaultPath: t }), a);
				if (a?.throwIfAborted(), !s) return null;
				const o = new Uint8Array(await p(e.arrayBuffer(), a)), i = Array.from(o);
				return a?.throwIfAborted(), await n("save_file_atomic", {
					path: s,
					bytes: i
				}), s;
			}(e, t, a)
		},
		fileDrop: { subscribe: (e) => function(e) {
			let t = null, a = !1;
			return (async () => {
				const { getCurrentWindow: r } = await import("./window-uHC0_7hY.js"), n = await r().onDragDropEvent(async (t) => {
					const a = t.payload;
					"enter" === a.type ? e({ phase: "enter" }) : "over" === a.type ? e({ phase: "over" }) : "leave" === a.type ? e({ phase: "leave" }) : "drop" === a.type && e({
						phase: "drop",
						sources: await Promise.all(a.paths.map((e) => X.fromPath(e)))
					});
				});
				a ? n() : t = n;
			})(), () => {
				a = !0, t?.();
			};
		}(e) },
		shell: {
			revealInFolder: async (e) => {
				try {
					await async function(e) {
						const { invoke: t } = await import("./core-B0WeKh9d.js");
						await t("plugin:opener|reveal_item_in_dir", { path: e });
					}(e);
				} catch (t) {
					console.warn("[platform] revealInFolder failed:", t);
				}
			},
			notify: async ({ title: e, body: t }) => {
				try {
					await async function(e, t) {
						const { invoke: a } = await import("./core-B0WeKh9d.js");
						let r = await a("plugin:notification|is_permission_granted");
						r || (r = "granted" === await a("plugin:notification|request_permission")), r && await a("plugin:notification|notify", { options: t ? {
							title: e,
							body: t
						} : { title: e } });
					}(e, t);
				} catch (a) {
					console.warn("[platform] notify failed:", a);
				}
			},
			setProgress: async (e) => {
				try {
					await async function(e) {
						const { getCurrentWindow: t, ProgressBarStatus: a } = await import("./window-uHC0_7hY.js"), r = t();
						if (null === e) await r.setProgressBar({ status: a.None });
						else {
							const t = Math.max(0, Math.min(100, Math.round(100 * e)));
							await r.setProgressBar({
								status: a.Normal,
								progress: t
							});
						}
					}(e);
				} catch (t) {
					console.warn("[platform] setProgress failed:", t);
				}
			},
			onCloseRequested: (e) => function(e) {
				let t = null, a = !1;
				return (async () => {
					const { getCurrentWindow: r } = await import("./window-uHC0_7hY.js"), n = await r().onCloseRequested(async (t) => {
						await e() || t.preventDefault();
					});
					a ? n() : t = n;
				})(), () => {
					a = !0, t?.();
				};
			}(e),
			onMenuAction: (e) => function(e) {
				let t = null, a = !1;
				return (async () => {
					const { listen: r } = await import("./event-BInfzwX-.js"), n = await r("menu-action", (t) => e(t.payload));
					a ? n() : t = n;
				})(), () => {
					a = !0, t?.();
				};
			}(e)
		},
		workspace: {
			switchWorkspace: (e) => async function(e) {
				const { invoke: t } = await import("./core-B0WeKh9d.js");
				await t("switch_workspace", { workspaceId: e });
			}(e),
			deleteWorkspace: (e) => async function(e) {
				const { invoke: t } = await import("./core-B0WeKh9d.js");
				await t("delete_workspace_db", { workspaceId: e });
			}(e),
			saveMarkers: (e) => async function(e) {
				const { invoke: t } = await import("./core-B0WeKh9d.js");
				await t("save_markers_to_sqlite", e);
			}(e),
			configurePeerGroup: (e, t) => async function(e, t) {
				const { invoke: a } = await import("./core-B0WeKh9d.js");
				await a("set_group_config", {
					groupHash: await Z(e),
					username: t
				});
			}(e, t),
			computeGroupHash: (e) => Z(e)
		},
		updater: {
			check: () => async function() {
				const { check: e } = await import("./dist-js-D7-Ut_gj.js"), t = await e();
				return t?.available ? (_t = t, {
					version: t.version,
					currentVersion: t.currentVersion,
					...t.body ? { body: t.body } : {},
					...t.date ? { date: t.date } : {}
				}) : (_t = null, null);
			}(),
			downloadAndInstall: (e) => async function(e) {
				if (!_t) throw new Error("No pending update. Call checkForUpdate() first.");
				const t = _t;
				let a = 0;
				await t.downloadAndInstall((t) => {
					if (e) switch (t.event) {
						case "Started":
							a = t.data.contentLength ?? 0, e({
								chunkSize: 0,
								total: a
							});
							break;
						case "Progress":
							e({
								chunkSize: t.data.chunkLength ?? 0,
								total: a
							});
							break;
						case "Finished": e({
							chunkSize: 0,
							total: a
						});
					}
				}), _t = null;
			}(e),
			relaunch: () => async function() {
				const { relaunch: e } = await import("./dist-js-Hcq9KDqU.js");
				if (!e) throw new Error("Relaunch API is unavailable");
				await e();
			}()
		}
	} : {
		kind: "web",
		routerKind: "browser",
		capabilities: {
			tauri: !1,
			autoUpdate: !1
		},
		files: {
			pickFiles: (e) => async function(e) {
				if ("showOpenFilePicker" in window) try {
					const t = await window.showOpenFilePicker({
						types: [{
							description: "Activity Files",
							accept: {
								"text/csv": [".csv"],
								"application/octet-stream": [
									".gt3x",
									".bin",
									".rdata",
									".rda"
								],
								"application/zip": [".gt3x", ".zip"],
								"application/x-bzip2": [".tar.bz2", ".tbz2"],
								...Object.fromEntries(nt().filter((e) => !ct.includes(e)).map((e) => [`application/x-${e.slice(1)}`, [e]]))
							}
						}],
						multiple: e
					}), a = [];
					for (const e of t) a.push(await e.getFile());
					return a.length > 0 ? a : null;
				} catch (t) {
					return t instanceof DOMException && "AbortError" === t.name ? null : (console.warn("[web-dialogs] showOpenFilePicker failed, falling back to <input>:", t instanceof Error ? t.message : t), lt(e));
				}
				return lt(e);
			}(e),
			pickFolder: (e) => async function(e) {
				if ("showDirectoryPicker" in window) try {
					const t = await window.showDirectoryPicker();
					return await ft(t, t.name, e);
				} catch (t) {
					return t instanceof DOMException && "AbortError" === t.name ? null : (console.warn("[web-dialogs] showDirectoryPicker failed, falling back to <input>:", t instanceof Error ? t.message : t), ut());
				}
				return ut();
			}(e),
			saveBlob: (e, t, a) => (a?.throwIfAborted(), function(e, t) {
				const a = URL.createObjectURL(e), r = document.createElement("a");
				r.href = a, r.download = t, document.body.appendChild(r), r.click(), document.body.removeChild(r), setTimeout(() => URL.revokeObjectURL(a), 1e3);
			}(e, t), Promise.resolve(null))
		},
		fileDrop: { subscribe: (e, t) => {
			const a = t ?? window, r = (e) => Array.from(e.dataTransfer?.types ?? []).includes("Files"), n = (e) => Array.from(e.dataTransfer?.items ?? []).filter((e) => "file" === e.kind).map((e) => {
				const t = e.getAsFile?.();
				return e.webkitGetAsEntry?.()?.isDirectory ? {
					name: t?.name,
					type: e.type,
					directory: !0
				} : t ? {
					name: t.name,
					type: e.type
				} : { type: e.type };
			}), s = (t) => {
				const a = t;
				r(a) && (a.preventDefault(), e({
					phase: "enter",
					items: n(a)
				}));
			}, o = (t) => {
				const a = t;
				r(a) && (a.preventDefault(), e({
					phase: "over",
					items: n(a)
				}));
			}, i = (t) => {
				r(t) && e({ phase: "leave" });
			}, c = (t) => {
				const a = t;
				r(a) && (a.preventDefault(), a.dataTransfer && async function(e) {
					const t = Array.from(e.items ?? []).filter((e) => "file" === e.kind).map((e) => {
						const t = e, a = e.webkitGetAsEntry?.(), r = e.getAsFile?.();
						return {
							handle: t.getAsFileSystemHandle?.(),
							legacy: a,
							file: r
						};
					});
					return t.length ? (await Promise.all(t.map(async (e) => {
						const t = await e.handle?.catch(() => null) ?? (e.legacy ? wt(e.legacy) : null);
						return "directory" === t?.kind ? ft(t) : t?.getFile ? [await t.getFile().catch(() => Ye(t.name, !0))] : e.file ? [e.file] : [Ye(e.legacy?.name ?? "GGIR output folder", !0)];
					}))).flat() : Array.from(e.files);
				}(a.dataTransfer).then((t) => e({
					phase: "drop",
					sources: t
				})));
			};
			return a.addEventListener("dragenter", s), a.addEventListener("dragover", o), a.addEventListener("dragleave", i), a.addEventListener("drop", c), () => {
				a.removeEventListener("dragenter", s), a.removeEventListener("dragover", o), a.removeEventListener("dragleave", i), a.removeEventListener("drop", c);
			};
		} },
		shell: {
			revealInFolder: () => Promise.resolve(),
			notify: ({ title: e, body: t }) => ("undefined" != typeof Notification && "granted" === Notification.permission && new Notification(e, t ? { body: t } : void 0), Promise.resolve()),
			setProgress: () => Promise.resolve(),
			onCloseRequested: (e) => {
				const t = (t) => {
					!1 === e() && (t.preventDefault(), Reflect.set(t, "returnValue", ""));
				};
				return window.addEventListener("beforeunload", t), () => window.removeEventListener("beforeunload", t);
			},
			onMenuAction: () => () => {}
		},
		workspace: {
			switchWorkspace: () => Promise.resolve(),
			deleteWorkspace: () => Promise.resolve(),
			saveMarkers: () => Promise.resolve(),
			configurePeerGroup: () => Promise.resolve(),
			computeGroupHash: (e) => u(e)
		},
		updater: {
			check: () => Promise.resolve(null),
			downloadAndInstall: () => Promise.reject(/* @__PURE__ */ new Error(gt)),
			relaunch: () => Promise.reject(/* @__PURE__ */ new Error(gt))
		}
	}), yt;
}
const bt = "sleep-scoring-workspaces-wasm", kt = "sleep-scoring-active-workspace-wasm", St = `${bt}.migrated`;
function Et(e) {
	return `workspace-restore-committed:${e}`;
}
let Rt = null;
const At = /* @__PURE__ */ new Set();
const It = {
	getItem: async (e) => {
		let t;
		await (Rt || (Rt = (async () => {
			try {
				if ("undefined" == typeof localStorage) return;
				if (0 === await g.workspaces.count()) {
					const e = localStorage.getItem(bt);
					if (e) {
						const t = JSON.parse(e)?.state?.workspaces;
						Array.isArray(t) && t.length > 0 && await b(t), localStorage.removeItem(bt);
					}
				}
				await async function() {
					try {
						const e = globalThis.indexedDB, t = await g.workspaces.toArray();
						if (await Promise.all(t.map(async (e) => {
							e.restoreLock && globalThis.navigator?.locks?.request && await navigator.locks.request(e.restoreLock, { ifAvailable: !0 }, async (t) => {
								if (!t) return;
								const [a, r] = await Promise.all([g.workspaces.get(e.id), g.uiSettings.get(Et(e.dbName))]);
								a?.restoreLock === e.restoreLock && r?.value !== e.restoreLock && await Pt.getState().discardUncommittedWorkspace(e.id);
							});
						})), !e?.databases) return;
						const a = (await e.databases()).map((e) => e.name).filter((e) => !!e), r = a.filter((e) => "SleepScoringDB" === e || /^SleepScoringDB-.+/.test(e));
						if (0 === r.length) return;
						const n = new Set((await g.workspaces.toArray()).map((e) => e.dbName)), s = await v(), i = "SleepScoringGlobal";
						if (a.includes(i)) {
							const e = new h(i);
							try {
								for (const t of await e.workspaces.toArray()) n.add(t.dbName);
								for (const t of await v(e)) s.add(t);
							} catch {} finally {
								e.close();
							}
						}
						const { deleteWorkspaceDb: c } = await Promise.resolve().then(() => Dt);
						await Promise.all(r.filter((e) => s.has(e)).map(c));
						const l = r.filter((e) => !n.has(e) && !s.has(e));
						if (0 === l.length) return;
						const u = (/* @__PURE__ */ new Date()).toISOString(), p = await b(l.map((e) => ({
							id: "SleepScoringDB" === e ? o() : e.slice(15),
							displayName: "Recovered data",
							serverUrl: "",
							dbName: e,
							createdAt: u,
							lastAccessedAt: u
						})));
						console.warn(`workspace-store: re-registered ${p} orphaned local workspace database(s)`);
					} catch (e) {
						console.warn("workspace-store: orphan recovery failed", e);
					}
				}(), localStorage.setItem(St, "1");
			} catch (e) {
				console.warn("workspace-store: migration failed", e);
			}
		})(), Rt));
		try {
			t = await g.workspaces.toArray();
		} catch (a) {
			return console.warn("workspace-store: the workspace registry cannot be read", a), { state: {
				workspaces: [],
				storageUnavailable: !0
			} };
		}
		return t.sort((e, t) => t.lastAccessedAt > e.lastAccessedAt ? 1 : -1), { state: {
			workspaces: t,
			storageUnavailable: !1
		} };
	},
	setItem: async (e, t) => {
		const a = t.state.workspaces ?? [], r = [...At];
		await b(a, r);
		for (const n of r) At.delete(n);
	},
	removeItem: async (e) => {
		await g.workspaces.clear();
	}
};
function Ot(e) {
	At.add(e), Pt.setState({ workspaces: Pt.getState().workspaces.filter((t) => t.id !== e) });
}
const Pt = P()(J((e, t) => ({
	workspaces: [],
	storageUnavailable: !1,
	createWorkspace: (t, a, r) => {
		const n = o(), s = {
			...r ? { restoreLock: r } : {},
			id: n,
			displayName: a,
			serverUrl: t.replace(/\/+$/, ""),
			dbName: `SleepScoringDB-${n}`,
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			lastAccessedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		return e((e) => ({ workspaces: [...e.workspaces, s] })), s;
	},
	commitWorkspaceRestore: async (a) => {
		const r = t().workspaces.find((e) => e.id === a);
		if (!r) throw new Error("The restored workspace is no longer registered.");
		const { restoreLock: n, ...s } = r;
		await g.transaction("rw", g.workspaces, g.uiSettings, async () => {
			await g.uiSettings.put({
				key: Et(r.dbName),
				value: n,
				updatedAt: Date.now()
			}), await b([s]);
		}), e((e) => ({ workspaces: e.workspaces.map((e) => e.id === a ? s : e) }));
	},
	createWorkspaceWithId: (t) => {
		e((e) => ({ workspaces: [...e.workspaces, t] }));
	},
	deleteWorkspace: async (e) => {
		const { runWorkspaceScopeChange: a } = await import("./workspace-switch-BgWTFkct.js").then((e) => e.t);
		return a(async () => {
			if (e === Tt()) return void console.warn("Cannot delete the currently active workspace");
			const a = t().workspaces.find((t) => t.id === e);
			let r;
			if (a?.dbName) {
				const { preserveWorkspaceAuditLog: e } = await import("./workspace-audit-preservation-BqqGCcjY.js"), { auditLog: t } = await import("./audit-log-RFivnbbI.js").then((e) => e.n), { useSleepScoringStore: n } = await import("./store-StTfKmbj.js").then((e) => e.n), { username: s, sitePassword: o } = n.getState(), i = await e(a, {
					username: s,
					sitePassword: o
				}), { SleepScoringDB: c } = await import("./schema-D8rqa1Y6.js").then((e) => e.u), { countWorkspaceContents: l } = await import("./workspace-contents-cp-prw-y.js"), u = new c(a.dbName);
				let d;
				try {
					await u.open(), r = await l(u), d = await u.files.toArray();
				} finally {
					u.close();
				}
				const { deleteWorkspaceDb: p } = await Promise.resolve().then(() => Dt);
				await p(a.dbName);
				const { deleteMigrationBackups: f } = await import("./pre-migration-backup-BRtuCEA7.js").then((e) => e.t);
				await f(a.dbName);
				const { deleteFileCaches: m } = await import("./store-StTfKmbj.js").then((e) => e.p);
				await m(d), t.recordAppEvent("workspace_deleted", {
					workspaceId: a.id,
					displayName: a.displayName,
					auditRowsTotal: i.total,
					auditRowsReplicated: i.replicated,
					auditRowsDestroyed: i.destroyed,
					...i.reason ? { reason: i.reason } : {}
				}), await t.settleWrites();
			}
			Ot(e);
			try {
				const t = `sleep-scoring-storage-${e}`;
				localStorage.removeItem(t);
				const a = `sleep-scoring-prefs-${e}-`, r = [];
				for (let e = 0; e < localStorage.length; e++) {
					const t = localStorage.key(e);
					t?.startsWith(a) && r.push(t);
				}
				for (const e of r) localStorage.removeItem(e);
			} catch (n) {
				console.warn("Failed to clean up localStorage:", n);
			}
			return vt().capabilities.tauri && vt().workspace.deleteWorkspace(e).catch((e) => {
				console.warn("Failed to delete Tauri workspace DB:", e);
			}), r;
		});
	},
	discardUncommittedWorkspace: async (e) => {
		const { runWorkspaceScopeChange: a } = await import("./workspace-switch-BgWTFkct.js").then((e) => e.t);
		return a(async () => {
			const a = t().workspaces.find((t) => t.id === e) ?? await g.workspaces.get(e);
			if (a?.dbName) {
				const { deleteWorkspaceDb: e } = await Promise.resolve().then(() => Dt);
				await e(a.dbName);
				const { deleteMigrationBackups: t } = await import("./pre-migration-backup-BRtuCEA7.js").then((e) => e.t);
				await t(a.dbName);
			}
			Ot(e);
		});
	},
	recordWorkspaceBackup: (t, a) => {
		e((e) => ({ workspaces: e.workspaces.map((e) => e.id === t ? {
			...e,
			lastBackup: a
		} : e) }));
	},
	recordWorkspaceRestore: (t, a) => {
		e((e) => ({ workspaces: e.workspaces.map((e) => e.id === t ? {
			...e,
			lastRestore: a
		} : e) }));
	},
	renameWorkspace: (t, a) => {
		const r = a.trim();
		"" !== r && e((e) => ({ workspaces: e.workspaces.map((e) => e.id === t ? {
			...e,
			displayName: r
		} : e) }));
	},
	setWorkspaceUsername: (t, a) => {
		const r = a.trim();
		e((e) => ({ workspaces: e.workspaces.map((e) => {
			if (e.id !== t) return e;
			const { lastUsername: a, ...n } = e;
			return "" === r ? n : {
				...n,
				lastUsername: r
			};
		}) }));
	},
	updateLastAccessed: (t) => {
		e((e) => ({ workspaces: e.workspaces.map((e) => e.id === t ? {
			...e,
			lastAccessedAt: (/* @__PURE__ */ new Date()).toISOString()
		} : e) }));
	},
	getWorkspace: (e) => t().workspaces.find((t) => t.id === e)
}), {
	name: bt,
	storage: It,
	onRehydrateStorage: () => (e, t) => {
		if (!t) try {
			(async function() {
				w.basePath;
			})();
		} catch (a) {
			console.warn("[workspace-store] serverUrl normalization failed:", a);
		}
	}
})), Ct = P()(() => ({
	activeId: (() => {
		try {
			return sessionStorage.getItem(kt);
		} catch {
			return null;
		}
	})(),
	activating: !1
}));
function Tt() {
	return Ct.getState().activeId;
}
var Dt = r({
	closeDb: () => Bt,
	deleteWorkspaceDb: () => Wt,
	getDb: () => $t,
	hasOpenDb: () => zt,
	isWorkspaceDbDeleted: () => Ut,
	subscribeDbChanges: () => Vt
});
let Nt = null;
const Lt = /* @__PURE__ */ new Set(), jt = /* @__PURE__ */ new Set(), Gt = /* @__PURE__ */ new Set();
function Mt(e) {
	jt.add(e);
	for (const t of Object.values(j.getState().jobs)) t.workspaceId === e && t.controller.abort();
	for (const t of Lt) {
		const a = t.deref();
		a && a.name !== e || Lt.delete(t), a?.name === e && a.close({ disableAutoOpen: !0 });
	}
}
async function Wt(e) {
	const t = {
		key: y(e),
		value: !0,
		updatedAt: Date.now()
	};
	await g.transaction("rw", g.workspaces, g.uiSettings, async () => {
		await g.uiSettings.put(t);
		const a = await g.workspaces.toArray();
		await g.workspaces.bulkDelete(a.filter((t) => t.dbName === e).map((e) => e.id));
	}), Mt(e), xt(e);
	const { workspaces: a } = Pt.getState();
	a.some((t) => t.dbName === e) && Pt.setState({ workspaces: a.filter((t) => t.dbName !== e) });
	try {
		const { publishWorkspaceDeletion: e } = await import("./project-revision-CRZNLUWr.js").then((e) => e.n);
		e();
	} catch {}
	try {
		await i.delete(e);
	} catch {
		console.warn("Workspace data will be removed the next time the app starts.");
	}
}
function xt(e) {
	Nt?.name === e && (function() {
		try {
			sessionStorage.removeItem(kt);
		} catch {}
		Ct.setState({
			activeId: null,
			activating: !1
		});
	}(), Bt());
}
function Ut(e) {
	if (jt.has(e)) return !0;
	const t = Pt.getState().workspaces.some((t) => t.dbName === e);
	return t && Gt.add(e), !t && Gt.has(e);
}
i.addons.push((e) => {
	Lt.add(new WeakRef(e));
	const t = e.open.bind(e);
	e.open = () => jt.has(e.name) ? i.Promise.reject(new i.DatabaseClosedError()) : t().catch((t) => {
		throw jt.has(e.name) && (Mt(e.name), xt(e.name)), t;
	});
	const a = () => {
		if (e instanceof c) return i.waitFor(g.uiSettings.get(y(e.name))).then((t) => {
			if (t) throw jt.add(e.name), new i.DatabaseClosedError();
		});
	};
	e.on("populate", a), e.on("ready", a, !0), e.on("versionchange", (t) => {
		if (null === t.newVersion && e instanceof c) return Mt(e.name), xt(e.name), !1;
	}), jt.has(e.name) && e.close({ disableAutoOpen: !0 });
});
const Ft = /* @__PURE__ */ new Set();
function Vt(e) {
	return Ft.add(e), () => Ft.delete(e);
}
function Ht() {
	for (const e of Ft) try {
		e();
	} catch {}
}
function $t() {
	if (!Nt) {
		const e = "undefined" != typeof window ? Tt() : null;
		if (e) {
			const t = Pt.getState().getWorkspace(e);
			return Nt = new c(t?.dbName ?? `SleepScoringDB-${e}`), Ht(), Nt;
		}
		throw new Error("No workspace database is active. Call switchDb() first.");
	}
	return Nt;
}
function zt() {
	return null !== Nt;
}
function Bt() {
	Nt && (Nt.close(), Nt = null), Ht();
}
if ("undefined" != typeof window) {
	const e = () => {
		const e = Nt;
		e && import("./workspace-switch-BgWTFkct.js").then((e) => e.t).then(({ runWorkspaceScopeChange: t }) => t(() => {
			Nt === e && e.close({ disableAutoOpen: !1 });
		})).catch(() => {});
	};
	window.addEventListener("pagehide", e), window.addEventListener("freeze", e), window.addEventListener("pageshow", (e) => {
		const t = Nt;
		e.persisted && t && import("./workspace-switch-BgWTFkct.js").then((e) => e.t).then(async ({ workspaceActivation: e }) => {
			await e;
			const { useSleepScoringStore: a } = await import("./store-StTfKmbj.js").then((e) => e.n), { username: r, selectedStudyId: n, isAuthenticated: s } = a.getState();
			if (Nt !== t || !s || !r) return;
			const { recoverWorkspaceDiaryBindings: o } = await import("./staged-diary-import-DCJyTycP.js");
			Nt === t && await o(t, {
				username: r,
				studyId: n
			});
		}).catch(() => {
			console.warn("[diary] Page resume recovery could not start.", { failed: 1 });
		});
	});
}
export { L as $, Le as A, ne as B, Oe as C, De as D, Te as E, Fe as F, ge as G, ee as H, ue as I, pe as J, de as K, te as L, Ge as M, Me as N, xe as O, Ve as P, N as Q, fe as R, Ie as S, Ce as T, se as U, re as V, ae as W, z as X, Y, J as Z, ke as _, Tt as a, P as at, Re as b, He as c, w as ct, at as d, M as et, _e as f, We as g, be as h, Vt as i, T as it, je as j, Ne as k, Xe as l, d as lt, ve as m, zt as n, j as nt, Pt as o, R as ot, ye as p, he as q, Ut as r, C as rt, vt as s, S as st, $t as t, G as tt, qe as u, p as ut, Se as v, Pe as w, Ae as x, Ee as y, me as z };

/**
* @license
* Copyright 2019 Google LLC
* SPDX-License-Identifier: Apache-2.0
*/
const e = Symbol("Comlink.proxy"), i = Symbol("Comlink.endpoint"), t = Symbol("Comlink.releaseProxy"), s = Symbol("Comlink.finalizer"), n = Symbol("Comlink.thrown"), o = (e) => "object" == typeof e && null !== e || "function" == typeof e, a = /* @__PURE__ */ new Map([["proxy", {
	canHandle: (i) => o(i) && i[e],
	serialize(e) {
		const { port1: i, port2: t } = new MessageChannel();
		return r(e, i), [t, [t]];
	},
	deserialize: (e) => (e.start(), function(e) {
		const i = /* @__PURE__ */ new Map();
		return e.addEventListener("message", function(e) {
			const { data: t } = e;
			if (!t || !t.id) return;
			const s = i.get(t.id);
			if (s) try {
				s(t);
			} finally {
				i.delete(t.id);
			}
		}), m(e, i, [], void 0);
	}(e))
}], ["throw", {
	canHandle: (e) => o(e) && n in e,
	serialize({ value: e }) {
		let i;
		return i = e instanceof Error ? {
			isError: !0,
			value: {
				message: e.message,
				name: e.name,
				stack: e.stack
			}
		} : {
			isError: !1,
			value: e
		}, [i, []];
	},
	deserialize(e) {
		if (e.isError) throw Object.assign(new Error(e.value.message), e.value);
		throw e.value;
	}
}]]);
function r(i, t = globalThis, o = ["*"]) {
	t.addEventListener("message", function a(d) {
		if (!d || !d.data) return;
		if (!function(e, i) {
			for (const t of e) {
				if (i === t || "*" === t) return !0;
				if (t instanceof RegExp && t.test(i)) return !0;
			}
			return !1;
		}(o, d.origin)) return void console.warn(`Invalid origin '${d.origin}' for comlink proxy`);
		const { id: l, type: _, path: y } = Object.assign({ path: [] }, d.data), m = (d.data.argumentList || []).map(c);
		let h;
		try {
			const t = y.slice(0, -1).reduce((e, i) => e[i], i), s = y.reduce((e, i) => e[i], i);
			switch (_) {
				case "GET":
					h = s;
					break;
				case "SET":
					t[y.slice(-1)[0]] = c(d.data.value), h = !0;
					break;
				case "APPLY":
					h = s.apply(t, m);
					break;
				case "CONSTRUCT":
					h = function(i) {
						return Object.assign(i, { [e]: !0 });
					}(new s(...m));
					break;
				case "ENDPOINT":
					{
						const { port1: e, port2: t } = new MessageChannel();
						r(i, t), h = function(e, i) {
							return E.set(e, i), e;
						}(e, [e]);
					}
					break;
				case "RELEASE":
					h = void 0;
					break;
				default: return;
			}
		} catch (w) {
			h = {
				value: w,
				[n]: 0
			};
		}
		Promise.resolve(h).catch((e) => ({
			value: e,
			[n]: 0
		})).then((e) => {
			const [n, o] = g(e);
			t.postMessage(Object.assign(Object.assign({}, n), { id: l }), o), "RELEASE" === _ && (t.removeEventListener("message", a), p(t), s in i && "function" == typeof i[s] && i[s]());
		}).catch((e) => {
			const [i, s] = g({
				value: /* @__PURE__ */ new TypeError("Unserializable return value"),
				[n]: 0
			});
			t.postMessage(Object.assign(Object.assign({}, i), { id: l }), s);
		});
	}), t.start && t.start();
}
function p(e) {
	(function(e) {
		return "MessagePort" === e.constructor.name;
	})(e) && e.close();
}
function d(e) {
	if (e) throw new Error("Proxy has been released and is not useable");
}
function l(e) {
	return w(e, /* @__PURE__ */ new Map(), { type: "RELEASE" }).then(() => {
		p(e);
	});
}
const _ = /* @__PURE__ */ new WeakMap(), y = "FinalizationRegistry" in globalThis && new FinalizationRegistry((e) => {
	const i = (_.get(e) || 0) - 1;
	_.set(e, i), 0 === i && l(e);
});
function m(e, s, n = [], o = function() {}) {
	let a = !1;
	const r = new Proxy(o, {
		get(i, o) {
			if (d(a), o === t) return () => {
				(function(e) {
					y && y.unregister(e);
				})(r), l(e), s.clear(), a = !0;
			};
			if ("then" === o) {
				if (0 === n.length) return { then: () => r };
				const i = w(e, s, {
					type: "GET",
					path: n.map((e) => e.toString())
				}).then(c);
				return i.then.bind(i);
			}
			return m(e, s, [...n, o]);
		},
		set(i, t, o) {
			d(a);
			const [r, p] = g(o);
			return w(e, s, {
				type: "SET",
				path: [...n, t].map((e) => e.toString()),
				value: r
			}, p).then(c);
		},
		apply(t, o, r) {
			d(a);
			const p = n[n.length - 1];
			if (p === i) return w(e, s, { type: "ENDPOINT" }).then(c);
			if ("bind" === p) return m(e, s, n.slice(0, -1));
			const [l, _] = h(r);
			return w(e, s, {
				type: "APPLY",
				path: n.map((e) => e.toString()),
				argumentList: l
			}, _).then(c);
		},
		construct(i, t) {
			d(a);
			const [o, r] = h(t);
			return w(e, s, {
				type: "CONSTRUCT",
				path: n.map((e) => e.toString()),
				argumentList: o
			}, r).then(c);
		}
	});
	return function(e, i) {
		const t = (_.get(i) || 0) + 1;
		_.set(i, t), y && y.register(e, i, e);
	}(r, e), r;
}
function h(e) {
	const i = e.map(g);
	return [i.map((e) => e[0]), (t = i.map((e) => e[1]), Array.prototype.concat.apply([], t))];
	var t;
}
const E = /* @__PURE__ */ new WeakMap();
function g(e) {
	for (const [i, t] of a) if (t.canHandle(e)) {
		const [s, n] = t.serialize(e);
		return [{
			type: "HANDLER",
			name: i,
			value: s
		}, n];
	}
	return [{
		type: "RAW",
		value: e
	}, E.get(e) || []];
}
function c(e) {
	switch (e.type) {
		case "HANDLER": return a.get(e.name).deserialize(e.value);
		case "RAW": return e.value;
	}
}
function w(e, i, t, s) {
	return new Promise((n) => {
		const o = new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
		i.set(o, n), e.start && e.start(), e.postMessage(Object.assign({ id: o }, t), s);
	});
}
const u = Object.assign({ "../../wasm/pkg/diary-rdf/diary_rdf.js": () => import("./diary_rdf-DK7gcqON.js") });
let R = null, S = null;
function T() {
	return R ??= (async () => {
		const e = Object.values(u)[0];
		if (void 0 === e) throw new Error("diary_rdf wasm module is not built - run `scripts/agent-bootstrap.sh` (vite and vitest build it themselves via frontend/scripts/ensure-diary-rdf-wasm.mjs)");
		return e();
	})(), R;
}
const I = [
	{
		axiom_id: "10",
		shape_iri: "https://w3id.org/sleep-diary-ontology/EntryDateGteSleepDateShape",
		message: "Axiom 10: Entry date must be >= sleep date",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_entry_date ?ed .\n                $this sleep:diary_sleep_date ?sd .\n                FILTER(?ed < ?sd)\n            }\n        "
	},
	{
		axiom_id: "11",
		shape_iri: "https://w3id.org/sleep-diary-ontology/EntryDateGteOffsetDateShape",
		message: "Axiom 11: Entry date must be >= wake date",
		severity: "Violation",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_entry_date ?ed .\n                $this sleep:diary_offset_date ?od .\n                FILTER(?ed < ?od)\n            }\n        "
	},
	{
		axiom_id: "12",
		shape_iri: "https://w3id.org/sleep-diary-ontology/EntryDateNearSleepDateShape",
		message: "Axiom 12: Entry date more than 1 day after sleep date",
		severity: "Warning",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_entry_date_epoch_day ?edD .\n                $this sleep:diary_sleep_date_epoch_day ?sdD .\n                FILTER(?edD - ?sdD > 1)\n            }\n        "
	},
	{
		axiom_id: "13",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SubmissionAfterEntryShape",
		message: "Axiom 13: Submission must be >= entry date",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:submission_datetime ?sub .\n                $this sleep:diary_entry_date ?ed .\n                FILTER(?sub < ?ed)\n            }\n        "
	},
	{
		axiom_id: "14",
		shape_iri: "https://w3id.org/sleep-diary-ontology/WakeBeforeNextBedShape",
		message: "Axiom 14: Wake time of night N must precede bed time of night N+1",
		severity: "Violation",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn1 .\n                $this sleep:diary_wake_time ?wake .\n                $this sleep:diary_sleep_date ?d1 .\n                ?next sleep:participant_id ?pid .\n                ?next sleep:night_number ?nn2 .\n                ?next sleep:diary_in_bed_time ?bed .\n                ?next sleep:diary_sleep_date ?d2 .\n                FILTER(?nn2 = ?nn1 + 1)\n                $this sleep:diary_wake_time_minutes ?wakeMin .\n                ?next sleep:diary_in_bed_time_minutes ?bedMin .\n                FILTER(?d1 = ?d2 && ?wakeMin >= ?bedMin)\n            }\n        "
	},
	{
		axiom_id: "15",
		shape_iri: "https://w3id.org/sleep-diary-ontology/MidnightCrossingBedTimeShape",
		message: "Axiom 15: Bed time appears to cross midnight without date adjustment (00:00-05:59)",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_minutes ?bedMin .\n                $this sleep:diary_sleep_date ?sd .\n                $this sleep:diary_entry_date ?ed .\n                FILTER(?bedMin < 360)\n                FILTER(STR(?sd) = STR(?ed))\n            }\n        "
	},
	{
		axiom_id: "16",
		shape_iri: "https://w3id.org/sleep-diary-ontology/MidnightCrossingOnsetShape",
		message: "Axiom 16: Sleep onset appears to cross midnight without date adjustment (00:00-05:59)",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time_minutes ?onsetMin .\n                $this sleep:diary_sleep_date ?sd .\n                $this sleep:diary_entry_date ?ed .\n                FILTER(?onsetMin < 360)\n                FILTER(STR(?sd) = STR(?ed))\n            }\n        "
	},
	{
		axiom_id: "17",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepPeriodMaxShape",
		message: "Axiom 17: sleep period exceeds 24 hours",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_cmp ?bedCmp .\n                $this sleep:diary_out_of_bed_time_cmp ?outCmp .\n                BIND(?outCmp - ?bedCmp AS ?dur)\n                FILTER(?dur > 1440)\n            }\n        "
	},
	{
		axiom_id: "18",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NightDateOrderShape",
		message: "Axiom 18: Night date ordering violation",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn1 .\n                $this sleep:diary_sleep_date ?d1 .\n                ?other sleep:participant_id ?pid .\n                ?other sleep:night_number ?nn2 .\n                ?other sleep:diary_sleep_date ?d2 .\n                FILTER(?nn2 = ?nn1 + 1)\n                FILTER(?d2 <= ?d1)\n            }\n        "
	},
	{
		axiom_id: "19",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NightNumberDateAlignShape",
		message: "Axiom 19: Night numbers misaligned with dates",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn1 .\n                $this sleep:diary_sleep_date ?d1 .\n                ?other sleep:participant_id ?pid .\n                ?other sleep:night_number ?nn2 .\n                ?other sleep:diary_sleep_date ?d2 .\n                FILTER(?nn1 < ?nn2 && ?d1 > ?d2)\n            }\n        "
	},
	{
		axiom_id: "20",
		shape_iri: "https://w3id.org/sleep-diary-ontology/EntryDateSpacingShape",
		message: "Axiom 20: Gap of more than 7 days between consecutive entries",
		severity: "Warning",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn1 .\n                $this sleep:diary_sleep_date ?d1 .\n                ?next sleep:participant_id ?pid .\n                ?next sleep:night_number ?nn2 .\n                ?next sleep:diary_sleep_date ?d2 .\n                FILTER(?nn2 = ?nn1 + 1)\n                $this sleep:diary_sleep_date_epoch_day ?d1D .\n                ?next sleep:diary_sleep_date_epoch_day ?d2D .\n                FILTER(?d2D - ?d1D > 7)\n            }\n        "
	},
	{
		axiom_id: "21",
		shape_iri: "https://w3id.org/sleep-diary-ontology/OffsetDateGteOnsetDateShape",
		message: "Axiom 21: Wake date must be >= sleep onset date",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_offset_date ?wakeDate .\n                $this sleep:diary_sleep_date ?sleepDate .\n                FILTER(?wakeDate < ?sleepDate)\n            }\n        "
	},
	{
		axiom_id: "22",
		shape_iri: "https://w3id.org/sleep-diary-ontology/OffsetDateWithinOneDayShape",
		message: "Axiom 22: Wake date must be same day or next day after sleep date",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_offset_date_epoch_day ?wdD .\n                $this sleep:diary_sleep_date_epoch_day ?sdD .\n                BIND(?wdD - ?sdD AS ?diff)\n                FILTER(?diff < 0 || ?diff > 1)\n            }\n        "
	},
	{
		axiom_id: "23",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapDateNearEntryDateShape",
		message: "Axiom 23: Nap date more than 1 day from entry date",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:nap_date_epoch_day ?ndD .\n                $this sleep:diary_entry_date_epoch_day ?edD .\n                BIND(?ndD - ?edD AS ?diff)\n                FILTER(?diff < -1 || ?diff > 1)\n            }\n        "
	},
	{
		axiom_id: "25",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NoFutureDatesShape",
		message: "Axiom 25: Sleep date is in the future",
		severity: "Warning",
		scope: "field",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_date ?sd .\n                BIND(SUBSTR(STR(NOW()), 1, 10) AS ?today)\n                FILTER(STR(?sd) > ?today)\n            }\n        "
	},
	{
		axiom_id: "27",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TIBGteTSTShape",
		message: "Axiom 27: Time in bed must be >= total sleep time",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_time_in_bed_minutes ?tib .\n                $this sleep:diary_total_sleep_time_minutes ?tst .\n                FILTER(xsd:decimal(?tst) > xsd:decimal(?tib))\n            }\n        "
	},
	{
		axiom_id: "28",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapDurationRangeShape",
		message: "Axiom 28: Nap duration must be 0-720 minutes",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:nap_start_time_minutes ?startMin .\n                $this sleep:nap_end_time_minutes ?endMin .\n                BIND(?endMin - ?startMin AS ?dur)\n                FILTER(?dur < 0 || ?dur > 720)\n            }\n        "
	},
	{
		axiom_id: "29",
		shape_iri: "https://w3id.org/sleep-diary-ontology/WakePeriodNonNegativeShape",
		message: "Axiom 29: Wake period between consecutive nights is negative (overlap)",
		severity: "Violation",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn1 .\n                $this sleep:diary_out_of_bed_time ?outOfBed .\n                $this sleep:diary_sleep_date ?d1 .\n                $this sleep:diary_sleep_date_epoch_day ?d1D .\n                $this sleep:diary_out_of_bed_time_minutes ?outMin .\n                BIND(?nn1 + 1 AS ?nn2)\n                FILTER(BOUND(?nn2))\n                # Bind participant/night before looking up the next entry.\n                # Reject the OPTIONAL's unmatched row to preserve inner-join\n                # multiplicity, including duplicate entries for that next night.\n                OPTIONAL {\n                    ?next sleep:participant_id ?pid .\n                    ?next sleep:night_number ?nn2 .\n                    ?next sleep:diary_in_bed_time ?inBed .\n                    ?next sleep:diary_sleep_date ?d2 .\n                    ?next sleep:diary_sleep_date_epoch_day ?d2D .\n                    ?next sleep:diary_in_bed_time_minutes ?inMin .\n                    FILTER(((?d2D - ?d1D) * 1440) + ?inMin - ?outMin < 0)\n                }\n                FILTER(BOUND(?next))\n            }\n        "
	},
	{
		axiom_id: "30",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NoSimultaneousSleepWakeShape",
		message: "Axiom 30: Sleep onset and wake time are identical",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time ?onset .\n                $this sleep:diary_wake_time ?wake .\n                FILTER(STR(?onset) = STR(?wake))\n            }\n        "
	},
	{
		axiom_id: "31",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ContinuousSleepPeriodShape",
		message: "Axiom 31: Zero-duration sleep period (in-bed time equals out-of-bed time)",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time ?bed .\n                $this sleep:diary_out_of_bed_time ?out .\n                FILTER(STR(?bed) = STR(?out))\n            }\n        "
	},
	{
		axiom_id: "32",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ParticipantIdConsistentShape",
		message: "Axiom 32: Multiple participant IDs found in same dataset",
		severity: "Info",
		scope: "dataset",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT DISTINCT $this WHERE {\n                # One linear pass: the pairwise form with a nested NOT EXISTS was\n                # cubic in entries (a 932-night diary froze the browser for minutes).\n                {\n                    SELECT (COUNT(DISTINCT ?pid) AS ?pids) (MIN(STR(?e)) AS ?first)\n                    WHERE { ?e sleep:participant_id ?pid }\n                }\n                FILTER(?pids > 1)\n                $this sleep:participant_id ?anypid .\n                FILTER(STR($this) = ?first)\n            }\n        "
	},
	{
		axiom_id: "33",
		shape_iri: "https://w3id.org/sleep-diary-ontology/UniqueNightShape",
		message: "Axiom 33: Duplicate entry for same participant and night",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn .\n                ?other sleep:participant_id ?pid .\n                ?other sleep:night_number ?nn .\n                FILTER($this != ?other)\n                FILTER(STR($this) > STR(?other))\n            }\n        "
	},
	{
		axiom_id: "34",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapOccurredConsistencyShape",
		message: "Axiom 34: diary_nap_occurred=true but no nap episodes",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_nap_occurred \"true\"^^xsd:boolean .\n                FILTER NOT EXISTS {\n                    $this sleep:diary_nap_episodes ?nap\n                }\n            }\n        "
	},
	{
		axiom_id: "36",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepEfficiencyConsistencyShape",
		message: "Axiom 36: Reported sleep efficiency does not match TST/TIB",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_total_sleep_time_minutes ?tst .\n                $this sleep:diary_time_in_bed_minutes ?tib .\n                $this sleep:diary_sleep_efficiency_percent ?se .\n                FILTER(xsd:decimal(?tib) > 0)\n                BIND((xsd:decimal(?tst) / xsd:decimal(?tib)) * 100 AS ?computed)\n                FILTER(ABS(xsd:decimal(?se) - ?computed) > 2)\n            }\n        "
	},
	{
		axiom_id: "37",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DuplicateEntrySameTimesShape",
		message: "Axiom 37: Duplicate entries for same night have different sleep times",
		severity: "Violation",
		scope: "participant",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:night_number ?nn .\n                $this sleep:diary_sleep_onset_time ?onset1 .\n                ?other sleep:participant_id ?pid .\n                ?other sleep:night_number ?nn .\n                ?other sleep:diary_sleep_onset_time ?onset2 .\n                FILTER($this != ?other)\n                FILTER(STR($this) < STR(?other))\n                FILTER(?onset1 != ?onset2)\n            }\n        "
	},
	{
		axiom_id: "4",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TSTDurationConsistencyShape",
		message: "Axiom 4: Reported TST does not match computed duration (onset to wake)",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time_cmp ?onsetCmp .\n                $this sleep:diary_wake_time_cmp ?wakeCmp .\n                $this sleep:diary_total_sleep_time_minutes ?tst .\n                $this sleep:diary_waso_minutes ?waso .\n                BIND((?wakeCmp - ?onsetCmp) - xsd:decimal(?waso) AS ?computed)\n                FILTER(ABS(xsd:decimal(?tst) - ?computed) > 15)\n            }\n        "
	},
	{
		axiom_id: "42",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ConsistentTimezoneShape",
		message: "Axiom 42: Inconsistent timezone format detected across entries",
		severity: "Warning",
		scope: "dataset",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT DISTINCT $this WHERE {\n                # Report the same earliest entry when both clock formats occur,\n                # without a pairwise join and correlated earliest-entry scan.\n                {\n                    SELECT (MIN(STR(?e)) AS ?first)\n                           (MAX(IF(STRLEN(STR(?t)) > 8, 1, 0)) AS ?long)\n                           (MAX(IF(STRLEN(STR(?t)) <= 8, 1, 0)) AS ?short)\n                    WHERE { ?e sleep:diary_in_bed_time ?t }\n                }\n                FILTER(?long = 1 && ?short = 1)\n                $this sleep:diary_in_bed_time ?anyT .\n                FILTER(STR($this) = ?first)\n            }\n        "
	},
	{
		axiom_id: "43",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ConsistentDateFormatShape",
		message: "Axiom 43: Inconsistent date format precision across entries",
		severity: "Warning",
		scope: "dataset",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT DISTINCT $this WHERE {\n                # One linear pass (see axiom 32): same first entry, same condition.\n                {\n                    SELECT (COUNT(DISTINCT STRLEN(STR(?d))) AS ?lengths) (MIN(STR(?e)) AS ?first)\n                    WHERE { ?e sleep:diary_sleep_date ?d }\n                }\n                FILTER(?lengths > 1)\n                $this sleep:diary_sleep_date ?anyD .\n                FILTER(STR($this) = ?first)\n            }\n        "
	},
	{
		axiom_id: "44",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ConsistentMissingEncodingShape",
		message: "Axiom 44: Inconsistent missing value encoding (empty string found as value)",
		severity: "Info",
		scope: "population",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_quality ?val .\n                FILTER(STR(?val) = \"\" || STR(?val) = \"NA\" || STR(?val) = \"N/A\" || STR(?val) = \"null\" || STR(?val) = \"none\")\n            }\n        "
	},
	{
		axiom_id: "45",
		shape_iri: "https://w3id.org/sleep-diary-ontology/OnsetDateDerivableShape",
		message: "Axiom 45: Sleep onset date conflicts with entry date and onset time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_date_epoch_day ?sdD .\n                $this sleep:diary_entry_date_epoch_day ?edD .\n                $this sleep:diary_sleep_onset_time_minutes ?onsetMin .\n                BIND(?onsetMin / 60 AS ?onsetH)\n                BIND(?edD - ?sdD AS ?diff)\n                FILTER(\n                    (?onsetH >= 18 && ?diff != 0) ||\n                    (?onsetH < 6 && ?diff != 1)\n                )\n            }\n        "
	},
	{
		axiom_id: "46",
		shape_iri: "https://w3id.org/sleep-diary-ontology/OffsetDateDerivableShape",
		message: "Axiom 46: Wake date conflicts with sleep date and wake time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_date_epoch_day ?sdD .\n                $this sleep:diary_offset_date_epoch_day ?odD .\n                $this sleep:diary_wake_time_minutes ?wakeMin .\n                BIND(?wakeMin / 60 AS ?wakeH)\n                BIND(?odD - ?sdD AS ?diff)\n                FILTER(\n                    (?wakeH < 18 && ?diff != 1) ||\n                    (?wakeH >= 18 && ?diff != 0)\n                )\n            }\n        "
	},
	{
		axiom_id: "47",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapDateDerivableShape",
		message: "Axiom 47: Nap date conflicts with entry date",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:nap_date_epoch_day ?ndD .\n                $this sleep:diary_entry_date_epoch_day ?edD .\n                BIND(?ndD - ?edD AS ?diff)\n                FILTER(?diff < -1 || ?diff > 0)\n            }\n        "
	},
	{
		axiom_id: "48",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ComputedPrecisionShape",
		message: "Axiom 48: TST has sub-minute precision but source times are HH:MM",
		severity: "Info",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_total_sleep_time_minutes ?tst .\n                $this sleep:diary_sleep_onset_time ?onset .\n                BIND(FLOOR(xsd:decimal(?tst)) AS ?floored)\n                FILTER(xsd:decimal(?tst) != ?floored)\n                FILTER(STRLEN(STR(?onset)) <= 8)\n            }\n        "
	},
	{
		axiom_id: "5",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapOnsetBeforeOffsetShape",
		message: "Axiom 5: Nap start time must precede nap end time",
		severity: "Violation",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:nap_start_time_minutes ?startMin .\n                $this sleep:nap_end_time_minutes ?endMin .\n                FILTER(?startMin >= ?endMin)\n            }\n        "
	},
	{
		axiom_id: "52",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DatesWithinStudyPeriodShape",
		message: "Axiom 52: Sleep date falls outside study period",
		severity: "Warning",
		scope: "population",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_date ?sd .\n                $this sleep:study_start_date ?start .\n                $this sleep:study_end_date ?end .\n                FILTER(?sd < ?start || ?sd > ?end)\n            }\n        "
	},
	{
		axiom_id: "54",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ProspectiveCompletionShape",
		message: "Axiom 54: Diary entry appears to be backdated (>3 days between sleep date and entry date)",
		severity: "Warning",
		scope: "population",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_entry_date ?ed .\n                $this sleep:diary_sleep_date ?sd .\n                $this sleep:diary_entry_date_epoch_day ?edD .\n                $this sleep:diary_sleep_date_epoch_day ?sdD .\n                FILTER(?edD - ?sdD > 3)\n            }\n        "
	},
	{
		axiom_id: "59",
		shape_iri: "https://w3id.org/sleep-diary-ontology/InvalidNightTimesAbsentShape",
		message: "Axiom 59: is_invalid_night=true but sleep times are present",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_is_invalid_night \"true\"^^xsd:boolean .\n                {\n                    $this sleep:diary_sleep_onset_time ?val .\n                } UNION {\n                    $this sleep:diary_wake_time ?val .\n                } UNION {\n                    $this sleep:diary_total_sleep_time_minutes ?val .\n                }\n            }\n        "
	},
	{
		axiom_id: "60",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepTimesPresentImpliesInvalidNightFalseShape",
		message: "Axiom 60: sleep times present but is_invalid_night is true",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time ?onset .\n                $this sleep:diary_wake_time ?wake .\n                $this sleep:diary_is_invalid_night \"true\"^^xsd:boolean .\n            }\n        "
	},
	{
		axiom_id: "61",
		shape_iri: "https://w3id.org/sleep-diary-ontology/CaffeineTimeImpliesIntakeShape",
		message: "Axiom 61: caffeine_last_time present but caffeine_intake is not true",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_caffeine_last_time ?time .\n                FILTER NOT EXISTS {\n                    $this sleep:diary_caffeine_intake \"true\"^^xsd:boolean .\n                }\n            }\n        "
	},
	{
		axiom_id: "62",
		shape_iri: "https://w3id.org/sleep-diary-ontology/AlcoholTimeImpliesIntakeShape",
		message: "Axiom 62: alcohol_last_time present but alcohol_intake is not true",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_alcohol_last_time ?time .\n                FILTER NOT EXISTS {\n                    $this sleep:diary_alcohol_intake \"true\"^^xsd:boolean .\n                }\n            }\n        "
	},
	{
		axiom_id: "63",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NoCaffeineImpliesNoTimeShape",
		message: "Axiom 63: caffeine_intake=false but caffeine_last_time is present",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_caffeine_intake \"false\"^^xsd:boolean .\n                $this sleep:diary_caffeine_last_time ?time .\n            }\n        "
	},
	{
		axiom_id: "64",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ZeroAwakeningsImpliesZeroWASOShape",
		message: "Axiom 64: number_of_awakenings=0 but WASO > 0",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_number_of_awakenings ?n .\n                $this sleep:diary_waso_minutes ?waso .\n                FILTER(xsd:integer(?n) = 0)\n                FILTER(xsd:decimal(?waso) > 0)\n            }\n        "
	},
	{
		axiom_id: "65",
		shape_iri: "https://w3id.org/sleep-diary-ontology/PositiveWASOImpliesAwakeningsShape",
		message: "Axiom 65: WASO > 0 but number_of_awakenings=0",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_waso_minutes ?waso .\n                $this sleep:diary_number_of_awakenings ?n .\n                FILTER(xsd:decimal(?waso) > 0)\n                FILTER(xsd:integer(?n) = 0)\n            }\n        "
	},
	{
		axiom_id: "66",
		shape_iri: "https://w3id.org/sleep-diary-ontology/WASOPerAwakeningRatioShape",
		message: "Axiom 66: WASO/awakenings ratio > 60 min per awakening",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_waso_minutes ?waso .\n                $this sleep:diary_number_of_awakenings ?n .\n                FILTER(xsd:integer(?n) > 0)\n                BIND(xsd:decimal(?waso) / xsd:integer(?n) AS ?ratio)\n                FILTER(?ratio > 60)\n            }\n        "
	},
	{
		axiom_id: "67",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NoNapOccurredButEpisodesExistShape",
		message: "Axiom 67: diary_nap_occurred=false but nap episodes exist",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_nap_occurred \"false\"^^xsd:boolean .\n                $this sleep:diary_nap_episodes ?nap .\n            }\n        "
	},
	{
		axiom_id: "68",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapEpisodeCountMatchShape",
		message: "Axiom 68: nap episode count does not match list length",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_nap_occurred \"true\"^^xsd:boolean .\n                {\n                    SELECT $this (COUNT(?nap) AS ?napCount)\n                    WHERE {\n                        $this sleep:diary_nap_episodes ?nap .\n                    }\n                    GROUP BY $this\n                }\n                FILTER(?napCount = 0)\n            }\n        "
	},
	{
		axiom_id: "69",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapEpisodeNonOverlapShape",
		message: "Axiom 69: Nap episodes overlap in time",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_nap_episodes ?nap1 .\n                $this sleep:diary_nap_episodes ?nap2 .\n                FILTER(?nap1 != ?nap2)\n                ?nap1 sleep:nap_start_time ?s1 .\n                ?nap1 sleep:nap_end_time ?e1 .\n                ?nap2 sleep:nap_start_time ?s2 .\n                ?nap2 sleep:nap_end_time ?e2 .\n                FILTER(STR(?s1) < STR(?s2))\n                FILTER(STR(?e1) > STR(?s2))\n            }\n        "
	},
	{
		axiom_id: "7",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NapWithinWakePeriodShape",
		message: "Axiom 7: Nap time falls outside the wake period (before wake or after bed)",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:nap_start_time_minutes ?napMin .\n                $this sleep:diary_wake_time_minutes ?wakeMin .\n                $this sleep:diary_in_bed_time_cmp ?bedCmp .\n                FILTER(?napMin < ?wakeMin || ?napMin > ?bedCmp)\n            }\n        "
	},
	{
		axiom_id: "70",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NonwearEpisodeNonOverlapShape",
		message: "Axiom 70: Nonwear episodes overlap in time",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_nonwear_episodes ?nw1 .\n                $this sleep:diary_nonwear_episodes ?nw2 .\n                FILTER(?nw1 != ?nw2)\n                ?nw1 sleep:nonwear_start_time ?s1 .\n                ?nw1 sleep:nonwear_end_time ?e1 .\n                ?nw2 sleep:nonwear_start_time ?s2 .\n                ?nw2 sleep:nonwear_end_time ?e2 .\n                FILTER(STR(?s1) < STR(?s2))\n                FILTER(STR(?e1) > STR(?s2))\n            }\n        "
	},
	{
		axiom_id: "71",
		shape_iri: "https://w3id.org/sleep-diary-ontology/WakeRiseSameTypeRiskShape",
		message: "Axiom 71: wake_time = out_of_bed_time — same-type confusion risk",
		severity: "Info",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_wake_time ?wake .\n                $this sleep:diary_out_of_bed_time ?rise .\n                FILTER(STR(?wake) = STR(?rise))\n            }\n        "
	},
	{
		axiom_id: "72",
		shape_iri: "https://w3id.org/sleep-diary-ontology/BedLightsoutSameTypeRiskShape",
		message: "Axiom 72: in_bed_time = try_to_sleep_time — same-type confusion risk",
		severity: "Info",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time ?bed .\n                $this sleep:diary_try_to_sleep_time ?lights .\n                FILTER(STR(?bed) = STR(?lights))\n            }\n        "
	},
	{
		axiom_id: "73",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DozingOnsetBeforeOffsetShape",
		message: "Axiom 73: dozing_start_time >= dozing_end_time",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_dozing_episodes ?ep .\n                ?ep sleep:dozing_start_time ?start .\n                ?ep sleep:dozing_end_time ?end .\n                FILTER(STR(?start) >= STR(?end))\n            }\n        "
	},
	{
		axiom_id: "74",
		shape_iri: "https://w3id.org/sleep-diary-ontology/NonwearOnsetBeforeOffsetShape",
		message: "Axiom 74: nonwear_start_time >= nonwear_end_time",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_nonwear_episodes ?ep .\n                ?ep sleep:nonwear_start_time ?start .\n                ?ep sleep:nonwear_end_time ?end .\n                FILTER(STR(?start) >= STR(?end))\n            }\n        "
	},
	{
		axiom_id: "75",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DLMOPlausibilityShape",
		message: "Axiom 75: DLMO time outside typical range (18:00-02:00)",
		severity: "Warning",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_dlmo_time ?dlmo .\n                FILTER(\n                    STR(?dlmo) >= \"02:00\" &&\n                    STR(?dlmo) < \"18:00\"\n                )\n            }\n        "
	},
	{
		axiom_id: "76",
		shape_iri: "https://w3id.org/sleep-diary-ontology/ScreenTimeRangeShape",
		message: "Axiom 76: screen_time_before_bed outside range 0-480",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_screen_time_before_bed ?val .\n                BIND(xsd:decimal(?val) AS ?num)\n                FILTER(?num < 0 || ?num > 480)\n            }\n        "
	},
	{
		axiom_id: "77",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepQualityRangeShape",
		message: "Axiom 77: sleep_quality outside valid range",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_quality ?val .\n                FILTER(\n                    STR(?val) != \"very_poor\" &&\n                    STR(?val) != \"poor\" &&\n                    STR(?val) != \"fair\" &&\n                    STR(?val) != \"good\" &&\n                    STR(?val) != \"very_good\"\n                )\n            }\n        "
	},
	{
		axiom_id: "78",
		shape_iri: "https://w3id.org/sleep-diary-ontology/MenstrualDayRangeShape",
		message: "Axiom 78: menstrual_day outside range 1-45",
		severity: "Violation",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_menstrual_day ?val .\n                BIND(xsd:integer(?val) AS ?num)\n                FILTER(?num < 1 || ?num > 45)\n            }\n        "
	},
	{
		axiom_id: "79",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DozingWithinWakePeriodShape",
		message: "Axiom 79: dozing episode overlaps with main sleep period",
		severity: "Warning",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_dozing_episodes ?ep .\n                ?ep sleep:dozing_start_time ?doz_start .\n                $this sleep:diary_sleep_onset_time ?onset .\n                $this sleep:diary_wake_time ?wake .\n                FILTER(\n                    STR(?doz_start) >= STR(?onset) &&\n                    STR(?doz_start) <= STR(?wake)\n                )\n            }\n        "
	},
	{
		axiom_id: "80",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepEfficiencyTstTibConsistencyShape",
		message: "Axiom 80: sleep_efficiency_percent inconsistent with TST/TIB",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_efficiency_percent ?se .\n                $this sleep:diary_total_sleep_time_minutes ?tst .\n                $this sleep:diary_time_in_bed_minutes ?tib .\n                FILTER(xsd:decimal(?tib) > 0)\n                BIND((xsd:decimal(?tst) / xsd:decimal(?tib)) * 100 AS ?expected)\n                FILTER(ABS(xsd:decimal(?se) - ?expected) > 5)\n            }\n        "
	},
	{
		axiom_id: "81",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TimezoneConsistencyShape",
		message: "Axiom 81: Participant has entries with different entry_timezone values — possible data-entry error or undeclared multi-site enrolment",
		severity: "Warning",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:participant_id ?pid .\n                $this sleep:entry_timezone ?tz1 .\n                ?other sleep:participant_id ?pid .\n                ?other sleep:entry_timezone ?tz2 .\n                FILTER($this != ?other)\n                FILTER(STR(?tz1) != STR(?tz2))\n                FILTER(STR($this) > STR(?other))\n            }\n        "
	},
	{
		axiom_id: "82",
		shape_iri: "https://w3id.org/sleep-diary-ontology/DstDurationImpactShape",
		message: "Axiom 82: Entry falls in a DST-transition month with an explicit timezone — duration fields may require DST-aware correction (±60 min)",
		severity: "Info",
		scope: null,
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n            SELECT $this WHERE {\n                $this sleep:entry_timezone ?tz .\n                $this sleep:diary_sleep_date ?sd .\n                BIND(xsd:integer(SUBSTR(STR(?sd), 6, 2)) AS ?month)\n                FILTER(?month = 3 || ?month = 4 || ?month = 10 || ?month = 11)\n            }\n        "
	},
	{
		axiom_id: "9",
		shape_iri: "https://w3id.org/sleep-diary-ontology/SleepNapDisjointShape",
		message: "Axiom 9: Nap period overlaps with main sleep period",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time_cmp ?sOnCmp .\n                $this sleep:diary_wake_time_cmp ?sOffCmp .\n                $this sleep:nap_start_time_minutes ?nOnMin .\n                $this sleep:nap_end_time_minutes ?nOffMin .\n                FILTER(?nOnMin < ?sOffCmp && ?nOffMin > ?sOnCmp)\n            }\n        "
	},
	{
		axiom_id: "main_sleep_1_2",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_in_bed_time_before_diary_try_to_sleep_time",
		message: "diary_in_bed_time must be <= diary_try_to_sleep_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_cmp ?minA .\n                $this sleep:diary_try_to_sleep_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n            }\n        "
	},
	{
		axiom_id: "main_sleep_1_3",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_in_bed_time_before_diary_sleep_onset_time",
		message: "diary_in_bed_time must be <= diary_sleep_onset_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_cmp ?minA .\n                $this sleep:diary_sleep_onset_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_try_to_sleep_time_cmp ?mid0 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_1_4",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_in_bed_time_before_diary_wake_time",
		message: "diary_in_bed_time must be <= diary_wake_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_cmp ?minA .\n                $this sleep:diary_wake_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_try_to_sleep_time_cmp ?mid0 }\n                FILTER NOT EXISTS { $this sleep:diary_sleep_onset_time_cmp ?mid1 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_1_5",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_in_bed_time_before_diary_out_of_bed_time",
		message: "diary_in_bed_time must be <= diary_out_of_bed_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_in_bed_time_cmp ?minA .\n                $this sleep:diary_out_of_bed_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_try_to_sleep_time_cmp ?mid0 }\n                FILTER NOT EXISTS { $this sleep:diary_sleep_onset_time_cmp ?mid1 }\n                FILTER NOT EXISTS { $this sleep:diary_wake_time_cmp ?mid2 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_2_3",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_try_to_sleep_time_before_diary_sleep_onset_time",
		message: "diary_try_to_sleep_time must be <= diary_sleep_onset_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_try_to_sleep_time_cmp ?minA .\n                $this sleep:diary_sleep_onset_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n            }\n        "
	},
	{
		axiom_id: "main_sleep_2_4",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_try_to_sleep_time_before_diary_wake_time",
		message: "diary_try_to_sleep_time must be <= diary_wake_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_try_to_sleep_time_cmp ?minA .\n                $this sleep:diary_wake_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_sleep_onset_time_cmp ?mid0 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_2_5",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_try_to_sleep_time_before_diary_out_of_bed_time",
		message: "diary_try_to_sleep_time must be <= diary_out_of_bed_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_try_to_sleep_time_cmp ?minA .\n                $this sleep:diary_out_of_bed_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_sleep_onset_time_cmp ?mid0 }\n                FILTER NOT EXISTS { $this sleep:diary_wake_time_cmp ?mid1 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_3_4",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_sleep_onset_time_before_diary_wake_time",
		message: "diary_sleep_onset_time must be <= diary_wake_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time_cmp ?minA .\n                $this sleep:diary_wake_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n            }\n        "
	},
	{
		axiom_id: "main_sleep_3_5",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_sleep_onset_time_before_diary_out_of_bed_time",
		message: "diary_sleep_onset_time must be <= diary_out_of_bed_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_sleep_onset_time_cmp ?minA .\n                $this sleep:diary_out_of_bed_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n                FILTER NOT EXISTS { $this sleep:diary_wake_time_cmp ?mid0 }\n            }\n        "
	},
	{
		axiom_id: "main_sleep_4_5",
		shape_iri: "https://w3id.org/sleep-diary-ontology/TemporalOrder_diary_wake_time_before_diary_out_of_bed_time",
		message: "diary_wake_time must be <= diary_out_of_bed_time",
		severity: "Warning",
		scope: "entry",
		select_body: "\n            PREFIX sleep: <https://w3id.org/sleep-diary-ontology/>\n            SELECT $this WHERE {\n                $this sleep:diary_wake_time_cmp ?minA .\n                $this sleep:diary_out_of_bed_time_cmp ?minB .\n                FILTER(?minA > ?minB)\n            }\n        "
	}
];
function b(e) {
	return e.replace(/\$this\b/g, "?this");
}
function f(e) {
	return e.startsWith("urn:sleepentry:") ? e.slice(15) : e;
}
let $ = null;
r({ runDiaryAxioms: async function(e) {
	const i = new (await (async function() {
		return null === $ && ($ = (async () => {
			const e = await import("./web-CrQoLeDB.js"), i = e.default;
			return "function" == typeof i && await i(), e;
		})()), $;
	}())).Store(), t = await async function(e) {
		await (null === S && (S = (async () => {
			const { default: e } = await T();
			if ("undefined" != typeof process && Boolean(process.versions?.node)) {
				const i = "node:fs/promises", t = "node:path", s = await import(i), n = (await import(t)).resolve(process.cwd(), "src/wasm/pkg/diary-rdf/diary_rdf_bg.wasm");
				await e({ module_or_path: await s.readFile(n) });
			} else await e();
		})()), S);
		const { entriesToNtriples: i } = await T();
		return i(JSON.stringify(e));
	}(e);
	t.length > 0 && i.load(t, { format: "application/n-triples" });
	const s = [], n = [];
	for (const a of I) {
		const e = b(a.select_body);
		let t;
		try {
			t = i.query(e);
		} catch (o) {
			n.push({
				axiomId: a.axiom_id,
				shapeIri: a.shape_iri,
				error: o instanceof Error ? `${o.name}: ${o.message}` : String(o)
			});
			continue;
		}
		for (const i of t) {
			const e = i.get("this");
			e && s.push({
				axiomId: a.axiom_id,
				focusNode: f(e.value),
				severity: a.severity,
				message: a.message
			});
		}
	}
	return {
		violations: s,
		erroredShapes: n
	};
} });

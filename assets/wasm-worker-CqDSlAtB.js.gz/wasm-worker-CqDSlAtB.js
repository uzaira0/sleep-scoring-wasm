/**
* @license
* Copyright 2019 Google LLC
* SPDX-License-Identifier: Apache-2.0
*/
const e = Symbol("Comlink.proxy"), n = Symbol("Comlink.endpoint"), t = Symbol("Comlink.releaseProxy"), r = Symbol("Comlink.finalizer"), a = Symbol("Comlink.thrown"), o = (e) => "object" == typeof e && null !== e || "function" == typeof e, i = /* @__PURE__ */ new Map([["proxy", {
	canHandle: (n) => o(n) && n[e],
	serialize(e) {
		const { port1: n, port2: t } = new MessageChannel();
		return s(e, n), [t, [t]];
	},
	deserialize: (e) => (e.start(), function(e) {
		const n = /* @__PURE__ */ new Map();
		return e.addEventListener("message", function(e) {
			const { data: t } = e;
			if (!t || !t.id) return;
			const r = n.get(t.id);
			if (r) try {
				r(t);
			} finally {
				n.delete(t.id);
			}
		}), m(e, n, [], void 0);
	}(e))
}], ["throw", {
	canHandle: (e) => o(e) && a in e,
	serialize({ value: e }) {
		let n;
		return n = e instanceof Error ? {
			isError: !0,
			value: {
				message: e.message,
				name: e.name,
				stack: e.stack
			}
		} : {
			isError: !1,
			value: e
		}, [n, []];
	},
	deserialize(e) {
		if (e.isError) throw Object.assign(new Error(e.value.message), e.value);
		throw e.value;
	}
}]]);
function s(n, t = globalThis, o = ["*"]) {
	t.addEventListener("message", function i(l) {
		if (!l || !l.data) return;
		if (!function(e, n) {
			for (const t of e) {
				if (n === t || "*" === t) return !0;
				if (t instanceof RegExp && t.test(n)) return !0;
			}
			return !1;
		}(o, l.origin)) return void console.warn(`Invalid origin '${l.origin}' for comlink proxy`);
		const { id: u, type: d, path: p } = Object.assign({ path: [] }, l.data), m = (l.data.argumentList || []).map(h);
		let f;
		try {
			const t = p.slice(0, -1).reduce((e, n) => e[n], n), r = p.reduce((e, n) => e[n], n);
			switch (d) {
				case "GET":
					f = r;
					break;
				case "SET":
					t[p.slice(-1)[0]] = h(l.data.value), f = !0;
					break;
				case "APPLY":
					f = r.apply(t, m);
					break;
				case "CONSTRUCT":
					f = function(n) {
						return Object.assign(n, { [e]: !0 });
					}(new r(...m));
					break;
				case "ENDPOINT":
					{
						const { port1: e, port2: t } = new MessageChannel();
						s(n, t), f = g(e, [e]);
					}
					break;
				case "RELEASE":
					f = void 0;
					break;
				default: return;
			}
		} catch (y) {
			f = {
				value: y,
				[a]: 0
			};
		}
		Promise.resolve(f).catch((e) => ({
			value: e,
			[a]: 0
		})).then((e) => {
			const [a, o] = _(e);
			t.postMessage(Object.assign(Object.assign({}, a), { id: u }), o), "RELEASE" === d && (t.removeEventListener("message", i), c(t), r in n && "function" == typeof n[r] && n[r]());
		}).catch((e) => {
			const [n, r] = _({
				value: /* @__PURE__ */ new TypeError("Unserializable return value"),
				[a]: 0
			});
			t.postMessage(Object.assign(Object.assign({}, n), { id: u }), r);
		});
	}), t.start && t.start();
}
function c(e) {
	(function(e) {
		return "MessagePort" === e.constructor.name;
	})(e) && e.close();
}
function l(e) {
	if (e) throw new Error("Proxy has been released and is not useable");
}
function u(e) {
	return w(e, /* @__PURE__ */ new Map(), { type: "RELEASE" }).then(() => {
		c(e);
	});
}
const d = /* @__PURE__ */ new WeakMap(), p = "FinalizationRegistry" in globalThis && new FinalizationRegistry((e) => {
	const n = (d.get(e) || 0) - 1;
	d.set(e, n), 0 === n && u(e);
});
function m(e, r, a = [], o = function() {}) {
	let i = !1;
	const s = new Proxy(o, {
		get(n, o) {
			if (l(i), o === t) return () => {
				(function(e) {
					p && p.unregister(e);
				})(s), u(e), r.clear(), i = !0;
			};
			if ("then" === o) {
				if (0 === a.length) return { then: () => s };
				const n = w(e, r, {
					type: "GET",
					path: a.map((e) => e.toString())
				}).then(h);
				return n.then.bind(n);
			}
			return m(e, r, [...a, o]);
		},
		set(n, t, o) {
			l(i);
			const [s, c] = _(o);
			return w(e, r, {
				type: "SET",
				path: [...a, t].map((e) => e.toString()),
				value: s
			}, c).then(h);
		},
		apply(t, o, s) {
			l(i);
			const c = a[a.length - 1];
			if (c === n) return w(e, r, { type: "ENDPOINT" }).then(h);
			if ("bind" === c) return m(e, r, a.slice(0, -1));
			const [u, d] = f(s);
			return w(e, r, {
				type: "APPLY",
				path: a.map((e) => e.toString()),
				argumentList: u
			}, d).then(h);
		},
		construct(n, t) {
			l(i);
			const [o, s] = f(t);
			return w(e, r, {
				type: "CONSTRUCT",
				path: a.map((e) => e.toString()),
				argumentList: o
			}, s).then(h);
		}
	});
	return function(e, n) {
		const t = (d.get(n) || 0) + 1;
		d.set(n, t), p && p.register(e, n, e);
	}(s, e), s;
}
function f(e) {
	const n = e.map(_);
	return [n.map((e) => e[0]), (t = n.map((e) => e[1]), Array.prototype.concat.apply([], t))];
	var t;
}
const y = /* @__PURE__ */ new WeakMap();
function g(e, n) {
	return y.set(e, n), e;
}
function _(e) {
	for (const [n, t] of i) if (t.canHandle(e)) {
		const [r, a] = t.serialize(e);
		return [{
			type: "HANDLER",
			name: n,
			value: r
		}, a];
	}
	return [{
		type: "RAW",
		value: e
	}, y.get(e) || []];
}
function h(e) {
	switch (e.type) {
		case "HANDLER": return i.get(e.name).deserialize(e.value);
		case "RAW": return e.value;
	}
}
function w(e, n, t, r) {
	return new Promise((a) => {
		const o = new Array(4).fill(0).map(() => Math.floor(Math.random() * Number.MAX_SAFE_INTEGER).toString(16)).join("-");
		n.set(o, a), e.start && e.start(), e.postMessage(Object.assign({ id: o }, t), r);
	});
}
const b = "smart", v = "webster", S = {
	choi_2011: "choi_2011",
	flat_activity: "flat_activity",
	gt3x_capsense: "gt3x_capsense",
	actiware_off_wrist: "actiware_off_wrist",
	detach_nonwear: "detach_nonwear",
	van_hees_2013: "van_hees_2013",
	van_hees_2023: "van_hees_2023",
	ggir_part2_invalid: "ggir_part2_invalid",
	choi_2012: "choi_2012",
	troiano_2008: "troiano_2008",
	notworn_hasib: "notworn_hasib",
	ahmadi_2020: "ahmadi_2020",
	skovgaard_2023: "skovgaard_2023"
}, A = {
	diary: "diary",
	hdcza: "hdcza",
	l5: "l5",
	selected_scorer_first_last: "selected_scorer_first_last",
	selected_scorer_longest_bout: "selected_scorer_longest_bout",
	quiet_bout: "quiet_bout",
	event_marker: "event_marker",
	actiware_rest_interval: "actiware_rest_interval",
	none: "none"
}, M = A.diary, E = A.hdcza, x = A.l5, k = A.selected_scorer_first_last, I = A.selected_scorer_longest_bout, C = A.quiet_bout, T = A.event_marker, N = A.actiware_rest_interval, z = A.none, F = "use_source_a", R = {
	sourceA: "hdcza",
	sourceB: "selected_scorer_first_last",
	fusionPolicy: "source_b_bounded_by_source_a",
	mergeGapMinutes: 45,
	paddingMinutes: 0,
	minOverlapJaccard: .5,
	applyNonwearGate: !1
}, U = {
	[M]: "Diary",
	[E]: "HDCZA SPT",
	[x]: "L5 least active 5h",
	[k]: "Selected scorer first-last sleep",
	[I]: "Selected scorer longest sleep bout",
	[C]: "Quiet-bout least-active window",
	[T]: "Event markers (button presses)",
	[N]: "Actiware rest interval",
	[z]: "None"
};
function G(e) {
	const n = e ?? {};
	return {
		...R,
		sourceA: n.sourceA ?? n.source_a ?? R.sourceA,
		sourceB: n.sourceB ?? n.source_b ?? R.sourceB,
		fusionPolicy: n.fusionPolicy ?? n.fusion_policy ?? R.fusionPolicy,
		mergeGapMinutes: n.mergeGapMinutes ?? n.merge_gap_minutes ?? R.mergeGapMinutes,
		paddingMinutes: n.paddingMinutes ?? n.padding_minutes ?? R.paddingMinutes,
		minOverlapJaccard: n.minOverlapJaccard ?? n.min_overlap_jaccard ?? R.minOverlapJaccard,
		applyNonwearGate: n.applyNonwearGate ?? n.apply_nonwear_gate ?? R.applyNonwearGate
	};
}
Object.values(A).map((e) => ({
	value: e,
	label: U[e]
}));
const O = [
	{
		id: "sadeh_1994_original",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "sadeh_1994::original",
		family: "sadeh_1994",
		implementation: "original",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "sadeh_1994_actilife",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "sadeh_1994::actilife",
		family: "sadeh_1994",
		implementation: "actilife",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "cole_kripke_1992_original",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "cole_kripke_1992::original",
		family: "cole_kripke_1992",
		implementation: "original",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "cole_kripke_1992_actilife",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "cole_kripke_1992::actilife",
		family: "cole_kripke_1992",
		implementation: "actilife",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "sadeh_1994_ggir",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "sadeh_1994::ggir",
		family: "sadeh_1994",
		implementation: "ggir",
		defaultCountMetric: "neishabouri",
		compatibleCountMetrics: ["neishabouri", "zero_crossing"],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "cole_kripke_1992_ggir",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "cole_kripke_1992::ggir",
		family: "cole_kripke_1992",
		implementation: "ggir",
		defaultCountMetric: "neishabouri",
		compatibleCountMetrics: ["neishabouri", "zero_crossing"],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "van_hees_2015",
		kind: "sleep_wake",
		requiredSignal: "angle_z",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "angle_spt",
		methodImplementationId: "van_hees_2015::ggir",
		family: "van_hees_2015",
		implementation: "ggir",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_5s"
	},
	{
		id: "van_hees_hasib_2015",
		kind: "sleep_wake",
		requiredSignal: "angle_z",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "angle_spt",
		methodImplementationId: "van_hees_hasib_2015::hasib",
		family: "van_hees_hasib_2015",
		implementation: "hasib",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_5s"
	},
	{
		id: "natural_language",
		kind: "sleep_wake",
		requiredSignal: "none",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "natural_language",
		methodImplementationId: "natural_language::reference",
		family: "natural_language",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "consensus_majority_vote",
		kind: "sleep_wake",
		requiredSignal: "epoch_scores",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "consensus_majority_vote::reference",
		family: "consensus_majority_vote",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "lstm_sleep_wake",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "neural_model",
		methodImplementationId: "lstm_sleep_wake::reference",
		family: "lstm_sleep_wake",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_5s"
	},
	{
		id: "manual",
		kind: "sleep_wake",
		requiredSignal: "none",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "manual",
		methodImplementationId: "manual::reference",
		family: "manual",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "oakley_1997",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [
			15,
			30,
			60
		],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "oakley_1997::hasib",
		family: "oakley_1997",
		implementation: "hasib",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "actiware_sleep_wake",
		kind: "sleep_wake",
		requiredSignal: "none",
		requiresTemperature: !1,
		nativeEpochSeconds: 30,
		supportedEpochSeconds: [30],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "vendor_analysis",
		methodImplementationId: "actiware_sleep_wake::actiware",
		family: "actiware_sleep_wake",
		implementation: "actiware",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "galland_2012",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "galland_2012::hasib",
		family: "galland_2012",
		implementation: "hasib",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "ucsd_scripps_2010",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 30,
		supportedEpochSeconds: [30],
		bindingEntry: "score_epochs",
		conformance: "conformant",
		execution: "count_scorer",
		methodImplementationId: "ucsd_scripps_2010::reference",
		family: "ucsd_scripps_2010",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "sazonov_2004",
		kind: "sleep_wake",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 30,
		supportedEpochSeconds: [30],
		bindingEntry: "score_epochs",
		conformance: "provisional",
		execution: "count_scorer",
		methodImplementationId: "sazonov_2004::reference",
		family: "sazonov_2004",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: "epoch_60s"
	},
	{
		id: "syed_cnn",
		kind: "sleep_wake",
		requiredSignal: "raw_accel",
		requiresTemperature: !1,
		nativeEpochSeconds: 30,
		supportedEpochSeconds: [30],
		bindingEntry: "score_epochs",
		conformance: "needs_model",
		execution: "neural_model",
		methodImplementationId: "syed_cnn::reference",
		family: "syed_cnn",
		implementation: "reference",
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: "syed_cnn trained sleep/wake CNN checkpoint (weights + preprocessing spec)",
		displayGrid: "epoch_60s"
	},
	{
		id: "choi_2011",
		kind: "nonwear",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "choi_2011",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "flat_activity",
		kind: "nonwear",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "flat_activity",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "gt3x_capsense",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "raw_detector",
		methodImplementationId: "gt3x_capsense",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "actiware_off_wrist",
		kind: "nonwear",
		requiredSignal: "none",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "device_statement",
		methodImplementationId: "actiware_off_wrist",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "detach_nonwear",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !0,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "detach_nonwear",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "van_hees_2013",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "raw_detector",
		methodImplementationId: "van_hees_2013",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "van_hees_2023",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "raw_detector",
		methodImplementationId: "van_hees_2023",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "ggir_part2_invalid",
		kind: "nonwear",
		requiredSignal: "none",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "ggir_part2",
		methodImplementationId: "ggir_part2_invalid",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "choi_2012",
		kind: "nonwear",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "choi_2012",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "troiano_2008",
		kind: "nonwear",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 60,
		supportedEpochSeconds: [60],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "troiano_2008",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "notworn_hasib",
		kind: "nonwear",
		requiredSignal: "counts_axis_y",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "detect_nonwear",
		conformance: "conformant",
		execution: "count_detector",
		methodImplementationId: "notworn_hasib",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "ahmadi_2020",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !1,
		nativeEpochSeconds: 5,
		supportedEpochSeconds: [5],
		bindingEntry: "detect_nonwear",
		conformance: "provisional",
		execution: "raw_detector",
		methodImplementationId: "ahmadi_2020",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: null,
		displayGrid: null
	},
	{
		id: "skovgaard_2023",
		kind: "nonwear",
		requiredSignal: "raw_accel",
		requiresTemperature: !0,
		nativeEpochSeconds: 30,
		supportedEpochSeconds: [30],
		bindingEntry: "detect_nonwear",
		conformance: "needs_model",
		execution: "raw_detector",
		methodImplementationId: "skovgaard_2023",
		family: null,
		implementation: null,
		defaultCountMetric: null,
		compatibleCountMetrics: [],
		needsModelArtifact: "skovgaard_2023 trained temperature-nonwear model (weights + feature spec)",
		displayGrid: null
	}
], W = [
	{
		id: "epoch_60s",
		epochSeconds: 60,
		timestampsKey: "timestamps"
	},
	{
		id: "epoch_5s",
		epochSeconds: 5,
		timestampsKey: "ggirTimestamps"
	},
	{
		id: "epoch_30s",
		epochSeconds: 30,
		timestampsKey: "timestamps30s"
	}
], P = ([
	{
		id: "consecutive_onset3s_offset5s",
		onsetMinConsecutiveSleep: 3,
		offsetMinConsecutiveMinutes: 5,
		offsetScanState: "sleep",
		label: "3-min Onset / 5-min Offset (Default)"
	},
	{
		id: "consecutive_onset5s_offset10s",
		onsetMinConsecutiveSleep: 5,
		offsetMinConsecutiveMinutes: 10,
		offsetScanState: "sleep",
		label: "5-min Onset / 10-min Offset"
	},
	{
		id: "tudor_locke_2014",
		onsetMinConsecutiveSleep: 5,
		offsetMinConsecutiveMinutes: 10,
		offsetScanState: "wake",
		label: "Tudor-Locke (2014)"
	}
].map((e) => e.id), O.map((e) => e.id), [{
	id: "choi_plus_flat",
	components: ["choi_2011", "flat_activity"],
	combine: "union"
}, {
	id: "diary_anchored",
	components: ["choi_2011"],
	combine: "priority"
}].map((e) => e.id), {
	method_family_ids: {
		sadeh_1994: {},
		cole_kripke_1992: {},
		oakley_1997: {},
		galland_2012: {},
		ucsd_scripps_2010: {},
		sazonov_2004: {}
	},
	fixed_output_method_binding_ids: { van_hees_2015: {} },
	count_provenance_implementation_variant_ids: {
		actilife: {},
		original: {}
	},
	consensus_strategy_ids: {
		majority_tie_sleep: {},
		strict_majority: {},
		intersection_sleep: {},
		union_sleep: {}
	},
	count_input_series_keys: {
		neishabouri_x_30s: {
			count_family: "neishabouri",
			axis: "x",
			epoch_seconds: 30
		},
		neishabouri_x_60s: {
			count_family: "neishabouri",
			axis: "x",
			epoch_seconds: 60
		},
		neishabouri_y_30s: {
			count_family: "neishabouri",
			axis: "y",
			epoch_seconds: 30
		},
		neishabouri_y_60s: {
			count_family: "neishabouri",
			axis: "y",
			epoch_seconds: 60
		},
		neishabouri_z_30s: {
			count_family: "neishabouri",
			axis: "z",
			epoch_seconds: 30
		},
		neishabouri_z_60s: {
			count_family: "neishabouri",
			axis: "z",
			epoch_seconds: 60
		},
		neishabouri_vm_30s: {
			count_family: "neishabouri",
			axis: "vm",
			epoch_seconds: 30
		},
		neishabouri_vm_60s: {
			count_family: "neishabouri",
			axis: "vm",
			epoch_seconds: 60
		},
		zero_crossing_x_30s: {
			count_family: "zero_crossing",
			axis: "x",
			epoch_seconds: 30
		},
		zero_crossing_x_60s: {
			count_family: "zero_crossing",
			axis: "x",
			epoch_seconds: 60
		},
		zero_crossing_y_30s: {
			count_family: "zero_crossing",
			axis: "y",
			epoch_seconds: 30
		},
		zero_crossing_y_60s: {
			count_family: "zero_crossing",
			axis: "y",
			epoch_seconds: 60
		},
		zero_crossing_z_30s: {
			count_family: "zero_crossing",
			axis: "z",
			epoch_seconds: 30
		},
		zero_crossing_z_60s: {
			count_family: "zero_crossing",
			axis: "z",
			epoch_seconds: 60
		}
	},
	fixed_output_series_keys: { anglez_5s: {
		axis: "z",
		epoch_seconds: 5
	} },
	epoch_suffixes: {
		"30s": { epoch_seconds: 30 },
		"60s": { epoch_seconds: 60 }
	}
}), D = [
	{
		grammarId: "count_cell",
		cellRole: "planner_output_cell",
		outputFamilyId: "count_hasib",
		segmentSeparator: "__",
		legacyTemplateFieldIds: ["count_config_id_template", "count_provenance_config_id_template"],
		segments: [
			{
				segmentRole: "root",
				literalValue: "hasib"
			},
			{
				segmentRole: "method_family",
				parameterId: "algorithm_id",
				valueEnumerationId: "method_family_ids"
			},
			{
				segmentRole: "implementation_variant",
				parameterId: "implementation_variant",
				valueEnumerationId: "count_provenance_implementation_variant_ids",
				optional: !0
			},
			{
				segmentRole: "series_key",
				valueEnumerationId: "count_input_series_keys",
				captures: [
					{
						captureId: "count_family",
						parameterId: "count_family"
					},
					{
						captureId: "axis",
						parameterId: "axis"
					},
					{
						captureId: "epoch_seconds",
						parameterId: "epoch_seconds"
					}
				]
			}
		]
	},
	{
		grammarId: "angle_cell",
		cellRole: "planner_output_cell",
		outputFamilyId: "angle_hasib",
		segmentSeparator: "__",
		segments: [
			{
				segmentRole: "root",
				literalValue: "hasib"
			},
			{
				segmentRole: "method_family",
				valueEnumerationId: "fixed_output_method_binding_ids"
			},
			{
				segmentRole: "series_key",
				valueEnumerationId: "fixed_output_series_keys",
				captures: [{
					captureId: "axis",
					parameterId: "axis"
				}, {
					captureId: "epoch_seconds",
					parameterId: "epoch_seconds"
				}]
			}
		]
	},
	{
		grammarId: "model_cell",
		cellRole: "planner_output_cell",
		outputFamilyId: "lstm",
		segmentSeparator: "__",
		legacyTemplateFieldIds: ["model_config_id_template"],
		segments: [
			{
				segmentRole: "root",
				literalValue: "lstm"
			},
			{
				segmentRole: "model_slug",
				parameterId: "model_id"
			},
			{
				segmentRole: "preset_slug",
				tagPrefix: "threshold_"
			}
		]
	},
	{
		grammarId: "consensus_cell",
		cellRole: "planner_output_cell",
		outputFamilyId: "consensus",
		segmentSeparator: "__",
		legacyTemplateFieldIds: ["consensus_config_id_template"],
		segments: [
			{
				segmentRole: "root",
				literalValue: "consensus"
			},
			{ segmentRole: "scope" },
			{
				segmentRole: "strategy",
				parameterId: "consensus_strategy",
				valueEnumerationId: "consensus_strategy_ids"
			},
			{
				segmentRole: "suffix",
				valueEnumerationId: "epoch_suffixes",
				captures: [{
					captureId: "epoch_seconds",
					parameterId: "epoch_seconds"
				}]
			}
		]
	},
	{
		grammarId: "count_skip_entry",
		cellRole: "planner_skip_entry",
		outputFamilyId: "count_hasib",
		segmentSeparator: "__",
		segments: [{
			segmentRole: "root",
			literalValue: "count_hasib"
		}, {
			segmentRole: "method_family",
			parameterId: "algorithm_id",
			valueEnumerationId: "method_family_ids"
		}]
	},
	{
		grammarId: "scored_variant",
		cellRole: "scored_variant",
		segmentSeparator: "__",
		segments: [
			{
				segmentRole: "root",
				literalValue: "variant"
			},
			{
				segmentRole: "classifier_config_id",
				greedy: !0
			},
			{
				segmentRole: "nonwear",
				tagPrefix: "nw_"
			},
			{
				segmentRole: "period_source",
				tagPrefix: "pg_"
			},
			{
				segmentRole: "ruleset",
				tagPrefix: "rs_"
			},
			{
				segmentRole: "rescoring",
				tagPrefix: "pp_"
			}
		]
	}
];
function q(e, n) {
	const t = e.segmentSeparator, r = e.segments, a = n.split(t), o = r.findIndex((e) => !0 === e.greedy);
	let i, s;
	if (o >= 0) {
		const e = r.length - o - 1;
		if (a.length < r.length) return null;
		s = a.slice(0, o).map((e) => [e]), s.push(a.slice(o, a.length - e));
		for (const n of a.slice(a.length - e)) s.push([n]);
		i = r;
	} else {
		const e = r.flatMap((e, n) => !0 === e.optional ? [n] : []), n = r.length - a.length;
		if (n < 0 || n > e.length) return null;
		const t = new Set(e.slice(e.length - n));
		i = r.filter((e, n) => !t.has(n)), s = a.map((e) => [e]);
	}
	const c = {};
	for (let l = 0; l < i.length; l += 1) {
		const e = i[l], n = s[l];
		if (void 0 === e || void 0 === n) return null;
		let r = n.join(t);
		if (void 0 === e.literalValue) {
			if (void 0 !== e.tagPrefix) {
				if (!r.startsWith(e.tagPrefix)) return null;
				r = r.slice(e.tagPrefix.length);
			}
			if (0 === r.length) return null;
			if (void 0 !== e.valueEnumerationId) {
				const n = P[e.valueEnumerationId]?.[r];
				if (void 0 === n) return null;
				for (const [e, t] of Object.entries(n)) c[e] = t;
			}
			c[e.segmentRole] = r;
		} else if (r !== e.literalValue) return null;
	}
	return c;
}
D.filter((e) => "planner_output_cell" === e.cellRole).map((e) => `${e.segments[0]?.literalValue ?? ""}${e.segmentSeparator}`).filter((e, n, t) => t.indexOf(e) === n).sort();
const j = { family: "unknown" };
function B(e, n) {
	const t = e[n];
	return void 0 === t ? void 0 : String(t);
}
new Map(W.map((e) => [e.id, e])), new Map([
	{
		id: "axis_y",
		grid: "epoch_60s",
		seriesKey: "axisY",
		quantity: "activity_counts",
		countAxis: "y",
		label: "Y-Axis (Vertical, bandpass counts)",
		shortLabel: "Y-axis",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 7e3,
		sourceSelectable: !0,
		csvHeaderAliases: [
			"axis_y",
			"axis1",
			"y",
			"axis 1",
			"y-axis",
			"activity",
			"activity counts",
			"activitycounts",
			"counts",
			"activity_counts"
		],
		realizesSignal: "counts_axis_y"
	},
	{
		id: "axis_x",
		grid: "epoch_60s",
		seriesKey: "axisX",
		quantity: "activity_counts",
		countAxis: "x",
		label: "X-Axis (Lateral, bandpass counts)",
		shortLabel: "X-axis",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 7e3,
		sourceSelectable: !0,
		csvHeaderAliases: [
			"axis_x",
			"axis2",
			"x",
			"axis 2"
		],
		realizesSignal: null
	},
	{
		id: "axis_z",
		grid: "epoch_60s",
		seriesKey: "axisZ",
		quantity: "activity_counts",
		countAxis: "z",
		label: "Z-Axis (Forward, bandpass counts)",
		shortLabel: "Z-axis",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 7e3,
		sourceSelectable: !0,
		csvHeaderAliases: [
			"axis_z",
			"axis3",
			"z",
			"axis 3"
		],
		realizesSignal: null
	},
	{
		id: "vector_magnitude",
		grid: "epoch_60s",
		seriesKey: "vectorMagnitude",
		quantity: "activity_counts",
		countAxis: "vm",
		label: "Vector Magnitude",
		shortLabel: "VM",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 12e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: "counts_vm"
	},
	{
		id: "axis_y_30s",
		grid: "epoch_30s",
		seriesKey: "axisY30s",
		quantity: "activity_counts",
		countAxis: "y",
		label: "Y-Axis (Vertical, 30 s counts)",
		shortLabel: "Y-axis 30s",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 5e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "axis_x_30s",
		grid: "epoch_30s",
		seriesKey: "axisX30s",
		quantity: "activity_counts",
		countAxis: "x",
		label: "X-Axis (Lateral, 30 s counts)",
		shortLabel: "X-axis 30s",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 5e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "axis_z_30s",
		grid: "epoch_30s",
		seriesKey: "axisZ30s",
		quantity: "activity_counts",
		countAxis: "z",
		label: "Z-Axis (Forward, 30 s counts)",
		shortLabel: "Z-axis 30s",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 5e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "vector_magnitude_30s",
		grid: "epoch_30s",
		seriesKey: "vectorMagnitude30s",
		quantity: "activity_counts",
		countAxis: "vm",
		label: "Vector Magnitude (30 s counts)",
		shortLabel: "VM 30s",
		storedUnit: "counts",
		displayUnit: "counts",
		displayScale: 1,
		valueMin: 0,
		valueMax: 8e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "enmo",
		grid: "epoch_5s",
		seriesKey: "ggirEnmo",
		quantity: "enmo",
		countAxis: null,
		label: "ENMO (5 s, GGIR, mg)",
		shortLabel: "ENMO",
		storedUnit: "g",
		displayUnit: "mg",
		displayScale: 1e3,
		valueMin: 0,
		valueMax: 1e3,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "anglez",
		grid: "epoch_5s",
		seriesKey: "ggirAnglez",
		quantity: "anglez",
		countAxis: null,
		label: "Anglez (5 s, GGIR)",
		shortLabel: "AngleZ",
		storedUnit: "deg",
		displayUnit: "deg",
		displayScale: 1,
		valueMin: -90,
		valueMax: 90,
		sourceSelectable: !0,
		csvHeaderAliases: [],
		realizesSignal: "angle_z"
	},
	{
		id: "temperature",
		grid: "epoch_60s",
		seriesKey: "temperature",
		quantity: "temperature",
		countAxis: null,
		label: "Temperature",
		shortLabel: "Temp",
		storedUnit: "Cel",
		displayUnit: "Cel",
		displayScale: 1,
		valueMin: null,
		valueMax: null,
		sourceSelectable: !1,
		csvHeaderAliases: [
			"temperature",
			"temp",
			"skin_temp",
			"mean_temp"
		],
		realizesSignal: null
	},
	{
		id: "lux",
		grid: "epoch_60s",
		seriesKey: "lux",
		quantity: "lux",
		countAxis: null,
		label: "Light (photopic lux)",
		shortLabel: "Lux",
		storedUnit: "lx",
		displayUnit: "lx",
		displayScale: 1,
		valueMin: null,
		valueMax: null,
		sourceSelectable: !1,
		csvHeaderAliases: [],
		realizesSignal: null
	},
	{
		id: "melanopic_lux",
		grid: "epoch_60s",
		seriesKey: "melanopicLux",
		quantity: "melanopic_lux",
		countAxis: null,
		label: "Melanopic EDI",
		shortLabel: "mEDI",
		storedUnit: "lx",
		displayUnit: "lx",
		displayScale: 1,
		valueMin: null,
		valueMax: null,
		sourceSelectable: !1,
		csvHeaderAliases: [],
		realizesSignal: null
	}
].map((e) => [e.id, e]));
const L = O.filter((e) => "sleep_wake" === e.kind).map((e) => ({
	id: e.id,
	displayGrid: e.displayGrid,
	execution: e.execution,
	requiredSignal: e.requiredSignal,
	family: e.family
})), H = new Map(L.map((e) => [e.id, e]));
function V(e) {
	if (!e) return !1;
	const n = H.get(e);
	return n ? "angle_spt" === n.execution : "angle_hasib" === function(e) {
		if ("string" != typeof e || 0 === e.length) return j;
		const n = function(e) {
			let n = null;
			for (const t of D) {
				const r = q(t, e);
				if (null !== r) {
					if (null !== n) return null;
					n = {
						grammarId: t.grammarId,
						values: r
					};
				}
			}
			return n;
		}(e);
		if (null === n) return j;
		const t = n.values;
		switch (n.grammarId) {
			case "count_cell": {
				const e = B(t, "method_family"), n = B(t, "count_family"), r = B(t, "axis"), a = B(t, "epoch_seconds");
				if (void 0 === e || void 0 === n || void 0 === r || void 0 === a) return j;
				const o = B(t, "implementation_variant");
				return {
					family: "count_hasib",
					scorer: e,
					...void 0 !== o ? { provenance: o } : {},
					countSource: n,
					signalAxis: r,
					epoch: a
				};
			}
			case "angle_cell": {
				const e = B(t, "method_family"), n = B(t, "epoch_seconds");
				return void 0 === e || void 0 === n ? j : {
					family: "angle_hasib",
					scorer: e,
					signalAxis: "anglez",
					epoch: n
				};
			}
			case "model_cell": {
				const e = B(t, "model_slug"), n = B(t, "preset_slug");
				return void 0 === e || void 0 === n ? j : {
					family: "lstm",
					lstmModel: e,
					lstmThreshold: n
				};
			}
			case "consensus_cell": {
				const e = B(t, "strategy"), n = B(t, "epoch_seconds");
				return void 0 === e || void 0 === n ? j : {
					family: "consensus",
					consensusStrategy: e,
					epoch: n
				};
			}
			default: return j;
		}
	}(e).family;
}
new Map([...L].reverse().flatMap((e) => e.family ? [[e.family, e]] : [])), Math.max(...W.map((e) => 86400 / e.epochSeconds * 3));
const $ = "diary", J = "none", X = new Set(Object.values({
	SADEH_1994_ORIGINAL: "sadeh_1994_original",
	SADEH_1994_ACTILIFE: "sadeh_1994_actilife",
	COLE_KRIPKE_1992_ORIGINAL: "cole_kripke_1992_original",
	COLE_KRIPKE_1992_ACTILIFE: "cole_kripke_1992_actilife",
	SADEH_1994_GGIR: "sadeh_1994_ggir",
	COLE_KRIPKE_1992_GGIR: "cole_kripke_1992_ggir",
	VAN_HEES_2015: "van_hees_2015",
	VAN_HEES_HASIB_2015: "van_hees_hasib_2015",
	NATURAL_LANGUAGE: "natural_language",
	CONSENSUS_MAJORITY_VOTE: "consensus_majority_vote",
	LSTM_SLEEP_WAKE: "lstm_sleep_wake",
	MANUAL: "manual",
	OAKLEY_1997: "oakley_1997",
	ACTIWARE_SLEEP_WAKE: "actiware_sleep_wake",
	GALLAND_2012: "galland_2012",
	UCSD_SCRIPPS_2010: "ucsd_scripps_2010",
	SAZONOV_2004: "sazonov_2004",
	SYED_CNN: "syed_cnn"
}));
function Y(e) {
	if (!e) return [];
	const n = [];
	for (const [t, r] of e) null != t && "" !== t.trim() && n.push({
		onset_time: t,
		offset_time: r ?? null
	});
	return n;
}
function K(e) {
	if (!e) return [];
	const n = [];
	for (const [t, r] of e) null != t && null != r && "" !== t.trim() && "" !== r.trim() && n.push({
		start_time: t,
		end_time: r
	});
	return n;
}
function Z(e) {
	if (e.sleepPeriodDetection && !function(e) {
		const n = R;
		return e.sourceA === n.sourceA && e.sourceB === n.sourceB && e.fusionPolicy === n.fusionPolicy && e.mergeGapMinutes === n.mergeGapMinutes && e.paddingMinutes === n.paddingMinutes && e.minOverlapJaccard === n.minOverlapJaccard && e.applyNonwearGate === n.applyNonwearGate;
	}(G(e.sleepPeriodDetection))) {
		const n = function(e) {
			const n = G(e);
			return {
				source_a: n.sourceA,
				source_b: n.sourceB,
				fusion_policy: n.fusionPolicy,
				merge_gap_minutes: n.mergeGapMinutes,
				padding_minutes: n.paddingMinutes,
				min_overlap_jaccard: n.minOverlapJaccard,
				apply_nonwear_gate: n.applyNonwearGate
			};
		}(e.sleepPeriodDetection);
		return {
			source_a: n.source_a,
			source_b: n.source_b,
			fusion_policy: n.fusion_policy,
			apply_nonwear_gate: n.apply_nonwear_gate
		};
	}
	const n = e.periodGuider ?? b, t = Boolean(e.diaryOnsetTime) && Boolean(e.diaryWakeTime);
	return function(e, n) {
		const t = (e) => ({
			source_a: e,
			source_b: "none",
			fusion_policy: "use_source_a",
			apply_nonwear_gate: !1
		});
		switch (e) {
			case "diary": return;
			case "hdcza": return t("hdcza");
			case "l5": return t("l5");
			case "longest_bout": return t("selected_scorer_longest_bout");
			case "event_marker": return t("event_marker");
			case "actiware_rest_interval": return t("actiware_rest_interval");
			case "none": return t("none");
			case b:
				if (n.hasDiary) return;
				return t("lstm_sleep_wake" === (r = n.algorithm) ? "selected_scorer_longest_bout" : V(r) ? "hdcza" : "l5");
			default: return;
		}
		var r;
	}(n, {
		algorithm: e.algorithm ?? null,
		hasDiary: t
	});
}
function Q(e) {
	const n = { ruleset: V(e.algorithm) ? "ggir_part4" : e.ruleset ?? "legacy" };
	e.algorithm && X.has(e.algorithm) && (n.classifier = e.algorithm), null != e.epochLengthSeconds && (n.epoch_length_seconds = e.epochLengthSeconds), null != e.onsetMinConsecutiveSleep && (n.onset_min_consecutive_sleep = e.onsetMinConsecutiveSleep), null != e.offsetMinConsecutiveMinutes && (n.offset_min_consecutive_minutes = e.offsetMinConsecutiveMinutes), e.scorerPostprocessing && (n.scorer_postprocessing = e.scorerPostprocessing);
	const { nonwear_detector: t, nonwear_detectors: r } = re(e.nonwearDetectors, null, { alwaysNameSingle: !1 });
	if (t && (n.nonwear_detector = t), r && (n.nonwear_detectors = r), e.sleepPeriodDetection) {
		const t = G(e.sleepPeriodDetection);
		n.merge_gap_minutes = t.mergeGapMinutes, n.padding_minutes = t.paddingMinutes, n.min_overlap_jaccard = t.minOverlapJaccard;
	}
	const a = Z(e);
	return a && (n.detection = a), n;
}
function ee(e, n) {
	const t = te(e), r = e.map((e) => 1 << t.indexOf(e)), a = n[0]?.length ?? 0;
	return Array.from({ length: a }, (e, t) => n.reduce((e, n, a) => 1 === n[t] ? e | r[a] : e, 0));
}
const ne = Object.values(S);
function te(e) {
	const n = (e) => {
		const n = ne.indexOf(e);
		return -1 === n ? ne.length : n;
	};
	return [...e].sort((e, t) => n(e) - n(t));
}
function re(e, n, { alwaysNameSingle: t, memberFlags: r }) {
	if (!e || 0 === e.length) return {};
	if (1 === e.length) {
		const [n] = e;
		return t || n !== S.choi_2011 ? { nonwear_detector: n } : {};
	}
	return {
		nonwear_detectors: te(e),
		...n ? { nonwear_weight: [...n] } : {},
		...n && r ? { nonwear_member_flags: [...r] } : {}
	};
}
function ae(e) {
	const n = {
		analysis_date: e.analysisDate ?? "",
		epoch_length_seconds: e.epochLengthSeconds ?? 60,
		timestamps: e.timestamps,
		activity_counts: e.activityCounts,
		sleep_scores: e.sleepScores
	};
	e.choiNonwear && (n.choi_nonwear = e.choiNonwear);
	const { nonwear_weight: t, nonwear_member_flags: r } = re(e.nonwearDetectors, e.nonwearWeight, {
		alwaysNameSingle: !1,
		memberFlags: e.nonwearMemberFlags
	});
	t && (n.nonwear_weight = t), r && (n.nonwear_member_flags = r), e.ggirInvalid && (n.ggir_invalid = Array.from(e.ggirInvalid)), e.ggirHasptAlgo && (n.ggir_haspt_algo = e.ggirHasptAlgo), e.ggirDiaryHasBedlog && (n.ggir_diary_has_bedlog = !0), e.ggirDiaryHasSleeplog && (n.ggir_diary_has_sleeplog = !0), e.sensorNonwear && e.sensorNonwear.length > 0 && (n.sensor_nonwear = e.sensorNonwear.map((e) => ({
		start_ts: e.startTimestamp,
		end_ts: e.endTimestamp
	}))), null != e.diaryOnsetTime && (n.diary_onset_time = e.diaryOnsetTime), null != e.diaryWakeTime && (n.diary_wake_time = e.diaryWakeTime), null != e.diaryBedTime && (n.diary_in_bed_time = e.diaryBedTime), null != e.diaryOutBedTime && (n.diary_out_bed_time = e.diaryOutBedTime);
	const a = Y(e.diaryNaps);
	a.length > 0 && (n.diary_naps = a);
	const o = K(e.diaryNonwear);
	return o.length > 0 && (n.diary_nonwear = o), e.hdczaWindow && (n.hdcza_window = [e.hdczaWindow.startTimestamp, e.hdczaWindow.endTimestamp]), e.eventMarkerTimestamps && e.eventMarkerTimestamps.length > 0 && (n.event_marker_timestamps = Array.from(e.eventMarkerTimestamps)), e.actiwareRestWindow && (n.actiware_rest_window = [e.actiwareRestWindow.startTimestamp, e.actiwareRestWindow.endTimestamp]), null != e.nightStartHour && (n.night_start_hour = e.nightStartHour), null != e.nightEndHour && (n.night_end_hour = e.nightEndHour), n;
}
function oe(e) {
	const n = {
		analysis_date: e.analysisDate,
		epoch_length_seconds: e.epochLengthSeconds,
		timestamps: e.timestamps,
		activity_counts: e.activityCounts,
		sleep_scores: e.sleepScores
	};
	e.choiNonwear && (n.choi_nonwear = e.choiNonwear), e.nonwearWeight && (n.nonwear_weight = [...e.nonwearWeight]), e.nonwearWeight && e.nonwearMemberFlags && (n.nonwear_member_flags = [...e.nonwearMemberFlags]), e.sensorNonwear && e.sensorNonwear.length > 0 && (n.sensor_nonwear = e.sensorNonwear.map((e) => ({
		start_ts: e.startTimestamp,
		end_ts: e.endTimestamp
	}))), null != e.diaryOnsetTime && (n.diary_onset_time = e.diaryOnsetTime), null != e.diaryWakeTime && (n.diary_wake_time = e.diaryWakeTime), null != e.diaryBedTime && (n.diary_in_bed_time = e.diaryBedTime);
	const t = Y(e.diaryNaps);
	t.length > 0 && (n.diary_naps = t);
	const r = K(e.diaryNonwear);
	return r.length > 0 && (n.diary_nonwear = r), n;
}
function ie(e) {
	return e && 0 !== e.length ? e.map(([e, n]) => [e, n]) : null;
}
let se = null;
const ce = /unreachable|RuntimeError|out of bounds|wasm/i, le = /* @__PURE__ */ new WeakSet();
async function ue() {
	const e = await async function(e) {
		if (!0 !== (n = e.scope).pinnedSingleThread && n.sharedArrayBuffer && n.crossOriginIsolated && n.cores > 1) {
			let n;
			try {
				const t = await e.loadThreaded();
				if (n = t, le.has(t)) throw new Error("thread pool start was abandoned earlier in this worker");
				await t.default();
				const r = Math.min(4, e.scope.cores);
				return t.threadPoolReady() || await function(e, n) {
					let t;
					const r = new Promise((e, r) => {
						t = setTimeout(() => {
							r(/* @__PURE__ */ new Error(`thread pool did not start within ${String(n)} ms`));
						}, n);
					});
					return Promise.race([e, r]).finally(() => {
						clearTimeout(t);
					});
				}(t.startThreadPool(r), e.poolStartTimeoutMs ?? 15e3), {
					mod: t,
					runtime: {
						threaded: !0,
						threads: r
					}
				};
			} catch (r) {
				void 0 !== n && le.add(n), e.warn("[wasm] threaded runtime unavailable, using the single-thread package", r);
			}
		}
		var n;
		const t = await e.loadSingle();
		return await t.default(), {
			mod: t,
			runtime: {
				threaded: !1,
				threads: 1
			}
		};
	}({
		scope: {
			pinnedSingleThread: "actours-single-thread" === globalThis.name,
			sharedArrayBuffer: "undefined" != typeof SharedArrayBuffer,
			crossOriginIsolated: "undefined" != typeof crossOriginIsolated && crossOriginIsolated,
			cores: "undefined" != typeof navigator ? navigator.hardwareConcurrency : 1
		},
		loadThreaded: () => import("./actours-DUA9KYtS.js"),
		loadSingle: () => import("./actours-BWB_DdDH.js"),
		warn: (e, n) => {
			console.warn(e, n);
		}
	});
	return function(e) {
		const n = /* @__PURE__ */ new Float64Array(16), t = new Uint8Array(e.scoreSadeh(n, -4));
		if (16 !== t.length) throw new Error(`WASM integrity check failed: scoreSadeh length ${String(t.length)}, expected ${String(16)}`);
		for (let r = 0; r < 16; r++) if (1 !== t[r]) throw new Error(`WASM integrity check failed: scoreSadeh(zeros)[${String(r)}] = ${String(t[r])}, expected 1. Bundle may be corrupt — clear the site cache and reload.`);
	}(e.mod), e;
}
function de(e) {
	return null == e || "object" != typeof e || Array.isArray(e) ? null : e;
}
function pe(e) {
	return null === e || "object" != typeof e || Array.isArray(e) ? null : e;
}
function me(e) {
	const n = pe(e), t = n?.analysis_date, r = pe(n?.intrinsic), a = r?.state;
	if (!n || "string" != typeof t || 0 === t.length || !r || "string" != typeof a || ![
		"scorable",
		"unscorable",
		"insufficient"
	].includes(a)) return null;
	const o = r.score, i = r.verdict, s = r.infinite_reason, c = {}, l = [], u = n.per_guider;
	if (Array.isArray(u)) for (const y of u) {
		const e = pe(y);
		if (!e) continue;
		l.push(e);
		const n = e.guider;
		if ("string" != typeof n) continue;
		const t = e.confidence;
		Object.defineProperty(c, n, {
			value: "number" == typeof t && Number.isFinite(t) ? t : null,
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
	}
	const d = pe(r.features), p = d && Array.isArray(d.feature_values) ? d : null, m = pe(r.legacy_complexity_features) ?? (null === p ? d : null) ?? {}, f = n.computed_at;
	return {
		difficulty: "number" == typeof o && Number.isFinite(o) ? o : null,
		state: a,
		verdict: "string" == typeof i ? i : null,
		infiniteReason: "string" == typeof s ? s : null,
		confidenceByGuider: c,
		features: m,
		featureVector: p,
		perGuider: l,
		computedAt: "string" == typeof f ? f : null,
		canonicalResult: n,
		canonicalIntrinsic: r
	};
}
[
	"observed",
	"not_collected",
	"structurally_absent",
	"not_applicable",
	"nonresponse",
	"technically_unusable",
	"corrupt",
	"censored",
	"below_detection",
	"redacted",
	"mapping_unresolved",
	"unknown"
].filter((e) => "observed" !== e && "technically_unusable" !== e && "corrupt" !== e);
const fe = [
	"skipped_disabled",
	"recalibrated",
	"identity_fallback_no_valid_fit",
	"identity_fallback_error_increased",
	"candidate_retained_below_preferred_quality"
];
function ye(e) {
	return "number" == typeof e && Number.isFinite(e) ? e : null;
}
function ge(e, n) {
	const t = Array.isArray(e) ? e : [], r = (e) => ye(t[e]) ?? n;
	return [
		r(0),
		r(1),
		r(2)
	];
}
function _e(e, n) {
	const t = "object" == typeof e && null !== e ? e : {};
	return {
		scale: ge(t.scale, n ? 1 : 0),
		offset: ge(t.offset, 0),
		temperatureOffset: ge(t.temperatureOffset, 0),
		errorStart: ye(t.errorStart),
		errorEnd: ye(t.errorEnd),
		fitAttempted: !0 === t.fitAttempted,
		numPoints: Math.max(0, Math.round(ye(t.numPoints) ?? 0)),
		hoursUsed: ye(t.hoursUsed) ?? 0,
		success: !0 === t.success,
		message: "string" == typeof t.message ? t.message : ""
	};
}
function he(e) {
	if ("object" != typeof e || null === e) return null;
	const n = e, t = n.disposition;
	if ("string" != typeof t || !fe.includes(t)) return null;
	const r = _e(n, !0);
	return {
		...r,
		disposition: t,
		observed: "observed" in n ? _e(n.observed, !0) : r,
		applied: "applied" in n ? _e(n.applied, !0) : r
	};
}
const we = 1073741824, be = "actours.compute.v1", ve = "actours-corrected-3.3.7-v2";
function Se(e) {
	return "number" == typeof e ? e : "nan" === e ? NaN : "positive_infinity" === e ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
}
function Ae(e) {
	return null === e ? null : Se(e);
}
let Me = null;
function Ee() {
	return Me || (Me = (async () => {
		const { mod: e, runtime: n } = await ue();
		return "configureComputeMemoryBudgetV1" in e && "function" == typeof e.configureComputeMemoryBudgetV1 && e.configureComputeMemoryBudgetV1(function() {
			const e = "undefined" == typeof navigator ? void 0 : navigator.deviceMemory;
			if ("number" != typeof e || !Number.isFinite(e) || e <= 0) return we;
			const n = Math.floor(1024 * e * 1024 * 1024 / 4);
			return Math.min(2147483648, Math.max(we, n));
		}()), e;
	})().catch((e) => {
		throw Me = null, e;
	})), Me;
}
function xe(e, n = "computeMimsUnit") {
	if ("object" != typeof e || null === e) throw new Error(`${n}: unexpected WASM return shape — got ${typeof e}`);
	const t = e, r = ke(t.mimsUnit);
	if (!r) throw new Error(`${n}: missing mimsUnit array — got ${JSON.stringify(e)}`);
	const a = t.epochSeconds;
	if ("number" != typeof a || !Number.isFinite(a) || a <= 0) throw new Error(`${n}: missing positive epochSeconds — got ${JSON.stringify(e)}`);
	const o = (e) => ke(t[e]) ?? void 0, i = {
		mimsUnit: r,
		epochSeconds: a
	}, s = o("mimsUnitX");
	s && (i.mimsUnitX = s);
	const c = o("mimsUnitY");
	c && (i.mimsUnitY = c);
	const l = o("mimsUnitZ");
	l && (i.mimsUnitZ = l);
	const u = o("headerTimeStamp");
	u && (i.headerTimeStamp = u);
	const d = o("mimsOrientationTimestamp");
	d && (i.mimsOrientationTimestamp = d);
	const p = o("mimsOrientationXAngle");
	p && (i.mimsOrientationXAngle = p);
	const m = o("mimsOrientationYAngle");
	m && (i.mimsOrientationYAngle = m);
	const f = o("mimsOrientationZAngle");
	return f && (i.mimsOrientationZAngle = f), i;
}
function ke(e) {
	if (e instanceof Float64Array) return new Float64Array(e);
	if (ArrayBuffer.isView(e)) {
		const n = e;
		if ("number" == typeof n.length) return new Float64Array(Array.from(n, Number));
	}
	return Array.isArray(e) ? new Float64Array(e) : null;
}
function Ie(e) {
	if (e instanceof Uint8Array) return new Uint8Array(e);
	if (ArrayBuffer.isView(e)) {
		const n = e;
		if ("number" == typeof n.length) return new Uint8Array(Array.from(n, Number));
	}
	return Array.isArray(e) ? new Uint8Array(e) : null;
}
function Ce(e, n) {
	if ("object" != typeof e || null === e) throw new Error(`${n}: unexpected WASM return shape — got ${JSON.stringify(e)}`);
	const t = e, r = {}, a = [];
	for (const o of Object.keys(t)) {
		const e = t[o];
		if (Array.isArray(e)) {
			const n = new Float64Array(e);
			r[o] = n, a.push(n.buffer);
		} else r[o] = e;
	}
	return g(r, a);
}
function Te(e) {
	return null == e || "object" != typeof e || Array.isArray(e) ? null : e;
}
const Ne = {
	day_summaries: [],
	days_with_signal: 0
}, ze = [];
function Fe(e, n) {
	const t = "object" == typeof e && null !== e ? e : {}, r = t.nonwear, a = r instanceof Uint8Array ? r : null, o = t.element_seconds, i = "number" == typeof o && Number.isFinite(o) && o > 0 ? o : n, s = Boolean(t.available) && null !== a, c = t.reason;
	return {
		nonwear: s ? a : null,
		conformance: "string" == typeof t.conformance ? t.conformance : s ? "conformant" : "unavailable",
		available: s,
		reason: "string" == typeof c ? c : null,
		elementSeconds: i
	};
}
function Re(e, n, t, r) {
	const a = t.epochSeconds, o = {}, i = (e) => ({
		nonwear: null,
		conformance: "unavailable",
		available: !1,
		reason: e,
		elementSeconds: a
	}), s = e.detectNonwearUnifiedBatchTyped;
	if ("function" != typeof s) {
		console.warn("[wasm-worker] detectNonwearUnifiedBatchTyped export missing — degrading to unavailable.");
		for (const e of n) o[e] = i("detectNonwearUnifiedBatchTyped export missing (stale WASM bundle)");
		return o;
	}
	try {
		const e = s(JSON.stringify(n), JSON.stringify(r ?? null), t.counts ?? /* @__PURE__ */ new Float64Array(), t.raw ?? /* @__PURE__ */ new Float64Array(), t.temperature ?? /* @__PURE__ */ new Float64Array(), t.epochSeconds, t.sampleRate ?? 0);
		for (const t of n) o[t] = Fe(e.results.find((e) => e.algorithm === t), a);
	} catch {
		console.warn("[wasm-worker] detectNonwearUnifiedBatchTyped failed — degrading to unavailable.");
		for (const e of n) o[e] = i("detectNonwearUnifiedBatchTyped failed");
	}
	return o;
}
"undefined" != typeof self && "undefined" == typeof window && (function() {
	const e = console.error.bind(console);
	console.error = (...n) => {
		try {
			const t = n.map((e) => "string" == typeof e ? e : e instanceof Error ? e.stack ?? e.message : String(e)).join(" ");
			if (/panicked at|RuntimeError|unreachable/i.test(t)) {
				const n = /([A-Za-z0-9_.-]+\.rs):(\d+)/.exec(t);
				se = n ? `Rust trap at ${n[1]}:${n[2]}` : "Rust runtime trap", e("[wasm-worker] WASM runtime trap captured");
				return;
			}
		} catch {}
		e(...n);
	};
}(), s(function(e) {
	const n = {};
	for (const t of Object.keys(e)) {
		const r = e[t];
		if ("function" != typeof r) {
			n[t] = r;
			continue;
		}
		const a = r;
		n[t] = async (...e) => {
			se = null;
			try {
				return await a(...e);
			} catch (n) {
				const e = n instanceof Error ? n.message : String(n);
				if (se && ce.test(e)) throw new Error(`WASM panic in ${t}(): ${se}`, { cause: n });
				throw n;
			}
		};
	}
	return n;
}({
	async readDiaryWorkbook(e, n) {
		const { readDiaryWorkbookSheet: t } = await import("./diary-xlsx-adapter-DthwMDD1.js");
		return t(e, n);
	},
	async detectNonwearUnified(e) {
		const n = function(e, n) {
			return Re(e, [n.algorithm], n.signals, n.config)[n.algorithm];
		}(await Ee(), e);
		return g(n, n.nonwear ? [n.nonwear.buffer] : []);
	},
	async detectNonwearUnifiedBatch(e, n) {
		const t = Re(await Ee(), e, n);
		return g(t, Object.values(t).flatMap((e) => e.nonwear ? [e.nonwear.buffer] : []));
	},
	async scoreEpochs(e) {
		const n = function(e, n) {
			const t = n.signals.epochSeconds, r = (e) => ({
				sleepWake: null,
				conformance: "unavailable",
				available: !1,
				reason: e,
				elementSeconds: t
			}), a = e.scoreEpochsTyped;
			if ("function" != typeof a) return console.warn("[wasm-worker] scoreEpochsTyped is not present in this WASM bundle — unified local scoring degrades to unavailable. Rebuild the actours WASM crate to enable it."), r("scoreEpochsTyped export missing (stale WASM bundle)");
			let o;
			try {
				const { signals: e, ...t } = n;
				o = a(JSON.stringify(t), e.counts ?? /* @__PURE__ */ new Float64Array(), e.raw ?? /* @__PURE__ */ new Float64Array(), e.temperature ?? /* @__PURE__ */ new Float64Array(), e.epochSeconds, e.sampleRate ?? 0);
			} catch {
				return console.warn("[wasm-worker] scoreEpochsTyped failed — degrading to unavailable."), r("scoreEpochsTyped failed");
			}
			return function(e, n) {
				const t = "object" == typeof e && null !== e ? e : {}, r = t.sleep_wake, a = r instanceof Uint8Array ? r : null, o = t.element_seconds, i = "number" == typeof o && Number.isFinite(o) && o > 0 ? o : n, s = Boolean(t.available) && null !== a, c = t.reason;
				return {
					sleepWake: s ? a : null,
					conformance: "string" == typeof t.conformance ? t.conformance : s ? "conformant" : "unavailable",
					available: s,
					reason: "string" == typeof c ? c : null,
					elementSeconds: i
				};
			}(o, t);
		}(await Ee(), e);
		return g(n, n.sleepWake ? [n.sleepWake.buffer] : []);
	},
	async scoreSadeh(e, n) {
		const t = await Ee(), r = new Uint8Array(t.scoreSadeh(e, n));
		return g(r, [r.buffer]);
	},
	async scoreColeKripke(e, n) {
		const t = await Ee(), r = new Uint8Array(t.scoreColeKripke(e, n));
		return g(r, [r.buffer]);
	},
	async epochAgreement(e, n) {
		const t = (await Ee()).epochAgreement(e, n);
		if ("object" != typeof t || null === t) throw new Error("actours returned invalid epoch agreement");
		const r = t;
		for (const a of [
			"n",
			"agree",
			"agreement",
			"cohenKappa",
			"bothSleep",
			"bothWake",
			"aSleepBWake",
			"aWakeBSleep"
		]) if ("number" != typeof r[a]) throw new Error(`actours returned invalid epoch agreement field ${a}`);
		return r;
	},
	async rasterizePeriods(e, n, t, r) {
		const a = (await Ee()).rasterizePeriods(e, n, t, r);
		if (!(a?.mask instanceof Uint8Array) || "number" != typeof a.coveredEpochs) throw new Error("actours returned an invalid period raster");
		return g(a, [a.mask.buffer]);
	},
	exportNapAggregate: async (e) => (await Ee()).exportNapAggregate(e),
	exportPeriodFigures: async (e, n, t) => (await Ee()).exportPeriodFigures(e, n, t),
	summarizeExportGroups: async (e) => (await Ee()).summarizeExportGroups(e),
	compareNonwearDetectorMasks: async (e, n) => (await Ee()).compareNonwearDetectorMasks(e, n),
	reviewNonwearFile: async (e) => (await Ee()).reviewNonwearFile(e),
	fuseNonwearMasks: async (e) => (await Ee()).fuseNonwearMasks(e),
	summarizePhysicalActivityTrace: async (e) => (await Ee()).summarizePhysicalActivityTrace(e),
	ggirSummaryDenominator: async (e, n) => (await Ee()).ggirSummaryDenominator(e, n),
	reviewNonwearTotals: async (e) => (await Ee()).reviewNonwearTotals(e),
	async detectNonwear(e) {
		const n = await Ee(), t = new Uint8Array(n.detectNonwear(e));
		return g(t, [t.buffer]);
	},
	async detectNonwearChoi2011(e, n = 60) {
		const t = await Ee(), r = new Uint8Array("function" == typeof t.detectNonwearChoi2011Epoch ? t.detectNonwearChoi2011Epoch(e, n) : t.detectNonwearChoi2011(e));
		return g(r, [r.buffer]);
	},
	parseActigraphCsv: async (e, n) => Ce((await Ee()).parseActigraphCsv(e, n), "parseActigraphCsv"),
	parseGeneactivCsv: async (e) => Ce((await Ee()).parseGeneactivCsv(e), "parseGeneactivCsv"),
	isGeneactivFormat: async (e) => (await Ee()).isGeneactivFormat(e),
	async csvBufferClear(e) {
		(await Ee()).csvBufferClear(e);
	},
	async csvBufferAppend(e) {
		(await Ee()).csvBufferAppend(e);
	},
	parseGeneactivCsvBuffered: async () => Ce((await Ee()).parseGeneactivCsvBuffered(), "parseGeneactivCsvBuffered"),
	parseActigraphCsvBuffered: async (e) => Ce((await Ee()).parseActigraphCsvBuffered(e), "parseActigraphCsvBuffered"),
	async sha256Start() {
		(await Ee()).sha256StreamStart();
	},
	async sha256Feed(e) {
		(await Ee()).sha256StreamFeed(e);
	},
	sha256Finish: async () => (await Ee()).sha256StreamFinish(),
	async streamParseStart(e, n, t = 60) {
		const r = await Ee();
		"function" == typeof r.streamParseStartWithEpoch ? r.streamParseStartWithEpoch(e, n, t) : r.streamParseStart(e, n);
	},
	async streamParseStartData(e, n) {
		(await Ee()).streamParseStartData(e, n);
	},
	streamParseFeed: async (e) => (await Ee()).streamParseFeed(e),
	async streamParseFinish() {
		const e = (await Ee()).streamParseFinish();
		if (null == e || "object" != typeof e) throw new Error(`streamParseFinish: unexpected WASM return shape (${typeof e}) — bundle may be corrupt`);
		const n = new Float64Array(e.timestampsMs), t = new Float64Array(e.axisX), r = new Float64Array(e.axisY), a = new Float64Array(e.axisZ), o = new Float64Array(e.vectorMagnitude), i = new Float64Array(e.temperature);
		return g({
			timestampsMs: n,
			axisX: t,
			axisY: r,
			axisZ: a,
			vectorMagnitude: o,
			temperature: i,
			sampleFrequency: e.sampleFrequency,
			headerRowsSkipped: e.headerRowsSkipped
		}, [
			n.buffer,
			t.buffer,
			r.buffer,
			a.buffer,
			o.buffer,
			i.buffer
		]);
	},
	async streamParseFinishChunk() {
		const e = (await Ee()).streamParseFinishChunk();
		if (null == e || "object" != typeof e) throw new Error(`streamParseFinishChunk: unexpected WASM return shape (${typeof e}) — bundle may be corrupt`);
		const n = new Float64Array(e.timestampsMs), t = new Float64Array(e.axisX), r = new Float64Array(e.axisY), a = new Float64Array(e.axisZ), o = new Float64Array(e.vectorMagnitude), i = new Float64Array(e.temperature), s = new Uint32Array(e.counts), c = new Uint32Array(e.tempCounts), l = new Float64Array(e.timestampsMs5s), u = new Float64Array(e.enmo5s), d = new Float64Array(e.anglez5s), p = new Float64Array(e.anglex5s ?? 0), m = new Float64Array(e.angley5s ?? 0), f = new Float64Array(e.mad5s ?? 0), y = new Float64Array(e.enmoa5s ?? 0), _ = new Uint8Array(e.ggirInvalid5s), h = new Uint8Array(e.ggirNonwear5s), w = e, b = new Float64Array(w.zcx60s ?? []), v = new Float64Array(w.zcy60s ?? []), S = new Float64Array(w.zcz60s ?? []), A = new Uint32Array(e.counts5s), M = e, E = new Float64Array(M.mimsUnit ?? []), x = new Float64Array(M.mimsUnitX ?? []), k = new Float64Array(M.mimsUnitY ?? []), I = new Float64Array(M.mimsUnitZ ?? []), C = e;
		return g({
			timestampsMs: n,
			axisX: t,
			axisY: r,
			axisZ: a,
			vectorMagnitude: o,
			temperature: i,
			counts: s,
			tempCounts: c,
			timestampsMs5s: l,
			enmo5s: u,
			anglez5s: d,
			anglex5s: p,
			angley5s: m,
			mad5s: f,
			enmoa5s: y,
			ggirInvalid5s: _,
			ggirNonwear5s: h,
			zcx60s: b,
			zcy60s: v,
			zcz60s: S,
			counts5s: A,
			mimsUnit: E,
			mimsUnitX: x,
			mimsUnitY: k,
			mimsUnitZ: I,
			sampleFrequency: e.sampleFrequency,
			headerRowsSkipped: e.headerRowsSkipped,
			rowsDropped: e.rowsDropped,
			rawRetentionDegraded: C.rawRetentionDegraded ?? !1,
			canonicalPassDegraded: C.canonicalPassDegraded ?? !1,
			canonicalPassReason: C.canonicalPassReason ?? null
		}, [
			n.buffer,
			t.buffer,
			r.buffer,
			a.buffer,
			o.buffer,
			i.buffer,
			s.buffer,
			c.buffer,
			l.buffer,
			u.buffer,
			d.buffer,
			p.buffer,
			m.buffer,
			f.buffer,
			y.buffer,
			_.buffer,
			h.buffer,
			b.buffer,
			v.buffer,
			S.buffer,
			A.buffer,
			E.buffer,
			x.buffer,
			k.buffer,
			I.buffer
		]);
	},
	async neishabouriCounts(e, n, t, r, a) {
		const o = (await Ee()).neishabouriCounts(e, n, t, r, a), i = "object" == typeof o && null !== o ? o : null, s = i ? ke(i.x) : null, c = i ? ke(i.y) : null, l = i ? ke(i.z) : null, u = i ? ke(i.vm) : null;
		if (!(s && c && l && u)) throw new Error(`neishabouriCounts: unexpected WASM return shape — got ${JSON.stringify(o)}`);
		return g({
			x: s,
			y: c,
			z: l,
			vm: u
		}, [
			s.buffer,
			c.buffer,
			l.buffer,
			u.buffer
		]);
	},
	async zeroCrossingCounts(e, n, t, r, a) {
		const o = (await Ee()).zeroCrossingCounts(e, n, t, r, a), i = "object" == typeof o && null !== o ? o : null, s = i ? ke(i.zcx) : null, c = i ? ke(i.zcy) : null, l = i ? ke(i.zcz) : null;
		if (!s || !c || !l) throw new Error(`zeroCrossingCounts: unexpected WASM return shape — got ${JSON.stringify(o)}`);
		return g({
			zcx: s,
			zcy: c,
			zcz: l
		}, [
			s.buffer,
			c.buffer,
			l.buffer
		]);
	},
	async computeMimsUnit(e, n, t, r, a = {}) {
		const o = await Ee();
		if (!("computeMimsUnit" in o) || "function" != typeof o.computeMimsUnit) throw new Error("computeMimsUnit: current actours WASM bundle does not export MIMS_UNIT processing");
		const i = xe(o.computeMimsUnit(e, n, t, r, a), "computeMimsUnit");
		return g(i, [
			i.mimsUnit.buffer,
			i.mimsUnitX?.buffer,
			i.mimsUnitY?.buffer,
			i.mimsUnitZ?.buffer,
			i.headerTimeStamp?.buffer,
			i.mimsOrientationTimestamp?.buffer,
			i.mimsOrientationXAngle?.buffer,
			i.mimsOrientationYAngle?.buffer,
			i.mimsOrientationZAngle?.buffer
		].filter((e) => e instanceof ArrayBuffer));
	},
	async computeMimsUnitDataframe(e, n, t, r, a = {}) {
		const o = await Ee();
		if (!("computeMimsUnitDataframe" in o) || "function" != typeof o.computeMimsUnitDataframe) throw new Error("computeMimsUnitDataframe: current actours WASM bundle does not export MIMS_UNIT processing");
		const i = xe(o.computeMimsUnitDataframe(e, n, t, r, a), "computeMimsUnitDataframe");
		return g(i, [
			i.mimsUnit.buffer,
			i.mimsUnitX?.buffer,
			i.mimsUnitY?.buffer,
			i.mimsUnitZ?.buffer,
			i.headerTimeStamp?.buffer,
			i.mimsOrientationTimestamp?.buffer,
			i.mimsOrientationXAngle?.buffer,
			i.mimsOrientationYAngle?.buffer,
			i.mimsOrientationZAngle?.buffer
		].filter((e) => e instanceof ArrayBuffer));
	},
	async classifyActimetricPreschoolWristRf(e, n, t, r) {
		const a = await Ee(), o = "function" == typeof a.classifyActimetricPreschoolWristRfLagLead ? a.classifyActimetricPreschoolWristRfLagLead : "function" == typeof a.classifyActimetricPreschoolWristRf ? a.classifyActimetricPreschoolWristRf : "function" == typeof a.actimetricPreschoolWristRfClasses ? a.actimetricPreschoolWristRfClasses : "function" == typeof a.predictActimetricPreschoolWristRfClasses ? a.predictActimetricPreschoolWristRfClasses : null;
		if (!o) throw new Error("classifyActimetricPreschoolWristRf: current actours WASM bundle does not export actimetric preschool wrist RF inference");
		const i = function(e, n = "classifyActimetricPreschoolWristRf") {
			const t = Ie(e);
			if (t) return {
				classes: t,
				epochSeconds: 15
			};
			const r = "object" == typeof e && null !== e ? e : null, a = r ? Ie(r.classes) ?? Ie(r.activityClasses) ?? Ie(r.predictions) ?? Ie(r.activity) : null;
			if (!a) throw new Error(`${n}: unexpected WASM return shape — expected Uint8Array or { classes }`);
			const o = "number" == typeof r?.epochSeconds && Number.isFinite(r.epochSeconds) ? r.epochSeconds : "number" == typeof r?.epoch_seconds && Number.isFinite(r.epoch_seconds) ? r.epoch_seconds : 15, i = "string" == typeof r?.classifier ? r.classifier : void 0, s = "string" == typeof r?.model ? r.model : void 0;
			return {
				classes: a,
				epochSeconds: o,
				...i ? { classifier: i } : {},
				...s ? { model: s } : {}
			};
		}(o(e, n, t, r), "classifyActimetricPreschoolWristRf");
		return g(i, [i.classes.buffer]);
	},
	async lstmSpectralFeatures30s(e, n, t, r) {
		const a = await Ee(), o = a.lstmSpectralFeatures30s ?? a.spectralFeatures30s;
		if ("function" != typeof o) throw new Error("LSTM spectral feature extractor is not available in this WASM bundle");
		const i = o(e, n, t, r), s = "object" == typeof i && null !== i ? i : null, c = function(e) {
			if (e instanceof Float32Array) return new Float32Array(e);
			if (ArrayBuffer.isView(e)) {
				const n = e;
				if ("number" == typeof n.length) return new Float32Array(Array.from(n, Number));
			}
			return Array.isArray(e) ? new Float32Array(e) : null;
		}(s?.features ?? i), l = "number" == typeof s?.bins ? s.bins : 30, u = "number" == typeof s?.channels ? s.channels : 4, d = "number" == typeof s?.epochs ? s.epochs : c ? Math.floor(c.length / (l * u)) : 0;
		if (!c || d * l * u !== c.length) throw new Error(`lstmSpectralFeatures30s: unexpected WASM return shape — got ${JSON.stringify(i)}`);
		return g({
			features: c,
			epochs: d,
			bins: l,
			channels: u
		}, [c.buffer]);
	},
	async scoreConsensus(e, n) {
		const t = await Ee();
		if ("function" != typeof t.scoreConsensusTyped) throw new Error("scoreConsensus is not present in this WASM bundle.");
		const r = new Uint32Array(n.length + 1);
		for (const [s, c] of n.entries()) r[s + 1] = r[s] + c.length;
		const a = 1 === n.length ? n[0] : new Uint8Array(r[n.length]);
		if (1 !== n.length) for (const [s, c] of n.entries()) a.set(c, r[s]);
		const o = t.scoreConsensusTyped(JSON.stringify({ strategy: e }), a, r), i = null != o && "object" == typeof o ? o.consensus : void 0;
		if (!(i instanceof Uint8Array)) throw new Error(`scoreConsensus: unexpected WASM return shape — got ${JSON.stringify(o)}`);
		return g(i, [i.buffer]);
	},
	ggirSptDurationHours: async (e, n) => (await Ee()).ggirSptDurationHours(e, n),
	async computeSleepMetrics(e, n, t) {
		const r = (await Ee()).computeSleepMetrics(e, n, t);
		if (null == r || "object" != typeof r || "number" != typeof r.totalSleepTimeMinutes || "number" != typeof r.sleepEfficiency) throw new Error(`computeSleepMetrics: unexpected WASM return shape ${JSON.stringify(r)}`);
		return r;
	},
	computeFileDifficulty: async (e) => function(e, n) {
		const t = e.computeNightDifficultyTyped;
		return "function" != typeof t ? (console.warn("[wasm-worker] computeNightDifficulty is not present in this WASM bundle — night difficulty degrades to empty. Rebuild the actours WASM crate to enable it."), { byDate: {} }) : function(e) {
			const n = {}, t = /* @__PURE__ */ new Set(), r = Te(e)?.results;
			if (!Array.isArray(r)) return { byDate: n };
			for (const a of r) {
				const e = me(a);
				if (!e) return { byDate: {} };
				const r = e.canonicalResult.analysis_date;
				if (t.has(r)) return { byDate: {} };
				t.add(r), Object.defineProperty(n, r, {
					value: e,
					enumerable: !0,
					configurable: !0,
					writable: !0
				});
			}
			return { byDate: n };
		}(t(...n));
	}(await Ee(), e),
	computeFileSignals: async (e) => function(e, n) {
		const t = e.computeNightSignalsTyped;
		if ("function" != typeof t) return console.warn("[wasm-worker] computeNightSignals is not present in this WASM bundle — night-signal detail degrades to empty."), { byDate: {} };
		const [r, ...a] = n;
		return function(e) {
			const n = {}, t = /* @__PURE__ */ new Set(), r = Te(e)?.signals;
			if (!Array.isArray(r)) return { byDate: n };
			for (const a of r) {
				const e = Te(a), r = e?.analysis_date, o = e?.epoch_length_seconds;
				if (!e || "string" != typeof r || 0 === r.length || !Number.isInteger(o) || o <= 0) return { byDate: {} };
				if (t.has(r)) return { byDate: {} };
				t.add(r), Object.defineProperty(n, r, {
					value: e,
					enumerable: !0,
					configurable: !0,
					writable: !0
				});
			}
			return { byDate: n };
		}(t(JSON.stringify(function(e) {
			const n = de(e.config), t = de(n?.signals) ?? n;
			return {
				...t ? { config: t } : {},
				days: e.days
			};
		}(JSON.parse(r))), ...a));
	}(await Ee(), e),
	sleepRegularityIndex: async (e) => function(e, n) {
		const t = e.sleepRegularityIndex;
		if ("function" != typeof t) throw new Error("sleepRegularityIndex is not present in this WASM bundle. Rebuild the actours WASM crate.");
		const r = t(...n);
		if (null != r && "number" != typeof r) throw new Error("actours returned an invalid SRI");
		return r ?? null;
	}(await Ee(), e),
	computeCircadian: async (e) => function(e, n) {
		const t = e.computeCircadianTyped;
		if ("function" != typeof t) throw new Error("computeCircadian is not present in this WASM bundle. Rebuild the actours WASM crate.");
		const r = t(...n);
		return r && "object" == typeof r && Array.isArray(r.day_summaries) ? r : Ne;
	}(await Ee(), e),
	aggregateEpochSeries: async (e) => function(e, n) {
		const t = e.aggregateEpochSeries;
		if ("function" != typeof t) throw new Error("aggregateEpochSeries is not present in this WASM bundle. Rebuild the actours WASM crate.");
		const r = t(n);
		if (null == r || "object" != typeof r) throw new Error("aggregateEpochSeries returned an invalid result.");
		const a = r;
		if (!a.series || !Array.isArray(a.series.timestamps_ms)) throw new Error("aggregateEpochSeries returned an invalid result.");
		return r;
	}(await Ee(), e),
	async detectDeviceFormat(e, n) {
		const t = (await Ee()).detectDeviceFormat;
		if ("function" != typeof t) return null;
		try {
			return t(e, n);
		} catch {
			return null;
		}
	},
	async parseEpochSeries(e, n) {
		const t = (await Ee()).parseEpochSeries;
		if ("function" != typeof t) throw new Error("parseEpochSeries is not present in this WASM bundle.");
		return t(e, n);
	},
	async actiwareIntervals(e, n, t) {
		const r = await Ee(), a = r.generateActiwareRestIntervals, o = r.actiwareSleepIntervals;
		if ("function" != typeof a || "function" != typeof o) return null;
		if (n.length > 0) {
			const r = o(e, n, t);
			return {
				intervals: [...n, ...r],
				generated: !1
			};
		}
		return {
			intervals: a(e, t),
			generated: !0
		};
	},
	async actiwareSleepWake(e, n) {
		const t = (await Ee()).sleepWakeScores;
		return "function" != typeof t ? null : t(e, n);
	},
	async actiwareIntervalStatistics(e) {
		const n = (await Ee()).actiwareIntervalStatistics;
		return "function" != typeof n ? null : n(e);
	},
	hasParseAw5: async () => "function" == typeof (await Ee()).parseAw5,
	async parseAw5(e) {
		const n = (await Ee()).parseAw5;
		return "function" != typeof n ? null : n(e, null);
	},
	async openAw5Batch(e) {
		const n = (await Ee()).Aw5Batch;
		if ("function" != typeof n) return null;
		const t = new n(e);
		return {
			handle: ze.push(t) - 1,
			subjects: e.map((e, n) => t.subjects(n))
		};
	},
	aw5BatchRecording(e, n, t) {
		const r = ze[e];
		return r ? Promise.resolve(r.recording(n, t, null)) : Promise.reject(/* @__PURE__ */ new Error("The .AW5 batch is not open in this worker."));
	},
	async runScoredVariantBatch(e) {
		const n = await Ee(), t = {}, r = /* @__PURE__ */ new Set();
		let a = 0, o = !1;
		const i = Object.keys(e.classifierOutputs).filter((n) => e.classifierOutputs[n]?.length === e.timestamps.length).sort(), s = new Set(i), c = Object.keys(e.nonwearMasks).filter((n) => null != e.nonwearMasks[n]?.mask).sort(), l = function(e, n) {
			const t = [...new Set(e)].filter((e) => null != n[e]?.mask), r = t.map((e) => n[e].mask), a = r[0];
			return a ? {
				weight: Array.from({ length: a.length }, (e, n) => {
					const t = r.reduce((e, t) => e + (1 === t[n] ? 1 : 0), 0);
					return 1 === r.length ? t : t / r.length;
				}),
				available: t,
				memberFlags: ee(t, r)
			} : null;
		}(e.studyNonwearDetectors ?? [], e.nonwearMasks), u = (e) => "none" === e ? -1 : "study_selection" !== e ? c.indexOf(e) : l ? 1 === l.available.length ? c.indexOf(l.available[0]) : -2 : -1, d = e.variants.filter((n) => {
			if (!s.has(n.classifierConfigId)) return a += 1, !1;
			if ("study_selection" === n.nonwear) return l || r.add("None of the study's nonwear detectors can run for this data — scored without a nonwear mask."), !0;
			const t = "none" === n.nonwear ? void 0 : e.nonwearMasks[n.nonwear];
			if ("none" !== n.nonwear && !t?.mask) {
				const e = t?.reason ? ` (${t.reason})` : "";
				r.add(`Nonwear detector "${n.nonwear}" is unavailable for this data — scored without a nonwear mask.${e}`);
			}
			return !0;
		}), p = e.timestamps.length;
		if (0 === p) {
			for (const e of d) t[e.id] = /* @__PURE__ */ new ArrayBuffer(0);
			d.length && r.add("No activity data");
		} else if (d.length) if ("function" != typeof n.placeMarkersBatch) o = !0;
		else {
			const a = new Uint8Array(i.length * p);
			for (const [n, t] of i.entries()) {
				const r = e.classifierOutputs[t];
				if (r.length !== p) throw new Error(`classifier_scores length ${String(r.length)} does not match 1 rows × ${String(p)} epochs`);
				a.set(r, n * p);
			}
			const o = new Uint8Array(c.length * p);
			for (const [n, t] of c.entries()) {
				const r = e.nonwearMasks[t].mask;
				if (r.length !== p) throw new Error(`nonwear_masks length ${String(r.length)} does not match 1 rows × ${String(p)} epochs`);
				o.set(r, n * p);
			}
			const s = function(e) {
				let n;
				if ("variant" in e) {
					const { variant: a, timestamps: o, activityCounts: i, sleepScores: s, analysisDate: c, epochLengthSeconds: l, hdczaWindow: u, diary: d, onsetMinConsecutiveSleep: p, offsetMinConsecutiveMinutes: m, choiNonwear: f, nonwearDetectors: y, nonwearWeight: g, nonwearMemberFlags: _, eventMarkerTimestamps: h, actiwareRestWindow: w } = e, b = a.config.rescoring === v && (r = v) === v ? { preset: r } : void 0;
					n = {
						timestamps: o,
						activityCounts: i,
						sleepScores: s,
						...void 0 !== f ? { choiNonwear: f } : {},
						...void 0 !== y ? { nonwearDetectors: y } : {},
						...void 0 !== g ? { nonwearWeight: g } : {},
						...void 0 !== _ ? { nonwearMemberFlags: _ } : {},
						ruleset: a.config.ruleset,
						...void 0 !== b ? { scorerPostprocessing: b } : {},
						analysisDate: c,
						epochLengthSeconds: l,
						hdczaWindow: u ? {
							startTimestamp: u[0],
							endTimestamp: u[1]
						} : null,
						...h ? { eventMarkerTimestamps: h } : {},
						...w ? { actiwareRestWindow: w } : {},
						diaryBedTime: d?.diaryInBedTime ?? null,
						diaryOnsetTime: d?.onsetTime ?? null,
						diaryWakeTime: d?.diaryWakeTime ?? null,
						diaryNaps: ie(d?.naps),
						diaryNonwear: ie(d?.nonwear),
						...void 0 !== p ? { onsetMinConsecutiveSleep: p } : {},
						...void 0 !== m ? { offsetMinConsecutiveMinutes: m } : {},
						...(t = a.config.periodSource, t === $ ? { periodGuider: $ } : t === J ? { periodGuider: J } : { sleepPeriodDetection: {
							sourceA: t,
							sourceB: z,
							fusionPolicy: F,
							applyNonwearGate: !1
						} })
					};
				} else n = e;
				var t, r;
				return function(e) {
					const n = [
						"timestamps",
						"activity_counts",
						"sleep_scores",
						"choi_nonwear",
						"anglez",
						"light",
						"temperature",
						"heart_rate",
						"detach_nonwear"
					], t = n.flatMap((n) => {
						const t = e.days.map((e) => e[n] ?? []), r = new Uint32Array(t.length + 1);
						for (const [e, i] of t.entries()) r[e + 1] = r[e] + i.length;
						const a = "sleep_scores" === n || "choi_nonwear" === n || "detach_nonwear" === n ? Uint8Array : Float64Array, o = 1 === t.length && t[0] instanceof a ? t[0] : new a(r[t.length]);
						if (o !== t[0]) for (const [e, i] of t.entries()) o.set(i, r[e]);
						return [o, r];
					}), r = {
						config: e.config,
						days: e.days.map((e) => Object.fromEntries(Object.entries(e).filter(([e]) => !n.includes(e))))
					};
					return [JSON.stringify(r), ...t];
				}({
					config: Q(n),
					days: [ae(n), ...(n.contextDays ?? []).filter((e) => e.analysisDate !== (n.analysisDate ?? "")).map(oe)]
				});
			}({
				...e,
				timestamps: [],
				activityCounts: [],
				sleepScores: [],
				variant: { config: {
					...d[0],
					periodSource: "l5",
					rescoring: "none"
				} }
			}), f = JSON.parse(s[0]), y = f.days[0], g = l && l.available.length > 1 ? l : null, _ = (t) => n.placeMarkersBatch(JSON.stringify({
				...f.config,
				...y,
				classifier_ids: i,
				nonwear_ids: c,
				...g ? {
					nonwear_weight: g.weight,
					nonwear_member_flags: g.memberFlags,
					nonwear_detectors: te(g.available)
				} : {}
			}), Float64Array.from(e.timestamps), Float64Array.from(e.activityCounts), a, o, JSON.stringify(t.map((e) => ({
				id: e.id,
				classifier_index: i.indexOf(e.classifierConfigId),
				nonwear_index: u(e.nonwear),
				ruleset: e.ruleset,
				period_source: e.periodSource,
				rescoring: e.rescoring
			}))));
			let h, w = d;
			try {
				h = _(w);
			} catch (m) {
				if (!g) throw m;
				w = d.filter((e) => -2 !== u(e.nonwear)), r.add("The loaded placement core predates weighted nonwear; the study-selection variants were not scored."), h = _(w);
			}
			for (const e of h.notes) r.add(e);
			for (const [e, n] of w.entries()) t[n.id] = h.masks.slice(e * p, (e + 1) * p).buffer;
		}
		return g({
			masks: t,
			notes: [...r],
			missingClassifier: a,
			placementUnavailable: o
		}, Object.values(t));
	},
	async placeMarkers(e) {
		const n = await Ee();
		return "function" != typeof n.placeMarkersTyped ? (console.warn("[wasm-worker] placeMarkers is not present in this WASM bundle — local marker placement degrades to null."), null) : n.placeMarkersTyped(...e);
	},
	async placeNonwearMarkers(e) {
		const n = await Ee();
		return "function" != typeof n.placeNonwearMarkersTyped ? (console.warn("[wasm-worker] placeNonwearMarkers is not present in this WASM bundle — local marker placement degrades to null."), null) : n.placeNonwearMarkersTyped(...e);
	},
	async nonwearContributors(e, n, t, r) {
		const a = await Ee();
		return JSON.parse(a.nonwearContributors(Uint32Array.from(e), JSON.stringify(n), t, r));
	},
	epochRawData: async (e, n, t, r, a) => Ce((await Ee()).epochRawData(e, n, t, r, a), "epochRawData"),
	async epochWithBandpass(e, n, t) {
		const r = (await Ee()).epochWithBandpass(e, n, t), a = "object" == typeof r && null !== r ? r : null, o = ke(a?.timestamps), i = ke(a?.counts);
		if (!o || !i) throw new Error("epochWithBandpass: unexpected WASM return shape");
		return g({
			timestamps: o,
			counts: i
		}, [o.buffer, i.buffer]);
	},
	async computeEnmo5s(e, n, t, r) {
		const a = await Ee();
		return new Float64Array(a.computeEnmo5s(e, n, t, r));
	},
	async computeAnglez5s(e, n, t, r) {
		const a = await Ee();
		return new Float64Array(a.computeAnglez5s(e, n, t, r));
	},
	async processRawXyz(e, n, t, r, a, o) {
		const i = (await Ee()).processRawXyz(e, n, t, r, a, o ?? void 0), s = "object" == typeof i && null !== i ? i : null, c = s ? ke(s.enmo5s) : null, l = s ? ke(s.anglez5s) : null, u = s ? ke(s.countsX) : null, d = s ? ke(s.countsY) : null, p = s ? ke(s.countsZ) : null, m = s ? ke(s.countsVm) : null;
		if (!(c && l && u && d && p && m)) throw new Error(`processRawXyz: unexpected WASM return shape — got ${JSON.stringify(i)}`);
		const f = (e) => ke(e) ?? /* @__PURE__ */ new Float64Array(0), y = s ? f(s.anglex5s) : /* @__PURE__ */ new Float64Array(0), _ = s ? f(s.angley5s) : /* @__PURE__ */ new Float64Array(0), h = s ? f(s.mad5s) : /* @__PURE__ */ new Float64Array(0), w = s ? f(s.enmoa5s) : /* @__PURE__ */ new Float64Array(0);
		return g({
			enmo5s: c,
			anglez5s: l,
			anglex5s: y,
			angley5s: _,
			mad5s: h,
			enmoa5s: w,
			calibration: he(s?.calibration),
			counts: {
				x: u,
				y: d,
				z: p,
				vm: m
			}
		}, [
			c.buffer,
			l.buffer,
			y.buffer,
			_.buffer,
			h.buffer,
			w.buffer,
			u.buffer,
			d.buffer,
			p.buffer,
			m.buffer
		]);
	},
	async processRawXyzImputed(e, n, t, r, a, o, i = 60) {
		const s = await Ee(), c = "function" == typeof s.processRawXyzImputedWithEpoch ? s.processRawXyzImputedWithEpoch(e, n, t, r, a, o ?? void 0, i) : s.processRawXyzImputed(e, n, t, r, a, o ?? void 0), l = "object" == typeof c && null !== c ? c : null, u = l ? ke(l.enmo5s) : null, d = l ? ke(l.anglez5s) : null, p = l ? ke(l.countsX) : null, m = l ? ke(l.countsY) : null, f = l ? ke(l.countsZ) : null, y = l ? ke(l.countsVm) : null;
		if (!(u && d && p && m && f && y)) throw new Error(`processRawXyzImputed: unexpected WASM return shape — got ${JSON.stringify(c)}`);
		const _ = (e) => ke(e) ?? /* @__PURE__ */ new Float64Array(0), h = l ? _(l.anglex5s) : /* @__PURE__ */ new Float64Array(0), w = l ? _(l.angley5s) : /* @__PURE__ */ new Float64Array(0), b = l ? _(l.mad5s) : /* @__PURE__ */ new Float64Array(0), v = l ? _(l.enmoa5s) : /* @__PURE__ */ new Float64Array(0), S = (e) => Array.isArray(e) || ArrayBuffer.isView(e) ? Uint8Array.from(e) : /* @__PURE__ */ new Uint8Array(0), A = S(l?.ggirInvalid5s), M = S(l?.ggirNonwear5s);
		return g({
			enmo5s: u,
			anglez5s: d,
			anglex5s: h,
			angley5s: w,
			mad5s: b,
			enmoa5s: v,
			counts: {
				x: p,
				y: m,
				z: f,
				vm: y
			},
			ggirInvalid5s: A,
			ggirNonwear5s: M,
			firstTsMs: "number" == typeof l?.firstTsMs ? l.firstTsMs : 0,
			numGaps: "number" == typeof l?.numGaps ? l.numGaps : 0,
			samplesAdded: "number" == typeof l?.samplesAdded ? l.samplesAdded : 0,
			calibration: he(l?.calibration)
		}, [
			u.buffer,
			d.buffer,
			h.buffer,
			w.buffer,
			b.buffer,
			v.buffer,
			A.buffer,
			M.buffer,
			p.buffer,
			m.buffer,
			f.buffer,
			y.buffer
		]);
	},
	async detectDetachFromAccelerationG(e, n) {
		const t = await Ee(), r = new Uint8Array(t.detectDetachFromAccelerationG(e, n));
		return g(r, [r.buffer]);
	},
	runFullPipelineV1: async (e, n, t, r, a) => function(e, n, t, r, a, o) {
		const i = e.runFullPipelineV1({
			contractVersion: be,
			semanticProfile: ve,
			signal: {
				x: n,
				y: t,
				z: r,
				sampleRateHz: a,
				startTsEpochMs: 1e3 * o,
				preparation: "calibrated_g"
			},
			config: {
				ws3: 5,
				deviceSerialNumber: null
			},
			execution: {
				concurrency: { mode: "serial" },
				vectorization: "baseline",
				accelerator: "cpu_only"
			}
		});
		return i ? {
			result: (s = i.result, {
				metadata: {
					sampleRateHz: s.metadata.sampleRateHz,
					startTsEpochSec: s.metadata.startTsEpochMs / 1e3,
					ws3: s.metadata.ws3,
					nEpochs: s.metadata.nEpochs,
					nMidnights: s.metadata.nMidnights,
					nNights: s.metadata.nNights,
					nonwearFraction: Se(s.metadata.nonwearFraction)
				},
				days: s.days.map((e) => ({
					calendarDate: e.calendarDate,
					dayNumber: e.dayNumber,
					validHours: Se(e.validHours),
					nonwearHours: Se(e.nonwearHours),
					totalEpochs: e.totalEpochs,
					sedentaryMinutes: Se(e.sedentaryMinutes),
					lightMinutes: Se(e.lightMinutes),
					moderateMinutes: Se(e.moderateMinutes),
					vigorousMinutes: Se(e.vigorousMinutes),
					mvpaMinutes: Se(e.mvpaMinutes),
					l5ValueMg: Se(e.l5ValueMg),
					l5OnsetEpoch: e.l5OnsetEpoch,
					m5ValueMg: Se(e.m5ValueMg),
					m5OnsetEpoch: e.m5OnsetEpoch,
					igGradient: Se(e.igGradient),
					igIntercept: Se(e.igIntercept),
					igRsquared: Se(e.igRsquared),
					fragTpIn2ac: Se(e.fragTpIn2ac),
					fragTpAc2in: Se(e.fragTpAc2in),
					nFragments: e.nFragments,
					nightNumber: e.nightNumber,
					tstMinutes: Ae(e.tstMinutes),
					wasoMinutes: Ae(e.wasoMinutes),
					sleepEfficiency: Ae(e.sleepEfficiency),
					numberOfAwakenings: e.numberOfAwakenings,
					sptDurationHours: Ae(e.sptDurationHours),
					cleaningCode: e.cleaningCode
				}))
			}),
			execution: i.execution,
			provenance: i.provenance
		} : null;
		var s;
	}(await Ee(), e, n, t, r, a),
	getComputeIdentity: async () => function(e, n) {
		if (!/^[0-9a-f]{64}$/.test(n)) throw new Error("Actours WASM artifact identity is unavailable or invalid; refusing to attest this runtime");
		const t = "object" == typeof e && null !== e ? e : {}, r = (e, n) => {
			const t = e[n];
			if ("string" != typeof t || 0 === t.length) throw new Error(`Actours capability ${n} must be a non-empty string`);
			return t;
		}, a = r(t, "contractVersion");
		if (a !== be) throw new Error(`Unsupported Actours compute contract ${a}; expected ${be}`);
		const o = r(t, "crateVersion"), i = t.sourceRevision;
		if (null !== i && ("string" != typeof i || 0 === i.length)) throw new Error("Actours capability sourceRevision must be null or a non-empty string");
		const s = t.compiledFeatures;
		if (!Array.isArray(s) || !s.every((e) => "string" == typeof e && e.length > 0)) throw new Error("Actours capability compiledFeatures must be an array of non-empty strings");
		const c = r("object" == typeof t.execution && null !== t.execution ? t.execution : {}, "target");
		if ("wasm" !== c) throw new Error(`Unsupported Actours execution target ${c}; expected wasm`);
		if (!(Array.isArray(t.semanticProfiles) ? t.semanticProfiles : []).includes(ve)) throw new Error(`Actours capability does not provide required semantic profile ${ve}`);
		const l = r(t, "profileProofStatus");
		if ("proof_pending" !== l) throw new Error(`Unsupported Actours profile proof status ${l}; expected proof_pending`);
		const u = r(t, "temporalBasis");
		if ("utc" !== u) throw new Error(`Unsupported Actours temporal basis ${u}; expected utc`);
		return {
			contractVersion: a,
			crateVersion: o,
			sourceRevision: i,
			artifactSha256: n,
			compiledFeatures: s,
			target: c,
			semanticProfile: ve,
			profileProofStatus: l,
			temporalBasis: u
		};
	}((await Ee()).getComputeCapabilitiesV1(), "ce5a5afabf25b21e4fc5da930e38a2024e923b9e3d3c37db673d7a87f8964e38"),
	runGgirFromEpoch: async (e, n, t, r, a, o) => (await Ee()).runGgirFromEpoch({
		anglez: e,
		enmo: n,
		sampleRateHz: t,
		startTsEpochSec: r,
		...a ? { invalid: a } : {}
	}, {
		ws3: 5,
		...o ? { timezone: o } : {}
	}),
	async resolveTimezone(e) {
		const n = await Ee();
		if ("function" != typeof n.resolveTimezone) throw new Error("resolveTimezone: current actours WASM bundle does not export timezone resolution");
		return n.resolveTimezone(e);
	},
	async readGgirMeta(e) {
		const n = await Ee();
		if ("function" != typeof n.readGgirMeta) throw new Error("readGgirMeta: current actours WASM bundle does not export GGIR RData import");
		const t = n.readGgirMeta(e), r = "object" == typeof t && null !== t ? t : null, a = r ? ke(r.timestampsMs) : null, o = r ? ke(r.enmo5s) : null, i = r ? ke(r.anglez5s) : null, s = r ? ke(r.anglex5s) : null, c = r ? ke(r.angley5s) : null, l = r ? Ie(r.invalidShort) : null, u = r ? Ie(r.nonwearShort) : null, d = r ? Ie(r.part3Sib5s) : null, p = r ? ke(r.anglez5sImputed) : null, m = r ? ke(r.enmo5sImputed) : null, f = r?.part3SptNights, y = Array.isArray(f) ? f : null;
		if (!(a && o && i && l && u)) throw new Error(`readGgirMeta: unexpected WASM return shape — got ${JSON.stringify(t)}`);
		const _ = "number" == typeof r?.epochSeconds ? r.epochSeconds : 5, h = "number" == typeof r?.longEpochSeconds ? r.longEpochSeconds : 900, w = "number" == typeof r?.nShort ? r.nShort : o.length, b = "number" == typeof r?.nLong ? r.nLong : 0, v = "string" == typeof r?.desiredtz ? r.desiredtz : void 0, S = r?.inspection, A = "number" == typeof S?.dformc ? S.dformc : void 0;
		return g({
			...v ? { desiredtz: v } : {},
			...null != A ? { dataFormat: A } : {},
			timestampsMs: a,
			enmo5s: o,
			anglez5s: i,
			...s ? { anglex5s: s } : {},
			...c ? { angley5s: c } : {},
			invalidShort: l,
			nonwearShort: u,
			...d ? { part3Sib5s: d } : {},
			...p ? { anglez5sImputed: p } : {},
			...m ? { enmo5sImputed: m } : {},
			...y ? { part3SptNights: y } : {},
			epochSeconds: _,
			longEpochSeconds: h,
			nShort: w,
			nLong: b
		}, [
			a.buffer,
			o.buffer,
			i.buffer,
			...s ? [s.buffer] : [],
			...c ? [c.buffer] : [],
			l.buffer,
			u.buffer,
			...d ? [d.buffer] : [],
			...p ? [p.buffer] : [],
			...m ? [m.buffer] : []
		]);
	},
	identifyGgirRData: async (e) => (await Ee()).identifyGgirRData(e),
	ggirConfigValues: async (e) => function(e) {
		if ("object" != typeof e || null === e) throw new Error("actours returned invalid GGIR config values");
		const n = e, t = (e, t) => {
			const r = n[e] ?? null;
			if (null !== r && typeof r !== t) throw new Error(`actours returned an invalid GGIR config value ${e}`);
			return r;
		};
		return {
			desiredTz: t("desiredTz", "string"),
			configTz: t("configTz", "string"),
			imputeTimegaps: t("imputeTimegaps", "boolean"),
			logLocation: t("logLocation", "string")
		};
	}((await Ee()).ggirConfigValues(e)),
	async reviewGgirResults(e) {
		const n = (await Ee()).reviewGgirResults(e.part1, e.configCsv, e.ms2, e.ms3, e.ms4, e.ms5, e.sleeplogRData, e.sleeplogCsv, e.recordingId, e.edits, e.crossCheck);
		return g(n, [n.sib.buffer, n.invalid.buffer]);
	},
	async scoreGgirSib(e, n, t) {
		const r = (await Ee()).scoreGgirSib(e, n, t);
		if ("object" != typeof r || null === r || !r.sadeh_ggir || !r.ck_ggir) throw new Error(`scoreGgirSib: unexpected WASM return shape — got ${JSON.stringify(r)}`);
		const a = r, o = new Uint8Array(a.sadeh_ggir), i = new Uint8Array(a.ck_ggir);
		return g({
			sadeh_ggir: o,
			ck_ggir: i
		}, [o.buffer, i.buffer]);
	},
	async scoreGgirHasib(e) {
		const n = (await Ee()).scoreGgirHasib(e);
		if (!(n instanceof Uint8Array)) throw new Error("scoreGgirHasib: unexpected WASM return shape — expected Uint8Array, got " + typeof n);
		const t = new Uint8Array(n);
		return g(t, [t.buffer]);
	},
	async scoreGgirHasibVariant(e, n, t) {
		const r = function(e, n) {
			if ("object" != typeof e || null === e) throw new Error("scoreGgirHasibVariant: unexpected WASM return shape — got " + typeof e);
			const t = e, r = Ie(t.sib);
			if (!r) throw new Error(`scoreGgirHasibVariant: missing sib array — got ${JSON.stringify(e)}`);
			return {
				algo: "string" == typeof t.algo ? t.algo : n,
				sib: r,
				nPostch: "number" == typeof t.nPostch ? t.nPostch : 0,
				nGaps: "number" == typeof t.nGaps ? t.nGaps : 0,
				nWake: "number" == typeof t.nWake ? t.nWake : 0,
				nSleep: "number" == typeof t.nSleep ? t.nSleep : 0,
				sleepFraction: "number" == typeof t.sleepFraction ? t.sleepFraction : 0,
				columnName: "string" == typeof t.columnName ? t.columnName : ""
			};
		}((await Ee()).scoreGgirHasibVariant({
			data: e,
			algo: n,
			...t ? { config: t } : {}
		}), n);
		return g(r, [r.sib.buffer]);
	},
	async runGgirPart3(e) {
		const n = (await Ee()).runGgirPart3(e), t = "object" == typeof n && null !== n ? n : null, r = t ? Ie(t.part3Sib5s) : null, a = t?.part3SptNights;
		if (!r || !Array.isArray(a)) throw new Error("runGgirPart3: unexpected WASM return shape — got " + typeof n);
		return g({
			part3Sib5s: r,
			part3SptNights: a
		}, [r.buffer]);
	},
	async detectGgirHasptVariant(e) {
		const n = function(e, n) {
			if ("object" != typeof e || null === e) throw new Error("detectGgirHasptVariant: unexpected WASM return shape — got " + typeof e);
			const t = e, r = Ie(t.nomov), a = ke(t.rollingMedian);
			if (!r || !a) throw new Error(`detectGgirHasptVariant: missing output arrays — got ${JSON.stringify(e)}`);
			return {
				algo: "string" == typeof t.algo ? t.algo : n,
				guider: "string" == typeof t.guider ? t.guider : "",
				startEpoch: "number" == typeof t.startEpoch ? t.startEpoch : null,
				endEpoch: "number" == typeof t.endEpoch ? t.endEpoch : null,
				threshold: "number" == typeof t.threshold ? t.threshold : NaN,
				nomov: r,
				rollingMedian: a
			};
		}((await Ee()).detectGgirHasptVariant(e), e.algo);
		return g(n, [n.nomov.buffer, n.rollingMedian.buffer]);
	},
	async scoreAllDays(e) {
		const n = (await Ee()).scoreAllDays(e);
		if (!Array.isArray(n)) throw new Error("scoreAllDays: expected array from WASM, got " + typeof n);
		const t = (e) => e instanceof Uint8Array || Array.isArray(e), r = n[0];
		if (n.length > 0 && ("object" != typeof r || null === r || !t(r.sadeh_actilife) || !t(r.nonwear))) throw new Error(`scoreAllDays: unexpected element shape — got ${JSON.stringify(r)}`);
		const a = n.map((e) => ({
			sadeh_actilife: new Uint8Array(e.sadeh_actilife),
			sadeh_original: new Uint8Array(e.sadeh_original),
			ck_actilife: new Uint8Array(e.ck_actilife),
			ck_original: new Uint8Array(e.ck_original),
			nonwear: new Uint8Array(e.nonwear)
		}));
		return g(a, a.flatMap((e) => [
			e.sadeh_actilife.buffer,
			e.sadeh_original.buffer,
			e.ck_actilife.buffer,
			e.ck_original.buffer,
			e.nonwear.buffer
		]));
	}
})));

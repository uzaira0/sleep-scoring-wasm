import { Ht as t, Ut as e } from "./schema-ovLsLXAy.js";
import { t as o } from "./workspace-db-BfwRi1Vg.js";
import { o as r } from "./content-hash-BtD8CeUH.js";
import { i } from "./project-revision-D-oYPTdh.js";
import { t as a } from "./audit-hash-rfcCP1yx.js";
function n(t, e, o) {
	const r = Object.values(e);
	if (!r.includes(t)) throw new Error(`${o} must be one of ${r.join(", ")} (bundle reported "${t}")`);
	return t;
}
function s(e) {
	return n(e, t, "profileProofStatus");
}
function c(t) {
	return n(t, e, "temporalBasis");
}
const u = {
	full_calibrated_signal: "https://w3id.org/sleep-scoring-ontology/method/actours/full-pipeline-file/1",
	epoch_series_part3to5: "https://w3id.org/sleep-scoring-ontology/method/actours/ggir-epoch-parts-3-to-5/1"
}, m = "actours.compute.file.v1", p = Number.MAX_SAFE_INTEGER;
function d(t) {
	if (null == t) return null;
	if ("string" == typeof t) {
		for (let e = 0; e < t.length; e++) {
			const o = t.charCodeAt(e);
			if (o >= 55296 && o <= 56319) {
				const o = t.charCodeAt(e + 1);
				if (!(o >= 56320 && o <= 57343)) throw new TypeError("method parameter strings must contain only Unicode scalar values");
				e++;
			} else if (o >= 56320 && o <= 57343) throw new TypeError("method parameter strings must contain only Unicode scalar values");
		}
		return t;
	}
	if ("boolean" == typeof t) return t;
	if ("number" == typeof t) {
		if (!Number.isFinite(t)) throw new TypeError("method parameter numbers must be finite");
		if (Number.isInteger(t) && Math.abs(t) > p) throw new TypeError("method parameter integers must be exactly representable in IEEE-754 binary64");
		return t;
	}
	if (Array.isArray(t)) return t.map(d);
	if ("object" == typeof t) {
		const e = {};
		for (const [o, r] of Object.entries(t)) null != r && (e[o] = d(r));
		return e;
	}
	throw new TypeError("unsupported method parameter type: " + typeof t);
}
const _ = /* @__PURE__ */ new Set([
	"id",
	"fileId",
	"createdAt",
	"updatedAt"
]);
async function l(t) {
	const e = [...t].sort((t, e) => t.analysisDate.localeCompare(e.analysisDate)).map((t) => a(d(function(t) {
		const e = {};
		for (const [o, r] of Object.entries(t)) _.has(o) || void 0 !== r && (e[o] = r);
		return e;
	}(t))));
	return r(`[${e.join(",")}]`);
}
const h = {
	accelerator: "cpu_only",
	concurrency: {
		mode: "serial",
		max_threads: null
	},
	vectorization: "baseline"
};
async function f(t, e = o(), n) {
	const s = e, c = await async function(t) {
		if (!/^[0-9a-f]{64}$/.test(t.sourceContentSha256)) throw new Error("sourceContentSha256 must be 64 lowercase hex characters");
		if (!Number.isInteger(t.sourceSizeBytes) || t.sourceSizeBytes < 1) throw new Error("sourceSizeBytes must be a positive integer");
		if (!/^[0-9a-f]{64}$/.test(t.runtimeBuild.artifactSha256)) throw new Error("runtimeBuild.artifactSha256 must be 64 lowercase hex characters");
		const e = t.dailyRows.length, o = 0 === e ? [] : [`daily_summary_stream:sha256:${await l(t.dailyRows)}`], i = h, n = u[t.computePath], s = await async function(t) {
			if (!t.methodSpecificationId.trim()) throw new Error("methodSpecificationId must be nonblank");
			const e = (o = t.params, a(d(o)));
			var o;
			return {
				parameter_set_hash: await r(e),
				method_specification_id: t.methodSpecificationId,
				canonicalization_version: "rfc8785_jcs_v1",
				canonical_parameters_json: e,
				parameter_schema_reference: t.parameterSchemaReference ?? null
			};
		}({
			methodSpecificationId: n,
			params: {
				file_compute_contract: m,
				...t.ggirConfigSha256 ? { ggir_config_sha256: t.ggirConfigSha256 } : {},
				execution: {
					accelerator: i.accelerator,
					concurrency: {
						mode: i.concurrency.mode,
						maxThreads: i.concurrency.max_threads
					},
					vectorization: i.vectorization
				}
			}
		}), c = t.runtimeBuild, p = c.sourceRevision ?? `${c.crateVersion}+${[...c.compiledFeatures].sort().join("+")}`, _ = {
			execution_id: (f = t.fileId, y = t.computePath, `local:file-${String(f)}:actours-${y.replace(/_/g, "-")}-v1`),
			method_specification_id: n,
			method_implementation_id: `actours:${c.target}:${p}:artifact-sha256-${c.artifactSha256}:${t.computePath}`,
			parameter_set_hash: s.parameter_set_hash,
			input_entity_ids: [`urn:sha256:${t.sourceContentSha256}`],
			output_entity_ids: o,
			started_at: t.startedAt,
			completed_at: t.finishedAt
		};
		var f, y;
		return {
			result_contract_version: "sleep-scoring-web.local-content-bound-daily-summary/v1",
			file_compute_contract_version: m,
			compute_contract_version: "actours.compute.v1",
			source_content_sha256: t.sourceContentSha256,
			source_size_bytes: t.sourceSizeBytes,
			source_revision: c.sourceRevision,
			semantic_profile: t.semanticProfile,
			profile_proof_status: t.profileProofStatus,
			temporal_basis: t.temporalBasis,
			compute_path: t.computePath,
			target: "wasm",
			calibration_disposition: t.calibration?.disposition ?? "skipped_disabled",
			daily_output_disposition: 0 === e ? "no_complete_daily_interval" : "complete_daily_outputs",
			diary_disposition: t.diaryDisposition,
			timestamp_grid: t.timestampGrid,
			parameter_set: s,
			execution_request: i,
			method_execution: _,
			output_row_count: e,
			runtime_build: c,
			source_digest_scope: t.sourceDigestScope
		};
	}(t), p = await async function(t) {
		return r(a({
			execution_id: t.method_execution.execution_id,
			source_content_sha256: t.source_content_sha256,
			source_digest_scope: t.source_digest_scope,
			method_specification_id: t.method_execution.method_specification_id,
			method_implementation_id: t.method_execution.method_implementation_id,
			parameter_set_hash: t.parameter_set.parameter_set_hash,
			output_entity_ids: t.method_execution.output_entity_ids ?? [],
			output_row_count: t.output_row_count
		}));
	}(c), _ = {
		attestationId: p,
		fileId: t.fileId,
		importStatus: 0 === t.dailyRows.length ? "completed_partial" : "committed",
		contractStatus: "valid",
		importerName: "sleep-scoring-web-wasm",
		importerVersion: t.appVersion,
		startedAt: t.startedAt,
		finishedAt: t.finishedAt,
		createdAt: (/* @__PURE__ */ new Date()).toISOString(),
		attestation: c
	};
	return i(s, [s.localExecutions], async () => {
		const t = await s.localExecutions.where("attestationId").equals(p).first();
		if (void 0 !== t?.id) {
			const e = {
				..._,
				id: t.id,
				createdAt: t.createdAt
			};
			return await s.localExecutions.put(e), e;
		}
		const e = await s.localExecutions.add(_);
		return {
			..._,
			id: e
		};
	}, n);
}
export { f as i, s as n, c as r, d as t };
